﻿using ENOC.Loyalty.Utility;

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IdentityModel.Selectors;
using System.IdentityModel.Tokens;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace AuthenticationClass
{
    class ServiceValidator : UserNamePasswordValidator
    {

        public override void Validate(string userName, string password)
        {
            try
            {
                String AccountUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
               System.Diagnostics.EventLog.WriteEntry("ServiceUserName", userName);
                System.Diagnostics.EventLog.WriteEntry("ServicePassword", password);
                String ServiceID = userName.Substring(userName.Length - 4);
                int SID = int.Parse(ServiceID);
                userName = userName.Remove(userName.Length - 4);
                System.Diagnostics.EventLog.WriteEntry("userName", userName);
                string ServiceUsername = string.Empty;
                string ServicePassword = string.Empty;
                string ServiceCertiicate, ServicePublicKey, BTCertiicate, BTPublicKey;
                string BTUserName = string.Empty;
                string BTPassword = string.Empty;
                Encryptor EnocEnc = new Encryptor();
                ClassConnectionString strcon = new ClassConnectionString();
                
                strcon.connectionString();
                SqlCommand selectCMD = new SqlCommand("SELECT *   FROM [dbo].[ELM_ServiceCredential]  where ServiceID = " + SID + " and Active = 'Y'", strcon.conConnect);
                System.Diagnostics.EventLog.WriteEntry("selectCMD", selectCMD.ToString());
                System.Diagnostics.EventLog.WriteEntry("AccountUser", AccountUser);
                SqlDataAdapter da = new SqlDataAdapter();               
                da.SelectCommand = selectCMD;                
                strcon.conConnect.Open();             
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 2)
                {
                    foreach (DataRow dr in dt.Rows)
                    {                       
                        if (dr[7].ToString() != "Biztalk")
                        {
                            System.Diagnostics.EventLog.WriteEntry("Biztalk", dr[7].ToString());
                            System.Diagnostics.EventLog.WriteEntry("ServiceName1", AccountUser+"_"+ dr[7].ToString());
                            ServiceCertiicate = dr[5].ToString();
                            System.Diagnostics.EventLog.WriteEntry("ServiceCertiicate2", ServiceCertiicate);
                            ServicePublicKey = dr[6].ToString();
                            System.Diagnostics.EventLog.WriteEntry("ServicePublicKey3", AccountUser + "_" + ServicePublicKey);
                            ServiceUsername = EnocEnc.DecryptInput(userName, ServiceCertiicate, ServicePublicKey);
                            System.Diagnostics.EventLog.WriteEntry("ServiceUsernameDEC4", AccountUser + "_" + ServiceUsername);
                            ServicePassword = EnocEnc.DecryptInput(password, ServiceCertiicate, ServicePublicKey);
                            System.Diagnostics.EventLog.WriteEntry("ServicePasswordDEC5", AccountUser + "_" + ServicePassword);

                        }
                        if (dr[7].ToString() == "Biztalk")
                        {
                            BTUserName = dr[3].ToString();
                            System.Diagnostics.EventLog.WriteEntry("BTUserName1", AccountUser + "_" + BTUserName);
                            BTPassword = dr[4].ToString();
                            System.Diagnostics.EventLog.WriteEntry("BTPassword2", AccountUser + "_" + BTPassword);
                            BTCertiicate = dr[5].ToString();
                            System.Diagnostics.EventLog.WriteEntry("BTCertiicate3", AccountUser + "_" + BTCertiicate);
                            BTPublicKey = dr[6].ToString();
                            System.Diagnostics.EventLog.WriteEntry("BTPublicKey4", AccountUser + "_" + BTPublicKey);
                            BTUserName = EnocEnc.DecryptInput(BTUserName, BTCertiicate, BTPublicKey);
                            System.Diagnostics.EventLog.WriteEntry("BTUserNameDEC5", AccountUser + "_" + BTUserName);
                            BTPassword = EnocEnc.DecryptInput(BTPassword, BTCertiicate, BTPublicKey);
                            System.Diagnostics.EventLog.WriteEntry("BTPassword6", AccountUser + "_" + BTPassword);
                           
                        }
                    }
                }
                strcon.conConnect.Close();
                System.Diagnostics.EventLog.WriteEntry("Final", BTUserName + " _ " + BTPassword + " _ " + ServiceUsername + " _ " + ServicePassword);
               
                if ((String.Equals(ServiceUsername, BTUserName) == true) && (String.Equals(ServicePassword, BTPassword) == true))
                {
                    
                    return;
                }
                else
                {
                    
                    throw new SecurityTokenException("401-Unauthorized-access-is-denied-due-to-invalid-credentials");
                }

            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("SecurityTokenException", ex.ToString());
                             
                throw new FaultException("Unauthorized Access is denied due to Invalid Credentials", new FaultCode("401"));
               
              //  throw new SecurityTokenException("Unknown Username or Password");

            }
            throw new FaultException("Unauthorized Access is denied due to Invalid Credentials", new FaultCode("401"));
        }

    }
    public class ClassConnectionString
    {
        public SqlConnection conConnect;
        public void connectionString()
        {
            string conn_enc = System.Configuration.ConfigurationManager.AppSettings.Get("Connect_LoyaltyDB");           
            string key_enc = System.Configuration.ConfigurationManager.AppSettings.Get("Key_LoyaltyDB");           
            string key = decrypt(key_enc, "loyalitykey123");            
            string conn = decrypt(conn_enc, key);          
            conConnect = new SqlConnection(conn);          
        }

        private string decrypt(string con, string key_enc)
        {
            SecureAccessComponent.clsEncryption64 enc = new SecureAccessComponent.clsEncryption64();
            return enc.DecryptFromBase64String(con, key_enc);
        }
    }
}
