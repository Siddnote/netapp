﻿using AuthenticationTest.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Security;
using System.Text;
using System.Threading.Tasks;

namespace AuthenticationTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Service1Client c = new Service1Client();



            string UserName = "JnphorlbIFD8aJzcT4EX0ws9IlWtkdleCfEfCOx1xWTw5H511GCzD0szXlWL4mDjqoRDsbxFqAq/l+eovpcTdpUtUK8QF429b451g6+42YyfBhar+lVabEBfJNcn2ydFEaHZtgwhDJGIaUzJ5bTekL2jSk7mbeyPgY7lcfen2RhcN0Bsi/rfnQs9HExxKh86SagT9fgPZYEgOkc9N/7/6/PqhZjBTrE2dh6PSTpuKbMv79TPefmrpaIIVGSi83K7e64mlwqajiWdHkl6LcgnPJKYTvh69IwlcHVnmOlDj+u8yuMsGcCBLfTD6es/X4HVmSV2fxGs2zIdEHITF9th0A==0001";
            string Password = "exfKTT4V6+0ET7mW25JQF5EL64i81PTWYDzaHNEaPi51JCuLBVjY0pYz8bq8uANByNftZkqi1fnCs31fJEWeY9kubL1Qq8zpxU3XDvSTRl8DPv9pOhmbsZNJm4FTc5P2pxN2vfLXVaBXFmqQm9118WU6viEL3cYXcgYW/vFIjuoJtifDdngZOdUT9mDvQbZ8tHRcfJVBbKprcXLqhFze+kU1/J5RJr9aFdFqarr2J2oRZq+g2cCqcXihDxcCHhud9bYSaFTXv5HnuNHyzpGZ80q9cuWtwb60Ion4MlgbCCLT9g9J6sRx7Y7siZKIGNFW9Rb7kHp7oNNWIcCLZi4H7w==";


            //loyaltyBTProxy.ClientCredentials.UserName.UserName = UserName;
            //loyaltyBTProxy.ClientCredentials.UserName.Password = Password;
            c.ClientCredentials.UserName.UserName = UserName;
            c.ClientCredentials.UserName.Password = Password;

            System.Net.ServicePointManager.ServerCertificateValidationCallback += delegate { return true; };
            try
            {
                var t = c.GetData(1);
            }


            //catch (MessageSecurityException ex) {
            //    string a = ex.InnerException.ToString();
            //}


            catch (Exception ex)
            {
               
                if (ex is FaultException)
                {
                    string code = (ex as FaultException).Code.Name;
                }
                else if (ex is MessageSecurityException) {
                    string Description = ex.InnerException.Message;
                  
                }
            }



        }
    }
   
}
