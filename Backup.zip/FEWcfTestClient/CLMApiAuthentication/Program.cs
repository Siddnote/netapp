﻿


using CLMApiAuthentication.ServiceReference1;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using System.Text;
using System.Threading.Tasks;

namespace CLMApiAuthentication
{
    class Program
    {
        public static ServiceReference1.WcfService_ENOC_Loyalty_Integration_CLM_OrchestrationsClient loyaltyBTProxy = new ServiceReference1.WcfService_ENOC_Loyalty_Integration_CLM_OrchestrationsClient();
        public static string UserName = "nA2ppOJ/L4fcx3tT8Kxz7Uq7GiaCy589QwboElhuZGP29I31TNvn6CFqkibaJmZCYfI7tTQkPhUBkwal7uX8Bx2lgO/0UnpTBLZM6kXVOPqHIFxCom0EhfPm0Jse4HmseOlFw/mEeCV67xuwBbgrsTE9745znq/zEIcDSTV76eBpXisMBhQ6W4DdVM7hA5Sqg0wRC0sP4l03C8aFzUAOHlzqN/lNxpCbsCo9UBW8gps9Ue2i3sF5mUrWGoLmOlprpPm+fOn/r24mIFNgApczl9e/3RwMIjovWzbJjvF1ugUOdan0S+0b7vx6FMXmeq6hM/nRLPredvhiEZ9xgtqNag==0002";
        public static string Password = "YGnYroxk8l9FECwTMOt0Y6CMLlzRfueKzrKkDbAwYuBfWQJzwC7s/E3Ude/KbFv/pfgwQSMbrgIZsz3NnWVUc7y1utB36bXrONfh3tJZpoFO+niJjudptXwEFrYUcOhTn5qDb48sbF4op2lpavY341iLWfREeB9ZJP/Uq652RaPTy/jxd7YE4lbdQLhGN/A65RQOaVN0ykvB1+TRiokBzckORdI7yZaXlhfO9Zp58Du16ApJYLx7uj3Osh0IzF7aPkdOe/uFVhOD6SykuTVOQwTpltm7oGy3FgmkrAH4+hWd3F1ahK+y+X6Z3m5edxvGlUs2jW2Z2u3+yNQu/cnyRg==";

        static void Main(string[] args)
        {
            try
            {
            //    string logfilePath = @"D:\Siddhant\Archive\";
            //    string date = DateTime.Now.ToString("ddMMyyyy");
            //    string logDir = logfilePath +  date + "\\";
            //    if (!Directory.Exists(logDir))
            //    {
            //        Directory.CreateDirectory(logDir);
            //    }

                loyaltyBTProxy.ClientCredentials.UserName.UserName = UserName;
                loyaltyBTProxy.ClientCredentials.UserName.Password = Password;

                System.Net.ServicePointManager.ServerCertificateValidationCallback += delegate { return true; };

                Console.WriteLine("Enter Number of Messages You want to Process:");
                int numb =  Convert.ToInt32(Console.ReadLine());

                for (int i = 0; i < numb; i++)
                {
                    Console.WriteLine("Mesages Request Sent Number : " + i);
                    // CorporateEnrollment();
                    ValidateMember();
                    //PointExpiration();
                    //SoftEnrollment();
                   //Enrollment();
                    Console.WriteLine("Mesages Response Received Number" + i);
                }
                Console.ReadLine();

            }
            catch (Exception ex)
            {

                Console.WriteLine("Error: " + ex.InnerException.ToString());
            }

        }
        static string ValidateMember()
        {
            ProfileServiceResponseRecord response = loyaltyBTProxy.ProfileService(new ProfileServiceRequestRecord()
            {
                CallingSystem = "TestZoom",
                RequestId = Guid.NewGuid().ToString(),
                CLMProfileServiceValidateMemberRequest = new CLMProfileServiceValidateMemberRequest() { phone = "973456543309" },
                HTTP_METHOD = "GET",
                CLM_METHOD = "validatemember"
            });
            string Res = response.CLMResponse.CLMMessage;
            return Res;
        }
        static string CorporateEnrollment()
        {

            CorporateProfileServiceResponseRecord res = loyaltyBTProxy.CorporateService(new CorporateProfileServiceRequestRecord()
            {
                CLM_METHOD = "corpenrollment",
                HTTP_METHOD = "POST",
                RequestId = Guid.NewGuid().ToString(),
                CLMCorporateProfileServiceEnrollmentRequest = new CLMCorporateProfileServiceEnrollmentRequest()
                {
                    name = "Alexaa",
                    taxId = "11323211232-117",
                    balanceType = "S",
                    accountType = "AC_CORPO",
                    identifierType = "YES_CORP",
                    permissions = new CLMCorporateProfileServiceEnrollmentRequestPermissions()
                    {
                        adverts = "true",
                        email = "true",
                        info = "true",
                        phone = "true",
                        post = "true",
                        sms = "true"
                    },
                    address = new CLMCorporateProfileServiceEnrollmentRequestAddress()
                    {
                        street = "street 1",
                        house = "ENOC house",
                        postalCode = "34243",
                        city = "Dubai",
                        country = "UAE",
                        email = "tahel@gmail.com"
                    },
                    administrator = new CLMCorporateProfileServiceEnrollmentRequestAdministrator()
                    {
                        email = "rohan@gmail.com",
                        permissionEmail = true,
                        firstName = "Horizona",
                        lastName = "keviana",
                        login = "tahel@gmail.com",
                        language = "en",
                        password = "keviata"
                    }

                }

            });

            string Res = res.CLMResponse.CLMMessage;
            return Res;
        }
        static string PointExpiration()
        {
            TransactionServiceResponseRecord TRS = loyaltyBTProxy.TransactionService(new TransactionServiceRequestRecord()
            {
                CLM_METHOD = "pointsexpiration",
                RequestId = Guid.NewGuid().ToString(),
                CLMTransactionServiceExpirationForecastRequest = new CLMTransactionServiceExpirationForecastRequest()
                {
                    customerId = "4106"
                }
            });

            string Res = TRS.CLMResponse.CLMMessage;
            return Res;
        }

        static string CroporateClose()
        {
            CorporateProfileServiceResponseRecord response = loyaltyBTProxy.CorporateService(new CorporateProfileServiceRequestRecord()
            {
                CLM_METHOD = "corpclose",
                RequestId = Guid.NewGuid().ToString(),
                CLMCorporateProfileServiceCompanyIdCloseRequest = new CLMCorporateProfileServiceCompanyIdCloseRequest() { companyIdSpecified = true, fraud = true, reason = "Close", companyId = 123 }

            });

            string Res = response.CLMResponse.CLMMessage;
            return Res;
        }

        static string Enrollment()
        {
            ProfileServiceResponseRecord response = loyaltyBTProxy.ProfileService(new ProfileServiceRequestRecord()
            {
                CallingSystem = "TestZoom",
                RequestId = Guid.NewGuid().ToString(),
                CLMProfileServiceEnrollmentRequest = new CLMProfileServiceEnrollmentRequest()
                {
                    applicationDate = "2020-01-15",
                    title = "Mr.",
                    firstName = "aWWsf",
                    lastName = "W.",
                    birthDate = "1940-01-01",
                    extPhone = "+971345777842",
                    gender = "M",
                    login = "f@f.com",
                    password = "dxnz2219DX",
                    address = new CLMProfileServiceEnrollmentRequestAddress()
                    {
                        mobile = "971345777842",
                        email = "abcERT123@comarch.com"
                    }
                },
                HTTP_METHOD = "POST",
                CLM_METHOD = "enrollment"
            });
            string Res = response.CLMResponse.CLMMessage;
            return Res;
        }
        static string SoftEnrollment()
        {
            ProfileServiceRequestRecord loyaltySoftRegisterServiceRequest = new ProfileServiceRequestRecord()
            {
                // CallingSystem = SiteServiceID.ENOC_Loyalty_SSB_SiteService.ToString(),
                CLM_METHOD = "softenrollment",
                // SiteNo = ConfigurationManager.AppSettings[Constants.SiteSSBLoyaltyServiceENOCSiteNoAppKey],
                // HTTP_METHOD = HTTPMethods.GET.ToString(),
                RequestId = Guid.NewGuid().ToString(),
                // CompanyCode = ((int)CommonService.ToEnum<CompanyCode>(CompanyCode.UAE.ToString())).ToString(),

            };

            CLMProfileServiceSoftEnrollmentRequest loyaltySoftEnrollmentRequest = new ServiceReference1.CLMProfileServiceSoftEnrollmentRequest()
            {
                firstName = "Siddhantt",
                lastName = "Pandeey",
                phone = "+971588523424"
            };

            loyaltySoftRegisterServiceRequest.CLMProfileServiceSoftEnrollmentRequest = loyaltySoftEnrollmentRequest;

            ProfileServiceResponseRecord response = loyaltyBTProxy.ProfileService(loyaltySoftRegisterServiceRequest);
            string Res = response.CLMResponse.CLMMessage;
            return Res;
        }
    }

}

