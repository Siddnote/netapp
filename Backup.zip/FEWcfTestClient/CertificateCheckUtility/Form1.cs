﻿using Cryptography;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CertificateCheckUtility
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            Encryptor enc = new Encryptor();
            richTextBox1.Text = enc.DecryptInput(textBox1.Text, textBox2.Text, textBox3.Text);
            richTextBox1.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            Encryptor enc = new Encryptor();
            richTextBox1.Text = enc.EncryptUsingCertificateName(textBox1.Text, textBox2.Text, textBox3.Text);
            richTextBox1.Visible = true;
        }
    }

    public class Encryptor1
    {
        private static string encryptorMsg;
        private static string cryptoKey;
        private static HashedEncryption objEncryptDecrypt;
        private const string encryptionPvtKey = "HoAuthPvtKey@1406";
        private const string configXmlName = "ENOC.SSB.CertEncryptor.Config.xml";
        private static string enocPublicKey;
        private static string hashedCertName;
        private static string decryptedCertName;
        private static string decryptedPublicKey;

        public Encryptor1()
        {
            cryptoKey = string.Empty;
            decryptedCertName = string.Empty;
            objEncryptDecrypt = new HashedEncryption();
            decryptedPublicKey = string.Empty;
            enocPublicKey = string.Empty;
        }


        public string EncryptUsingCertificateName(string stringToBeEncrypt, string encryptedCertName, string encryptedPublicKey)
        {
            string encryptedInput = string.Empty;
            try
            {

                decryptedPublicKey = objEncryptDecrypt.Decrypt(encryptedPublicKey, encryptionPvtKey);
                decryptedCertName = objEncryptDecrypt.Decrypt(encryptedCertName, decryptedPublicKey);

                encryptedInput = EncryptCertString(stringToBeEncrypt, decryptedCertName);
            }
            catch (System.IO.FileNotFoundException exception)
            {

                encryptedInput = exception.Message;

            }
            catch (Exception exception)
            {

                encryptedInput = exception.Message;

            }

            return encryptedInput;
        }


        /// <summary>
        /// Method to be used to encrypt any string using certificate
        /// </summary>
        /// <param name="stringToBeEncrypt">Input string for encryption</param>
        /// <param name="encryptedCertName">Not in use</param>
        /// <param name="publicKey">Not in use</param>
        /// <returns>encrypted Input</returns>

        //[DllExport("EncryptUsingCertificate", CallingConvention = CallingConvention.Cdecl)]
        public string EncryptUsingCertificate(string stringToBeEncrypt, string encryptedCertName, string encryptedPublicKey)
        {
            string encryptedInput = string.Empty;
            try
            {
                //Read the config file in root directory
                DataSet dataset = new DataSet();
                dataset.ReadXml(configXmlName);
                hashedCertName = dataset.Tables[0].Rows[0]["CertificateName"].ToString();
                enocPublicKey = dataset.Tables[0].Rows[0]["ENOCPublicKey"].ToString();

                decryptedPublicKey = objEncryptDecrypt.Decrypt(enocPublicKey, encryptionPvtKey);
                decryptedCertName = objEncryptDecrypt.Decrypt(hashedCertName, decryptedPublicKey);

                //Old methods not in use
                //decryptedPublicKey = objEncryptDecrypt.Decrypt(publicKey, encryptionPvtKey);
                //decryptedCertName = objEncryptDecrypt.Decrypt(encryptedCertName, decryptedPublicKey);

                encryptedInput = EncryptCertString(stringToBeEncrypt, decryptedCertName);
            }
            catch (System.IO.FileNotFoundException exception)
            {
                // ProjectData.SetProjectError(exception);
                encryptedInput = exception.Message;
                //ProjectData.ClearProjectError();
            }
            catch (Exception exception)
            {
                //ProjectData.SetProjectError(exception);
                encryptedInput = exception.Message;
                //ProjectData.ClearProjectError();
            }

            return encryptedInput;
        }

        /// <summary>
        /// This method encrypts the input certificateName
        /// </summary>
        /// <param name="certName">CertificateName</param>
        /// <param name="publicKey">ENOC public key</param>
        /// <returns>encrypted certificate name</returns>
        //[DllExport("EncryptString", CallingConvention = CallingConvention.Cdecl)]
        public string EncryptString(string certName, string publicKey)
        {
            string encryptedCert = string.Empty;

            try
            {
                decryptedPublicKey = objEncryptDecrypt.Decrypt(publicKey, encryptionPvtKey);

                encryptedCert = EncryptWithHash(certName, decryptedPublicKey);
            }
            catch (Exception exception)
            {
                //ProjectData.SetProjectError(exception);
                encryptedCert = exception.Message;
                //ProjectData.ClearProjectError();
            }

            return encryptedCert;
        }
        private static string EncryptCertString(string stringToBeEncrypt, string certificateName)
        {
            string strEncyValue = string.Empty;

            try
            {
                // get the certificate from store
                X509Certificate2 cert = GetCertificateFromStore(certificateName);

                if (cert != null)
                {
                    byte[] cipherbytes = Encoding.ASCII.GetBytes(stringToBeEncrypt.Trim());
                    RSACryptoServiceProvider rsa = (RSACryptoServiceProvider)cert.PublicKey.Key;

                    byte[] cipher = rsa.Encrypt(cipherbytes, true);
                    strEncyValue = Convert.ToBase64String(cipher);
                }
                else
                {
                    encryptorMsg = "Certificate not found or invalid certificate in use";
                    strEncyValue = encryptorMsg;
                }
            }
            catch (Exception ex)
            {
                encryptorMsg = " Error in encyption, Method- Encryptstring, Error detail:  " + ex.Message;
                throw new Exception(encryptorMsg);
            }

            return strEncyValue;
        }
        private static X509Certificate2 GetCertificateFromStore(string certName)
        {
            // Get the certificate store for the local machine.
            X509Store store = new X509Store(StoreLocation.LocalMachine);
            try
            {
                store.Open(OpenFlags.ReadOnly);
                X509Certificate2Collection certCollection = store.Certificates;

                X509Certificate2Collection currentCerts = certCollection.Find(X509FindType.FindByTimeValid, DateTime.Now, false);
                X509Certificate2Collection signingCert = currentCerts.Find(X509FindType.FindBySubjectDistinguishedName, certName, false);

                if (signingCert.Count == 0)
                {
                    signingCert = currentCerts.Find(X509FindType.FindByThumbprint, certName, false);
                }
                return signingCert.Count == 0 ? null : signingCert[0];
            }
            catch (Exception exc)
            {
                encryptorMsg = " Error in encryptor, Method- #GetCertificateFromStore#, Error details:  " + exc.Message;
                throw new Exception(encryptorMsg);
            }
            finally
            {
                store.Close();
            }
        }

        public string DecryptInput(string stringToBeDecrypted, string encryptedCertName, string publicKey)
        {
            try
            {
                decryptedPublicKey = objEncryptDecrypt.Decrypt(publicKey, encryptionPvtKey);
                decryptedCertName = objEncryptDecrypt.Decrypt(encryptedCertName, decryptedPublicKey);

                return DecryptCertString(stringToBeDecrypted, decryptedCertName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string DecryptCertString(string strstringToDecrypt, string certificateNameKeyName)
        {
            string plainText = string.Empty;
            try
            {
                // get the certificate from store   
                X509Certificate2 cert = GetCertificateFromStore(certificateNameKeyName);
                if (cert != null)
                {
                    RSACryptoServiceProvider rsa;
                    rsa = (RSACryptoServiceProvider)cert.PrivateKey;
                    byte[] dcipherbytes = Convert.FromBase64String(strstringToDecrypt);
                    byte[] plainbytes = rsa.Decrypt(dcipherbytes, true);
                    ASCIIEncoding enc = new ASCIIEncoding();
                    plainText = enc.GetString(plainbytes);
                }
                else
                {
                    plainText = "ENOC.SSB.OutProcAuthService decryption - Certificate not found or invalid certificate in use";
                }
            }
            catch (Exception ex)
            {
                //plainText = " Decryption error in ENOC.SSB.OutProcAuthServices,Method- Decryptstring, Error detail:  " + ex.Message;
                //throw new Exception(encryptorMsg);
                plainText = ex.Message;
            }
            return plainText;
        }

        private static string EncryptWithHash(string stringTobeEncrypted, string key)
        {
            try
            {
                return objEncryptDecrypt.Encrypt(stringTobeEncrypted, key);
            }
            catch (Exception encryptExc)
            {
                throw encryptExc;
            }
        }

    }

    public class Encryptor
    {
        private static string encryptorMsg;
        private static string cryptoKey;
        private static HashedEncryption objEncryptDecrypt;
        private const string encryptionPvtKey = "HoAuthPvtKey@1406";
        private const string configXmlName = "ENOC.SSB.CertEncryptor.Config.xml";
        private static string enocPublicKey;
        private static string hashedCertName;
        private static string decryptedCertName;
        private static string decryptedPublicKey;

        public Encryptor()
        {
            cryptoKey = string.Empty;
            decryptedCertName = string.Empty;
            objEncryptDecrypt = new HashedEncryption();
            decryptedPublicKey = string.Empty;
            enocPublicKey = string.Empty;
        }


        public string EncryptUsingCertificateName(string stringToBeEncrypt, string encryptedCertName, string encryptedPublicKey)
        {
            string encryptedInput = string.Empty;
            try
            {

                decryptedPublicKey = objEncryptDecrypt.Decrypt(encryptedPublicKey, encryptionPvtKey);
                decryptedCertName = objEncryptDecrypt.Decrypt(encryptedCertName, decryptedPublicKey);

                encryptedInput = EncryptCertString(stringToBeEncrypt, decryptedCertName);
            }
            catch (System.IO.FileNotFoundException exception)
            {

                encryptedInput = exception.Message;

            }
            catch (Exception exception)
            {

                encryptedInput = exception.Message;

            }

            return encryptedInput;
        }


        /// <summary>
        /// Method to be used to encrypt any string using certificate
        /// </summary>
        /// <param name="stringToBeEncrypt">Input string for encryption</param>
        /// <param name="encryptedCertName">Not in use</param>
        /// <param name="publicKey">Not in use</param>
        /// <returns>encrypted Input</returns>

        //[DllExport("EncryptUsingCertificate", CallingConvention = CallingConvention.Cdecl)]
        public string EncryptUsingCertificate(string stringToBeEncrypt, string encryptedCertName, string encryptedPublicKey)
        {
            string encryptedInput = string.Empty;
            try
            {
                //Read the config file in root directory
                DataSet dataset = new DataSet();
                dataset.ReadXml(configXmlName);
                hashedCertName = dataset.Tables[0].Rows[0]["CertificateName"].ToString();
                enocPublicKey = dataset.Tables[0].Rows[0]["ENOCPublicKey"].ToString();

                decryptedPublicKey = objEncryptDecrypt.Decrypt(enocPublicKey, encryptionPvtKey);
                decryptedCertName = objEncryptDecrypt.Decrypt(hashedCertName, decryptedPublicKey);

                //Old methods not in use
                //decryptedPublicKey = objEncryptDecrypt.Decrypt(publicKey, encryptionPvtKey);
                //decryptedCertName = objEncryptDecrypt.Decrypt(encryptedCertName, decryptedPublicKey);

                encryptedInput = EncryptCertString(stringToBeEncrypt, decryptedCertName);
            }
            catch (System.IO.FileNotFoundException exception)
            {
                // ProjectData.SetProjectError(exception);
                encryptedInput = exception.Message;
                //ProjectData.ClearProjectError();
            }
            catch (Exception exception)
            {
                //ProjectData.SetProjectError(exception);
                encryptedInput = exception.Message;
                //ProjectData.ClearProjectError();
            }

            return encryptedInput;
        }

        /// <summary>
        /// This method encrypts the input certificateName
        /// </summary>
        /// <param name="certName">CertificateName</param>
        /// <param name="publicKey">ENOC public key</param>
        /// <returns>encrypted certificate name</returns>
        //[DllExport("EncryptString", CallingConvention = CallingConvention.Cdecl)]
        public string EncryptString(string certName, string publicKey)
        {
            string encryptedCert = string.Empty;

            try
            {
                decryptedPublicKey = objEncryptDecrypt.Decrypt(publicKey, encryptionPvtKey);

                encryptedCert = EncryptWithHash(certName, decryptedPublicKey);
            }
            catch (Exception exception)
            {
                //ProjectData.SetProjectError(exception);
                encryptedCert = exception.Message;
                //ProjectData.ClearProjectError();
            }

            return encryptedCert;
        }
        private static string EncryptCertString(string stringToBeEncrypt, string certificateName)
        {
            string strEncyValue = string.Empty;

            try
            {
                // get the certificate from store
                X509Certificate2 cert = GetCertificateFromStore(certificateName);

                if (cert != null)
                {
                    byte[] cipherbytes = Encoding.ASCII.GetBytes(stringToBeEncrypt.Trim());
                    RSACryptoServiceProvider rsa = (RSACryptoServiceProvider)cert.PublicKey.Key;

                    byte[] cipher = rsa.Encrypt(cipherbytes, false);
                    strEncyValue = Convert.ToBase64String(cipher);
                }
                else
                {
                    encryptorMsg = "Certificate not found or invalid certificate in use";
                    strEncyValue = encryptorMsg;
                }
            }
            catch (Exception ex)
            {
                encryptorMsg = " Error in encyption, Method- Encryptstring, Error detail:  " + ex.Message;
                throw new Exception(encryptorMsg);
            }

            return strEncyValue;
        }
        private static X509Certificate2 GetCertificateFromStore(string certName)
        {
            // Get the certificate store for the local machine.
            X509Store store = new X509Store(StoreLocation.LocalMachine);
            try
            {
                store.Open(OpenFlags.ReadOnly);
                X509Certificate2Collection certCollection = store.Certificates;

                X509Certificate2Collection currentCerts = certCollection.Find(X509FindType.FindByTimeValid, DateTime.Now, false);
                X509Certificate2Collection signingCert = currentCerts.Find(X509FindType.FindBySubjectDistinguishedName, certName, false);

                if (signingCert.Count == 0)
                {
                    signingCert = currentCerts.Find(X509FindType.FindByThumbprint, certName, false);
                }
                return signingCert.Count == 0 ? null : signingCert[0];
            }
            catch (Exception exc)
            {
                encryptorMsg = " Error in encryptor, Method- #GetCertificateFromStore#, Error details:  " + exc.Message;
                throw new Exception(encryptorMsg);
            }
            finally
            {
                store.Close();
            }
        }

        public string DecryptInput(string stringToBeDecrypted, string encryptedCertName, string publicKey)
        {
            try
            {
                decryptedPublicKey = objEncryptDecrypt.Decrypt(publicKey, encryptionPvtKey);
                decryptedCertName = objEncryptDecrypt.Decrypt(encryptedCertName, decryptedPublicKey);

                return DecryptCertString(stringToBeDecrypted, decryptedCertName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string DecryptCertString(string strstringToDecrypt, string certificateNameKeyName)
        {
            string plainText = string.Empty;
            try
            {
                // get the certificate from store   
                X509Certificate2 cert = GetCertificateFromStore(certificateNameKeyName);
                if (cert != null)
                {
                    RSACryptoServiceProvider rsa;
                    rsa = (RSACryptoServiceProvider)cert.PrivateKey;
                    byte[] dcipherbytes = Convert.FromBase64String(strstringToDecrypt);
                    byte[] plainbytes = rsa.Decrypt(dcipherbytes, false);
                    ASCIIEncoding enc = new ASCIIEncoding();
                    plainText = enc.GetString(plainbytes);
                }
                else
                {
                    plainText = "ENOC.SSB.OutProcAuthService decryption - Certificate not found or invalid certificate in use";
                }
            }
            catch (Exception ex)
            {
                //plainText = " Decryption error in ENOC.SSB.OutProcAuthServices,Method- Decryptstring, Error detail:  " + ex.Message;
                //throw new Exception(encryptorMsg);
                plainText = ex.Message;
            }
            return plainText;
        }

        private static string EncryptWithHash(string stringTobeEncrypted, string key)
        {
            try
            {
                return objEncryptDecrypt.Encrypt(stringTobeEncrypted, key);
            }
            catch (Exception encryptExc)
            {
                throw encryptExc;
            }
        }

    }
}
