namespace DynamicSendPort {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://DynamicSendPort.ResponseMsgSales",@"ResponseMsgSales")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"ResponseMsgSales"})]
    public sealed class ResponseMsgSales : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" attributeFormDefault=""unqualified"" elementFormDefault=""unqualified"" targetNamespace=""http://DynamicSendPort.ResponseMsgSales"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""ResponseMsgSales"">
    <xs:complexType>
      <xs:sequence>
        <xs:element minOccurs=""0"" name=""balance"" type=""xs:int"" />
        <xs:element minOccurs=""0"" name=""blockAccount"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""blockCustomer"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" name=""blockUser"" type=""xs:boolean"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""bonusPointTypes"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""mainBalance"" type=""xs:boolean"" />
              <xs:element minOccurs=""0"" name=""pointType"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""points"" type=""xs:int"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""bonusPoints"" type=""xs:int"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""extProducts"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""extAmount"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""extCode"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""extDiscounted"" type=""xs:boolean"" />
              <xs:element minOccurs=""0"" name=""extQuantity"" type=""xs:int"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""issuedCoupons"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""couponNumber"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""expiryDate"" type=""xs:date"" />
              <xs:element minOccurs=""0"" name=""id"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""type"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""typeName"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""loanPoints"" type=""xs:int"" />
        <xs:element minOccurs=""0"" name=""message"" type=""xs:string"" />
        <xs:element minOccurs=""0"" name=""moneyAmount"" type=""xs:int"" />
        <xs:element minOccurs=""0"" name=""moneyDiscount"" type=""xs:int"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""pointBalances"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""mainBalance"" type=""xs:boolean"" />
              <xs:element minOccurs=""0"" name=""pointType"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""points"" type=""xs:int"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""pointTypes"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""mainBalance"" type=""xs:boolean"" />
              <xs:element minOccurs=""0"" name=""pointType"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""points"" type=""xs:int"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""points"" type=""xs:int"" />
        <xs:element minOccurs=""0"" name=""transactionId"" type=""xs:int"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""usedCoupons"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" name=""couponNumber"" type=""xs:int"" />
              <xs:element minOccurs=""0"" name=""expiryDate"" type=""xs:dateTime"" />
              <xs:element minOccurs=""0"" name=""status"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""type"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""unlimitedUse"" type=""xs:boolean"" />
              <xs:element minOccurs=""0"" name=""useResult"" type=""xs:string"" />
              <xs:element minOccurs=""0"" name=""usedQuantity"" type=""xs:unsignedByte"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public ResponseMsgSales() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "ResponseMsgSales";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
