﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace FEWcfTestClient
{
    class Program
    {
        static void Main(string[] args)
        {
           // localhost.BizTalkServiceInstance client = new localhost.BizTalkServiceInstance();
            ServiceReference1.BTFrontEndServiceClient client = new ServiceReference1.BTFrontEndServiceClient();
                //BizTalkServiceInstance("WSHttpBinding_ITwoWayAsync");
            ServiceReference1.FrontendRequest FEreq = new ServiceReference1.FrontendRequest();
            FEreq.FirstName = "Siddhant";
            FEreq.LastName = "Pandey";
            FEreq.MobileNumber = "123456";


            ServiceReference1.Frontend FE = new ServiceReference1.Frontend();
            FE.Request = FEreq;


            XmlSerializer Ser1 = new XmlSerializer(FE.GetType());
            StringWriter sw = new StringWriter();
            XmlWriter writer = XmlWriter.Create(sw);

            Ser1.Serialize(writer, FE);
            Console.WriteLine("Request" + sw);

            ServiceReference1.Backend Res = client.FEOperation(FE);
 
            XmlSerializer Ser2 = new XmlSerializer(Res.GetType());
            StringWriter sw2 = new StringWriter();
            XmlWriter writer2 = XmlWriter.Create(sw2);

            Ser2.Serialize(writer2, Res);


            Console.WriteLine("----------------------------");
            Console.WriteLine("Res" + sw2);
            Console.ReadLine();

        }
    }
}

   

