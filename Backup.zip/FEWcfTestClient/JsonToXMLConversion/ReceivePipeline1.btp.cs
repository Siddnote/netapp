namespace JsonToXMLConversion
{
    using System;
    using System.Collections.Generic;
    using Microsoft.BizTalk.PipelineOM;
    using Microsoft.BizTalk.Component;
    using Microsoft.BizTalk.Component.Interop;
    
    
    public sealed class ReceivePipeline1 : Microsoft.BizTalk.PipelineOM.ReceivePipeline
    {
        
        private const string _strPipeline = "<?xml version=\"1.0\" encoding=\"utf-16\"?><Document xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instanc"+
"e\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" MajorVersion=\"1\" MinorVersion=\"0\">  <Description /> "+
" <CategoryId>f66b9f5e-43ff-4f5f-ba46-885348ae1b4e</CategoryId>  <FriendlyName>Receive</FriendlyName>"+
"  <Stages>    <Stage>      <PolicyFileStage _locAttrData=\"Name\" _locID=\"1\" Name=\"Decode\" minOccurs=\""+
"0\" maxOccurs=\"-1\" execMethod=\"All\" stageId=\"9d0e4103-4cce-4536-83fa-4a5040674ad6\" />      <Component"+
"s>        <Component>          <Name>Microsoft.BizTalk.Component.JsonDecoder,Microsoft.BizTalk.Pipel"+
"ine.Components, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35</Name>          <C"+
"omponentName>JSON decoder</ComponentName>          <Description>JSON decoder component</Description>"+
"          <Version>1.0</Version>          <Properties>            <Property Name=\"RootNode\" />      "+
"      <Property Name=\"RootNodeNamespace\" />            <Property Name=\"AddMessageBodyForEmptyMessage"+
"\">              <Value xsi:type=\"xsd:boolean\">false</Value>            </Property>          </Proper"+
"ties>          <CachedDisplayName>JSON decoder</CachedDisplayName>          <CachedIsManaged>true</C"+
"achedIsManaged>        </Component>      </Components>    </Stage>    <Stage>      <PolicyFileStage "+
"_locAttrData=\"Name\" _locID=\"2\" Name=\"Disassemble\" minOccurs=\"0\" maxOccurs=\"-1\" execMethod=\"FirstMatc"+
"h\" stageId=\"9d0e4105-4cce-4536-83fa-4a5040674ad6\" />      <Components>        <Component>          <"+
"Name>Microsoft.BizTalk.Component.XmlDasmComp,Microsoft.BizTalk.Pipeline.Components, Version=3.0.1.0,"+
" Culture=neutral, PublicKeyToken=31bf3856ad364e35</Name>          <ComponentName>XML disassembler</C"+
"omponentName>          <Description>Streaming XML disassembler</Description>          <Version>1.0</"+
"Version>          <Properties>            <Property Name=\"EnvelopeSpecNames\">              <Value xs"+
"i:type=\"xsd:string\" />            </Property>            <Property Name=\"EnvelopeSpecTargetNamespace"+
"s\">              <Value xsi:type=\"xsd:string\" />            </Property>            <Property Name=\"D"+
"ocumentSpecNames\">              <Value xsi:type=\"xsd:string\" />            </Property>            <P"+
"roperty Name=\"DocumentSpecTargetNamespaces\">              <Value xsi:type=\"xsd:string\" />           "+
" </Property>            <Property Name=\"AllowUnrecognizedMessage\">              <Value xsi:type=\"xsd"+
":boolean\">false</Value>            </Property>            <Property Name=\"ValidateDocument\">        "+
"      <Value xsi:type=\"xsd:boolean\">false</Value>            </Property>            <Property Name=\""+
"RecoverableInterchangeProcessing\">              <Value xsi:type=\"xsd:boolean\">false</Value>         "+
"   </Property>            <Property Name=\"HiddenProperties\">              <Value xsi:type=\"xsd:strin"+
"g\">EnvelopeSpecTargetNamespaces,DocumentSpecTargetNamespaces</Value>            </Property>         "+
" </Properties>          <CachedDisplayName>XML disassembler</CachedDisplayName>          <CachedIsMa"+
"naged>true</CachedIsManaged>        </Component>      </Components>    </Stage>    <Stage>      <Pol"+
"icyFileStage _locAttrData=\"Name\" _locID=\"3\" Name=\"Validate\" minOccurs=\"0\" maxOccurs=\"-1\" execMethod="+
"\"All\" stageId=\"9d0e410d-4cce-4536-83fa-4a5040674ad6\" />      <Components />    </Stage>    <Stage>  "+
"    <PolicyFileStage _locAttrData=\"Name\" _locID=\"4\" Name=\"ResolveParty\" minOccurs=\"0\" maxOccurs=\"-1\""+
" execMethod=\"All\" stageId=\"9d0e410e-4cce-4536-83fa-4a5040674ad6\" />      <Components>        <Compon"+
"ent>          <Name>ENOC.Loyalty.Integration.PipelinesComponent.AddNameSpaceComponent,ENOC.Loyalty.I"+
"ntegration.PipelinesComponent, Version=1.0.0.0, Culture=neutral, PublicKeyToken=495d07b20c9c117a</Na"+
"me>          <ComponentName>AddXMLNameSpace</ComponentName>          <Description>Pipeline component"+
" used to add namespaces to XML Element.</Description>          <Version>1.0.0.0</Version>          <"+
"Properties>            <Property Name=\"NamespacePreifix\">              <Value xsi:type=\"xsd:string\" "+
"/>            </Property>            <Property Name=\"TargetNamespace\">              <Value xsi:type="+
"\"xsd:string\" />            </Property>          </Properties>          <CachedDisplayName>AddXMLName"+
"Space</CachedDisplayName>          <CachedIsManaged>true</CachedIsManaged>        </Component>      "+
"</Components>    </Stage>  </Stages></Document>";
        
        private const string _versionDependentGuid = "7d8f474f-9e1e-4518-bd2a-632fd51ae682";
        
        public ReceivePipeline1()
        {
            Microsoft.BizTalk.PipelineOM.Stage stage = this.AddStage(new System.Guid("9d0e4103-4cce-4536-83fa-4a5040674ad6"), Microsoft.BizTalk.PipelineOM.ExecutionMode.all);
            IBaseComponent comp0 = Microsoft.BizTalk.PipelineOM.PipelineManager.CreateComponent("Microsoft.BizTalk.Component.JsonDecoder,Microsoft.BizTalk.Pipeline.Components, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");;
            if (comp0 is IPersistPropertyBag)
            {
                string comp0XmlProperties = "<?xml version=\"1.0\" encoding=\"utf-16\"?><PropertyBag xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-inst"+
"ance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">  <Properties>    <Property Name=\"RootNode\" />   "+
" <Property Name=\"RootNodeNamespace\" />    <Property Name=\"AddMessageBodyForEmptyMessage\">      <Valu"+
"e xsi:type=\"xsd:boolean\">false</Value>    </Property>  </Properties></PropertyBag>";
                PropertyBag pb = PropertyBag.DeserializeFromXml(comp0XmlProperties);;
                ((IPersistPropertyBag)(comp0)).Load(pb, 0);
            }
            this.AddComponent(stage, comp0);
            stage = this.AddStage(new System.Guid("9d0e4105-4cce-4536-83fa-4a5040674ad6"), Microsoft.BizTalk.PipelineOM.ExecutionMode.firstRecognized);
            IBaseComponent comp1 = Microsoft.BizTalk.PipelineOM.PipelineManager.CreateComponent("Microsoft.BizTalk.Component.XmlDasmComp,Microsoft.BizTalk.Pipeline.Components, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");;
            if (comp1 is IPersistPropertyBag)
            {
                string comp1XmlProperties = "<?xml version=\"1.0\" encoding=\"utf-16\"?><PropertyBag xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-inst"+
"ance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">  <Properties>    <Property Name=\"EnvelopeSpecNam"+
"es\">      <Value xsi:type=\"xsd:string\" />    </Property>    <Property Name=\"EnvelopeSpecTargetNamesp"+
"aces\">      <Value xsi:type=\"xsd:string\" />    </Property>    <Property Name=\"DocumentSpecNames\">   "+
"   <Value xsi:type=\"xsd:string\" />    </Property>    <Property Name=\"DocumentSpecTargetNamespaces\"> "+
"     <Value xsi:type=\"xsd:string\" />    </Property>    <Property Name=\"AllowUnrecognizedMessage\">   "+
"   <Value xsi:type=\"xsd:boolean\">false</Value>    </Property>    <Property Name=\"ValidateDocument\"> "+
"     <Value xsi:type=\"xsd:boolean\">false</Value>    </Property>    <Property Name=\"RecoverableInterc"+
"hangeProcessing\">      <Value xsi:type=\"xsd:boolean\">false</Value>    </Property>    <Property Name="+
"\"HiddenProperties\">      <Value xsi:type=\"xsd:string\">EnvelopeSpecTargetNamespaces,DocumentSpecTarge"+
"tNamespaces</Value>    </Property>  </Properties></PropertyBag>";
                PropertyBag pb = PropertyBag.DeserializeFromXml(comp1XmlProperties);;
                ((IPersistPropertyBag)(comp1)).Load(pb, 0);
            }
            this.AddComponent(stage, comp1);
            stage = this.AddStage(new System.Guid("9d0e410e-4cce-4536-83fa-4a5040674ad6"), Microsoft.BizTalk.PipelineOM.ExecutionMode.all);
            IBaseComponent comp2 = Microsoft.BizTalk.PipelineOM.PipelineManager.CreateComponent("ENOC.Loyalty.Integration.PipelinesComponent.AddNameSpaceComponent,ENOC.Loyalty.Integration.PipelinesComponent, Version=1.0.0.0, Culture=neutral, PublicKeyToken=495d07b20c9c117a");;
            if (comp2 is IPersistPropertyBag)
            {
                string comp2XmlProperties = "<?xml version=\"1.0\" encoding=\"utf-16\"?><PropertyBag xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-inst"+
"ance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">  <Properties>    <Property Name=\"NamespacePreifi"+
"x\">      <Value xsi:type=\"xsd:string\" />    </Property>    <Property Name=\"TargetNamespace\">      <V"+
"alue xsi:type=\"xsd:string\" />    </Property>  </Properties></PropertyBag>";
                PropertyBag pb = PropertyBag.DeserializeFromXml(comp2XmlProperties);;
                ((IPersistPropertyBag)(comp2)).Load(pb, 0);
            }
            this.AddComponent(stage, comp2);
        }
        
        public override string XmlContent
        {
            get
            {
                return _strPipeline;
            }
        }
        
        public override System.Guid VersionDependentGuid
        {
            get
            {
                return new System.Guid(_versionDependentGuid);
            }
        }
    }
}
