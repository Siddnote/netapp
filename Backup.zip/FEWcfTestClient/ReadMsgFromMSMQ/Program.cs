﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Messaging;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ReadMsgFromMSMQ
{
    class Program
    {
       



        public static void Main(string[] args)
        {
            MessageQueue msgQ = new MessageQueue(".\\Private$\\TEST");

            MessageQueue queue = new MessageQueue(@".\private$\TEST");
            var messages = queue.GetAllMessages();
            var messagesToDelete = messages.ToList();
            string[,] Messages = new string[messages.Length, 5];
            ReadQueue(".\\Private$\\TEST");




        }

        private static List<string> ReadQueue(string path)

        {

            List<string> lstMessages = new List<string>();

            using (MessageQueue messageQueue = new MessageQueue(path))

            {

                System.Messaging.Message[] messages = messageQueue.GetAllMessages();

                foreach (System.Messaging.Message message in messages)

                {
                    
                   message.Formatter = new BinaryMessageFormatter();

                    //string msg = BinaryToString(message.Body);
                    Stream ms = message.BodyStream;
                    StreamReader reader = new StreamReader(ms);
                    string text = reader.ReadToEnd();
                     lstMessages.Add(text);

                }

            }

            return lstMessages;

        }


        public static string BinaryToString(string data)
        {
            List<Byte> byteList = new List<Byte>();
            for (int i = 0; i < data.Length; i += 8)
            {
                byteList.Add(Convert.ToByte(data.Substring(i, 8), 2));
            }
            return Encoding.ASCII.GetString(byteList.ToArray());
        }
    } 
}
