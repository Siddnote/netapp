﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using Microsoft.BizTalk.Component.Interop;
using Microsoft.BizTalk.Message.Interop;
using System.IO;
using System.Xml;
using Microsoft.BizTalk.Streaming;
using Microsoft.BizTalk.XPath;

namespace HtttpDecoderReceivePipelineComponent
{

    [ComponentCategory(CategoryTypes.CATID_PipelineComponent)]
    [ComponentCategory(CategoryTypes.CATID_Any)]
    [System.Runtime.InteropServices.Guid("C726F9E4-9DC6-46B1-B927-CC0B2077C22C")]

    public class HtttpDecoderReceivePipeline : IBaseComponent, IComponentUI, Microsoft.BizTalk.Component.Interop.IComponent, IPersistPropertyBag
    {
        private string _Namespace = string.Empty;
        private string _ProcCode = string.Empty;
        private string _SIDNameSpace = string.Empty;

        private bool _enabled = false;

        IBaseMessagePart msgPart;
        string textProperty = string.Empty;

        Dictionary<string, string> _Replacements = new Dictionary<string, string>();

        #region properties

        [Description("Property containing the Configurable option to add namespace")]
        public string Namespace
        {
            get
            {
                return _Namespace;
            }
            set
            {
                _Namespace = value;
            }
        }

        [Description("Property containing the ProcCode to be replaced")]
        public string ProcCode
        {
            get
            {
                return _ProcCode;
            }
            set
            {
                _ProcCode = value;
            }
        }

        [Description("Property containing the SIDNameSpace to be replaced")]
        public string SIDNameSpace
        {
            get
            {
                return _SIDNameSpace;
            }
            set
            {
                _SIDNameSpace = value;
            }
        }

        [Description("Property saying if the replacement should be done or not")]
        public bool Enabled
        {
            get
            {
                return _enabled;
            }
            set
            {
                _enabled = value;
            }
        }

        #endregion properties

        #region Description of the pipeline component
        public string Description
        {
            get { return "This is a genric Pipeline Component to HtttpDecoderReceive the Message"; }
        }

        public string Name
        {
            get { return "HtttpDecoderReceivePipelineComponent"; }
        }

        public string Version
        {
            get { return "1.0.0.0"; }
        }
        #endregion

        #region IComponentUI Members

        public IntPtr Icon
        {
            get { return System.IntPtr.Zero; }
        }

        public System.Collections.IEnumerator Validate(object projectSystem)
        {
            return null;
        }

        #endregion

        #region IPersistPropertyBag Members

        public void GetClassID(out Guid classID)
        {
            classID = new System.Guid("C726F9E4-9DC6-46B1-B927-CC0B2077C22C");
        }

        public void InitNew()
        {
        }

        public void Load(IPropertyBag propertyBag, int errorLog)
        {
            object val = null;

            val = this.ReadPropertyBag(propertyBag, "Namespace");
            if ((val != null))
            {
                this._Namespace = ((string)(val));
            }

            val = null;

            val = this.ReadPropertyBag(propertyBag, "ProcCode");
            if ((val != null))
            {
                this._ProcCode = ((string)(val));
            }

            val = null;

            val = this.ReadPropertyBag(propertyBag, "SIDNameSpace");
            if ((val != null))
            {
                this._SIDNameSpace = ((string)(val));
            }

            val = null;

            val = this.ReadPropertyBag(propertyBag, "Enabled");
            if ((val != null))
            {
                this._enabled = ((bool)(val));
            }
        }

        public void Save(IPropertyBag propertyBag, bool clearDirty, bool saveAllProperties)
        {
            WritePropertyBag(propertyBag, "Namespace", Namespace);
            WritePropertyBag(propertyBag, "ProcCode", ProcCode);
            WritePropertyBag(propertyBag, "SIDNameSpace", SIDNameSpace);
            WritePropertyBag(propertyBag, "Enabled", Enabled);
        }

        #region utility functionality
        /// <summary>
        /// Reads property value from property bag
        /// </summary>
        /// <param name="pb">Property bag</param>
        /// <param name="propName">Name of property</param>
        /// <returns>Value of the property</returns>
        private object ReadPropertyBag(Microsoft.BizTalk.Component.Interop.IPropertyBag pb, string propName)
        {
            object val = null;
            try
            {
                pb.Read(propName, out val, 0);
            }
            catch (System.ArgumentException)
            {
                return val;
            }
            catch (System.Exception e)
            {
                throw new System.ApplicationException(e.Message);
            }
            return val;
        }

        /// <summary>
        /// Writes property values into a property bag.
        /// </summary>
        /// <param name="pb">Property bag.</param>
        /// <param name="propName">Name of property.</param>
        /// <param name="val">Value of property.</param>
        private void WritePropertyBag(Microsoft.BizTalk.Component.Interop.IPropertyBag pb, string propName, object val)
        {
            try
            {
                pb.Write(propName, ref val);
            }
            catch (System.Exception e)
            {
                throw new System.ApplicationException(e.Message);
            }
        }
        #endregion

        #endregion

        #region  IComponent Members

        public IBaseMessage Execute(IPipelineContext pContext, IBaseMessage pInMsg)
        {


            IBaseMessagePart bodyPart = pInMsg.BodyPart;
            MemoryStream memStream = new MemoryStream();
            string systemPropertyNameSpace = Namespace;
            string SIDNameSPACE = SIDNameSpace;

            IBaseMessageContext originalMessageContext;
            string pMessageType = string.Empty;
            string RRNFinalValue = string.Empty;
            String SessionId = string.Empty;
            msgPart = pInMsg.BodyPart;
            Stream originalStream = pInMsg.BodyPart.GetOriginalDataStream();
            try
            {
                if (msgPart != null && Enabled)
                {
                    if (originalStream != null)
                    {

                        XmlDocument xdocc = new XmlDocument();
                        xdocc.Load(originalStream);
                        originalMessageContext = PipelineUtil.CloneMessageContext(pInMsg.Context);


                        #region
                        String RootNode = xdocc.DocumentElement.Name;
                        pMessageType = RootNode;

                        String ErrorNO = @"/*[local-name()='" + RootNode + "' and namespace-uri()='']/*[local-name()='ENVELOPE' and namespace-uri()='']/@*[local-name()='ERRORNO' and namespace-uri()='']";
                        XmlNode ErrorNoValue = xdocc.SelectSingleNode(ErrorNO);
                        String ErrorNum = ErrorNoValue.InnerText;

                        if ((ErrorNum == "") || (ErrorNum == "0"))
                        {
                            ErrorNum = "000";

                            String SessionIdxpath = @"/*[local-name()='" + RootNode + "' and namespace-uri()='']/*[local-name()='ENVELOPE' and namespace-uri()='']/@*[local-name()='SESSIONID' and namespace-uri()='']";
                            String proccodeNum = @"/*[local-name()='" + RootNode + "' and namespace-uri()='']/*[local-name()='ENVELOPE' and namespace-uri()='']/@*[local-name()='PROCCODE' and namespace-uri()='']";
                            String xpathofEnvelope = @"/*[local-name()='" + RootNode + "' and namespace-uri()='']/*[local-name()='ENVELOPE' and namespace-uri()='']";
                            String xpathofstringinput = @"/*[local-name()='" + RootNode + "' and namespace-uri()='']/*[local-name()='BODY' and namespace-uri()='']/*[local-name()='XML' and namespace-uri()='']/*[local-name()='SOAPMessage' and namespace-uri()='']/*[local-name()='Envelope' and namespace-uri()='http://schemas.xmlsoap.org/soap/envelope/']/*[local-name()='Body' and namespace-uri()='http://schemas.xmlsoap.org/soap/envelope/']/*[local-name()='callCHWResponse' and namespace-uri()='http://auth.org']/*[local-name()='StringOutput' and namespace-uri()='http://auth.org']";

                            XmlNode stringSession = xdocc.SelectSingleNode(SessionIdxpath);
                            SessionId = stringSession.InnerXml;

                            XmlNode stringInputNode = xdocc.SelectSingleNode(xpathofstringinput);
                            XmlNode ProCode = xdocc.SelectSingleNode(proccodeNum);
                            String ProcNum = ProCode.InnerXml;

                            XmlNode stringInputEnvelope = xdocc.SelectSingleNode(xpathofEnvelope);
                            String EnvelopeOld = stringInputEnvelope.OuterXml;

                            String NewEnvelope = EnvelopeOld.Substring(0, EnvelopeOld.Length) + "";
                            String output = stringInputNode.InnerXml;

                            String EncodedString = System.Web.HttpUtility.HtmlDecode(output);
                            //String FinalReqMsg = "<" + RootNode + ">" + NewEnvelope + "<BODY>" + "<XML><MessageType>1210</MessageType><ProcCode>" + ProcNum + "</ProcCode><ActCode>000</ActCode>" + EncodedString + "</XML>" + "</BODY>" + "</" + RootNode + ">";

                            String FinalReqMsg = "<" + RootNode + ">" + NewEnvelope + "<BODY>" + "<XML><MessageType>1210</MessageType><ProcCode>" + ProcCode + "</ProcCode><ActCode>" + ErrorNum + "</ActCode>" + EncodedString + "</XML>" + "</BODY>" + "</" + RootNode + ">";
                            byte[] buffer = System.Text.Encoding.ASCII.GetBytes(FinalReqMsg);


                            String Packet = FinalReqMsg;

                            //string[] StringSeprator = new string[] { "<RRN>" };
                            //string[] RRNArray = Packet.Split(StringSeprator, StringSplitOptions.None);
                            //string[] RRNSeprator = new string[] { "</RRN>" };
                            //string[] RRNValue = RRNArray[1].Split(RRNSeprator, StringSplitOptions.None);
                            //RRNFinalValue = RRNValue[0];

                            memStream.Write(buffer, 0, buffer.Length);
                            memStream.Position = 0;
                            //  System.Diagnostics.EventLog.WriteEntry("RRnValue", RRNFinalValue);
                        }
                        else
                        {
                            String FinalReqMsg = xdocc.InnerXml;

                            String xpathofEnvelope = @"/*[local-name()='" + RootNode + "' and namespace-uri()='']/*[local-name()='ENVELOPE' and namespace-uri()='']";
                            XmlNode stringInputEnvelope = xdocc.SelectSingleNode(xpathofEnvelope);
                            String EnvelopeOld = stringInputEnvelope.OuterXml;
                            String NewEnvelope = EnvelopeOld.Substring(0, EnvelopeOld.Length) + "";
                            String ErrMsg = "<SOAPMessage><env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\"><env:Header /><env:Body><m:callCHWResponse xmlns:m=\"http://auth.org\"><m:StringOutput><CMSCHWService xmlns=\"http://xml.netbeans.org/schema/CMSCHWService\"><Header><Version>1.0</Version><SrcApp></SrcApp><TargetApp></TargetApp><SrcMsgId></SrcMsgId><TranTimeStamp></TranTimeStamp></Header><Body><CHWRes><TranCde>010</TranCde><RRN>000000000000000</RRN><RespCode>BE_ERROR</RespCode><RespData>Invalid Delivery Channel</RespData></CHWRes></Body></CMSCHWService></m:StringOutput></m:callCHWResponse></env:Body></env:Envelope></SOAPMessage>";
                            String FinalErrMsg = "<" + RootNode + ">" + NewEnvelope + "<BODY>" + "<XML><MessageType>1210</MessageType><ProcCode>" + ProcCode + "</ProcCode><ActCode>" + ErrorNum + "</ActCode>" + ErrMsg + "</XML>" + "</BODY>" + "</" + RootNode + ">";

                            String SessionIdxpath = @"/*[local-name()='" + RootNode + "' and namespace-uri()='']/*[local-name()='ENVELOPE' and namespace-uri()='']/@*[local-name()='SESSIONID' and namespace-uri()='']";
                            XmlNode stringSession = xdocc.SelectSingleNode(SessionIdxpath);
                            SessionId = stringSession.InnerXml;


                            //string[] StringSeprator = new string[] { "<RRN>" };
                            //string[] RRNArray = FinalErrMsg.Split(StringSeprator, StringSplitOptions.None);
                            //string[] RRNSeprator = new string[] { "</RRN>" };
                            //string[] RRNValue = RRNArray[1].Split(RRNSeprator, StringSplitOptions.None);

                            //RRNFinalValue = RRNValue[0];

                            byte[] buffer = System.Text.Encoding.ASCII.GetBytes(FinalErrMsg);
                            memStream.Write(buffer, 0, buffer.Length);
                            memStream.Position = 0;
                        }

                        for (int i = 0; i < originalMessageContext.CountProperties; i++)
                        {
                            string strName;
                            string strNSpace;

                            object val = originalMessageContext.ReadAt(i, out strName, out strNSpace);

                            if (originalMessageContext.IsPromoted(strName, strNSpace))
                            {
                                pInMsg.Context.Promote(strName, strNSpace, val);

                            }
                            else
                                pInMsg.Context.Write(strName, strNSpace, val);
                        }

                        #endregion
                    }

                }
                else
                {
                    System.Diagnostics.EventLog.WriteEntry("Application", "Pipeline Configuration Error");

                }

            }
            catch (Exception)
            {
                throw;
            }

            pInMsg.Context.Write("SESSIONID", SIDNameSPACE, SessionId);
            pInMsg.Context.Promote("SESSIONID", SIDNameSPACE, SessionId);
            pInMsg.Context.Promote("MessageType", systemPropertyNameSpace, pMessageType);
            pContext.ResourceTracker.AddResource(memStream);
            IBaseMessage outMsg = pInMsg;
            outMsg.BodyPart.Data = memStream;
            return outMsg;
        }

        #endregion



    }
}
