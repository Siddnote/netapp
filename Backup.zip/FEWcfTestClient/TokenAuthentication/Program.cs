﻿using Cryptography;
using ENOC.SSB.CertEncryptor;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace TokenAuthentication
{
    static class Program
    {
        static string address = "https://pos-enoc-uat.clm-comarch.com/oauth/token?grant_type=client_credentials&client_id=ws&client_secret=ws&scope=any";
        static string NamespacePreifix = string.Empty;
        static string TargetNamespace = string.Empty;
        static void Main(string[] args)
        {
            //string UserName = "Xj2P2CfwRZswZyVvO5y87GsLsqbTGB4g993W9xLdk83+wW4i4VO8Jd3a7H2ZgZDvOGkviYNDBijhrmgDPB2fVKzpGkb7OSmHz/waJUcvyyVNUhtgD6EC7amBeFicclnQ8wzbtfPLHmJTbrMchHKCqna9awwZeXHW1kW376DjZdtQU2/tTfzymkl6qtZhOEfuNEv1K8Ud7kHWc7sKGh+4E50CgT3rodlj2ppYPUSnUwUPa2OdhFwRgluFSefX27QwcClsVtQCbVLoGMIaTTFsoZDGxPg6CK3bsx20ldSXvpbYSsfP870aWrhexjTZiu0XJpsft/iuPpW8LRKLnX//LA==0001";
            //string Password = "GoAcQ4llHP77XgNpL83plDKjRaV3Z3ygWu2hqRMi+nK2A9XIq9NGnPaE+sF1xDJHijpLjuFB2lAaFhXa/IkFDPKI9OCdvOm99wqoK0o/Dp9FYtbvZGz4RneICF3F/6+VrJNbK6lWGPQzvjUbS6aMH9RTMmI4E3KicVDv1cHbe3p/d3yL1isFIVTdP4Fs0Pr3qFIZkFsahmlh+0N/NrQqASK6sqkkxhxmxUudg1AIJpK5xEJV+FwADEhu6gC4jFi7qxIySzmSdXgyteoFqbuyl55yfVeEKvQsi6QVLEfqye3UZVdG8aZWuRC/jbzFXkPKEDpikfqTaMgq6AGko8vhjg==";

            // Validate8(UserName, Password);

            // DateTime date = DateTime.Now;
            //// DateTime date = DateTime.Now.ToUniversalTime();
            //string DATETIME = String.Format("{0:G}", DateTime.Now);
            // string newDate =    GetXMLFromObject(DATETIME);
            //SalesLocationCode("000598", "ZOOM");

            //XmlDocument doc = new XmlDocument();
            //doc.Load("file:///D:/Siddhant/Test/MapTest/SoftEnrollment.xml");
            //XmlNodeList xnList = doc.SelectNodes("./CLMProfileServiceValidateMemberRequest/loyaltyId");



            //string code = File.ReadAllText(@"D:\Siddhant\Test\MapTest\Error.txt");
            //CodeCheck(code);
            //string tem = "<ns0:NACK Type =\"NACK\" xmlns:ns0=\"http://schema.microsoft.com/BizTalk/2003/NACKMessage.xsd\"><NAckID>{5889F224-DC98-44D0-A846-A4B7077A2F5F}</NAckID><ErrorCode>0xc0c0167a</ErrorCode><ErrorCategory>0</ErrorCategory><ErrorDescription>System.Net.WebException: There was no endpoint listening at https://pos-enoc-uat.clm-comarch.com/b2b/profile/validate-otp?otp=%3f that could accept the message. This is often caused by an incorrect address or SOAP action. See InnerException, if present, for more details.\r\n{\"error\":\"NOT_FOUND\",\"message\":\"Resource with id '?' not found\",\"path\":\"/b2b/profile/validate-otp\",\"requestToken\":\"1568721737730136\",\"status\":404,\"timestamp\":\"2019-09-17T12:02:12.062Z\"}</ErrorDescription></ns0:NACK>";
            //XmlDocument xdoc = Exception(tem);
            //string a = xdoc.InnerXml;
            //GetToken();
            //UpdateToken();
            //DisableToken();
            //MyWebRequest myRequest = new MyWebRequest(address, "POST");       
            //JObject JsonRes= myRequest.GetResponse();
            //string accesstoken = JsonRes["access_token"].ToString();
            //string inpuvalue = System.IO.File.ReadAllText("test.txt");
            //XmlDocument SoftEnrollment = GetHttpHeaderValues(inpuvalue, "enrollment");
            //Console.WriteLine(SoftEnrollment.InnerXml.ToString());
            //Console.ReadLine();
            //    string OutVal= AppStatus("customerscobrands");

            // string Key = "M0ul/SCLI+HUH9vA3Zv3Hs+T+ejTzrrryYi9++AGo1k=";
            // string ClientCertificate = "G0od8T8ZKqNH4W43YAZAg8eEibgMhp1mVPEwagPQ68V9ZHeQNuX2fe4dXu6YAgO6ATqjmgDx8KvOXRQe8lqg+N99BAyq6316IvjS1zA4r0YRKa8PObsIvG5fBjQEj37N";
            //// string UserName1 = "QVh9WugRJQDkGmGD3wcTirc44omHJfYzw9Pas+8ws4/Biyx3vUKehL34ebpOnMF3SOuNntlvTPz3spV5J3GqzEV1DZpOIaqzwy5TyanOwZTiUF1guwWEXwpUf/tlad0LZ6KkY9Gd2EkxAOhGhoxaWA9L4NZNs3CWNytLvXhiL/a6gA5+XAuP6HifH511RpSo97Ou2HA+0lwa+YF8NB54ZPxbondaq3CIxcl4zUjLecRoJT+Zym/A13uwitJlkj59+uCu0RbiiHxwcMMH3GMubKaGi4IVkTiN44ro1B7DAbniZXVNaPocu4FYpeWz86i+5RQoZilSx+IiZQqgTAtSQg==";

            //// Decrypt(UserName, Key);

            // Encryptor enc = new Encryptor();
            // string U = enc.EncryptUsingCertificateName("UserName", ClientCertificate, Key);
            //   string Value =  enc.DecryptInput(U, ClientCertificate, Key);

            TrnProTrace(@"D:\Siddhant\WorkLocation\FEWcfTestClient\TokenAuthentication\Request.xml", @"D:\Siddhant\WorkLocation\FEWcfTestClient\TokenAuthentication\Response.xml");


            //string date = DateTime.Now.ToString("yyyy-MM-dd");
            //PointsRefundTrace(@"D:\Siddhant\Test\Messages\ReversalReq.xml", @"D:\Siddhant\Test\Messages\ReversalRes.xml");
            //PointsRefundTrace(@"D:\Siddhant\Test\Messages\ReturnReq.xml", @"D:\Siddhant\Test\Messages\ReturnRes.xml");

        }
        public static void PointsRefundTrace(string Req, string Res)
        {
            string RequestID, CompanyID, SiteNo, CLMTrnxID, PointsEarned, CLMTrnxTypeVal;
            RequestID = CompanyID = SiteNo = CLMTrnxID = PointsEarned = CLMTrnxTypeVal = string.Empty;
            try
            {

                string CreatedBy = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                XmlDocument Reqdoc = new XmlDocument(); Reqdoc.Load(Req);
                XmlDocument Resdoc = new XmlDocument(); Resdoc.Load(Res);
                XmlNode xCLMTrnxType = Reqdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceRequestRecord' and namespace-uri()='']/*[local-name()='CLM_METHOD' and namespace-uri()='']");
                string CLMTrnxType = string.Empty; CLMTrnxType = (xCLMTrnxType != null) ? xCLMTrnxType.InnerText : "";

                if (CLMTrnxType == "reverse")
                {
                    CLMTrnxTypeVal = "REVERSE";
                    RequestID = Reqdoc.SelectSingleNode("//RequestId").InnerText;
                    CompanyID = Reqdoc.SelectSingleNode("//CompanyCode").InnerText;
                    SiteNo = Reqdoc.SelectSingleNode("//SiteNo").InnerText;

                    XmlNode xCLMTrnxID = Resdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceResponseRecord' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMTransactionProcessorServiceTransactionIdReverseResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdReverseResponse']/*[local-name()='transactionId' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdReverseResponse']");
                    CLMTrnxID = string.Empty; CLMTrnxID = (xCLMTrnxID != null) ? xCLMTrnxID.InnerText : "";

                    XmlNode xPoint = Resdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceResponseRecord' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMTransactionProcessorServiceTransactionIdReverseResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdReverseResponse']/*[local-name()='points' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdReverseResponse']");
                    PointsEarned = string.Empty; PointsEarned = (xPoint != null) ? xPoint.InnerText : "";
                }
                else if (CLMTrnxType == "salesreturn")
                {
                    CLMTrnxTypeVal = "SALES-RETURN";
                    RequestID = Reqdoc.SelectSingleNode("//RequestId").InnerText;
                    CompanyID = Reqdoc.SelectSingleNode("//CompanyCode").InnerText;
                    SiteNo = Reqdoc.SelectSingleNode("//SiteNo").InnerText;

                    XmlNode xCLMTrnxID = Resdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceResponseRecord' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMTransactionProcessorServiceProductReturnResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceProductReturnResponse']/*[local-name()='transactionId' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceProductReturnResponse']");
                    CLMTrnxID = string.Empty; CLMTrnxID = (xCLMTrnxID != null) ? xCLMTrnxID.InnerText : "";

                    XmlNode xPoint = Resdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceResponseRecord' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMTransactionProcessorServiceProductReturnResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceProductReturnResponse']/*[local-name()='points' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceProductReturnResponse']");
                    PointsEarned = string.Empty; PointsEarned = (xPoint != null) ? xPoint.InnerText : "";
                }

                ClassConnectionString strcon = new ClassConnectionString();
                strcon.connectionString();
                string query = "Insert INTO [dbo].[ELT_LoyaltySales] (RequestID,CompanyID,CLMTrnxID,CLMTrnxType,SiteNo,PointsEarned,BusinessDate,CreatedBy,CreatedDate) VALUES (@RequestID,@CompanyID,@CLMTrnxID,@CLMTrnxType,@SiteNo,@PointsEarned,@BusinessDate,@CreatedBy,@CreatedDate)";

                using (SqlCommand cmd = new SqlCommand(query, strcon.conConnect))
                {
                    strcon.conConnect.Open();
                    cmd.Parameters.AddWithValue("@RequestID", RequestID);
                    cmd.Parameters.AddWithValue("@CompanyID", CompanyID);

                    cmd.Parameters.AddWithValue("@CLMTrnxID", CLMTrnxID);
                    cmd.Parameters.AddWithValue("@CLMTrnxType", CLMTrnxTypeVal);

                    cmd.Parameters.AddWithValue("@SiteNo", SiteNo);
                    cmd.Parameters.AddWithValue("@PointsEarned", PointsEarned);

                    cmd.Parameters.AddWithValue("@BusinessDate", DateTime.Now.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                    cmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                    cmd.ExecuteNonQuery();
                    strcon.conConnect.Close();
                }
            }

            catch (Exception ex)
            {
                //  WriteLogtoFile("TranProReverseTrace", ex.InnerException.ToString());
            }

        }
        public static void TrnProTrace(string Req, string Res)
        {
            XmlDocument Resdoc = new XmlDocument();
            Resdoc.Load(Res);

            XmlNode xCLMTrnxID = Resdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceResponseRecord' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesReturnResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesReturnResponse']/*[local-name()='transactionId' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesReturnResponse']");
            string CLMTrnxID = string.Empty; CLMTrnxID = (xCLMTrnxID != null) ? xCLMTrnxID.InnerText : "";
            if (CLMTrnxID != "")
            {
                string PointsEarned = string.Empty;
                string PointsRedeemed = string.Empty;
                string ENOCTrnxID = string.Empty;
                XmlDocument Reqdoc = new XmlDocument();
                Reqdoc.Load(Req);

                string RequestID = Reqdoc.SelectSingleNode("//RequestId").InnerText;
                string CompanyID = Reqdoc.SelectSingleNode("//CompanyCode").InnerText;
                string SiteNo = Reqdoc.SelectSingleNode("//SiteNo").InnerText;
                string LoyaltyID = Reqdoc.SelectSingleNode("//SaleRequest/identifierId").InnerText;

                XmlNodeList xENOCTrnxID = Reqdoc.SelectNodes("/*[local-name()='TransactionProcessorServiceRequestRecord' and namespace-uri()='']/*[local-name()='SaleRequest' and namespace-uri()='']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesRequest' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesRequest']/*[local-name()='attributes' and namespace-uri()='']");
                if (xENOCTrnxID != null)
                {
                    foreach (XmlNode node in xENOCTrnxID)
                    {
                        string text = node.FirstChild.InnerText;
                        if (text.Equals("enocTrnId"))
                        {
                            ENOCTrnxID = node.LastChild.InnerText;
                        }
                    }
                }

                XmlNode xPoint = Resdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceResponseRecord' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesReturnResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesReturnResponse']/*[local-name()='points' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesReturnResponse']");
                string Point = string.Empty; Point = (xPoint != null) ? xPoint.InnerText : "";


                XmlNode xCLMTrnxType = Reqdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceRequestRecord' and namespace-uri()='']/*[local-name()='SaleRequest' and namespace-uri()='']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesRequest' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesRequest']/*[local-name()='extTransactionTypeName' and namespace-uri()='']");
                string CLMTrnxType = string.Empty; CLMTrnxType = (xCLMTrnxType != null) ? xCLMTrnxType.InnerText : "";
                if (CLMTrnxType == "ACCRUAL_FUEL" || CLMTrnxType == "ACCRUAL_NON_FUEL")
                {
                    PointsEarned = Point; PointsRedeemed = "";
                }
                else
                {
                    PointsEarned = ""; PointsRedeemed = Point;

                }

                XmlNode xLocation = Reqdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceRequestRecord' and namespace-uri()='']/*[local-name()='SaleRequest' and namespace-uri()='']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesRequest' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesRequest']/*[local-name()='partner' and namespace-uri()='']");
                string Location = string.Empty; Location = (xLocation != null) ? xLocation.InnerText : "";

                XmlNode xPartner = Reqdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceRequestRecord' and namespace-uri()='']/*[local-name()='SaleRequest' and namespace-uri()='']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesRequest' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesRequest']/*[local-name()='partner' and namespace-uri()='']");
                string Partner = string.Empty; Partner = (xPartner != null) ? xPartner.InnerText : "";

                XmlNode xTranDate = Reqdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceRequestRecord' and namespace-uri()='']/*[local-name()='SaleRequest' and namespace-uri()='']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesRequest' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesRequest']/*[local-name()='date' and namespace-uri()='']");
                string transactiondate = string.Empty; transactiondate = (xTranDate != null) ? xTranDate.InnerText : "";
                if (transactiondate != "")
                {
                    DateTime Date = Convert.ToDateTime(transactiondate);
                    transactiondate = Date.ToString();
                }


                XmlNode xBusinessDate = Reqdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceRequestRecord' and namespace-uri()='']/*[local-name()='SaleRequest' and namespace-uri()='']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesRequest' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesRequest']/*[local-name()='extBusinessDate' and namespace-uri()='']");
                string BusinessDate = string.Empty; BusinessDate = (xBusinessDate != null) ? xBusinessDate.InnerText : "";


                string CreatedBy = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

                ClassConnectionString strcon = new ClassConnectionString();
                strcon.connectionString();
                string query = "Insert INTO [dbo].[ELT_LoyaltySales] (RequestID,CompanyID,LoyaltyID,ENOCTrnxID,CLMTrnxID,CLMTrnxType,Partner,Location,SiteNo,PointsEarned,PointsRedeemed,BusinessDate,TransactionDate,CreatedBy,CreatedDate) VALUES (@RequestID,@CompanyID,@LoyaltyID,@ENOCTrnxID,@CLMTrnxID,@CLMTrnxType,@Partner,@Location,@SiteNo,@PointsEarned,@PointsRedeemed,@BusinessDate,@TransactionDate,@CreatedBy,@CreatedDate)";

                using (SqlCommand cmd = new SqlCommand(query, strcon.conConnect))
                {
                    strcon.conConnect.Open();
                    cmd.Parameters.AddWithValue("@RequestID", RequestID);
                    cmd.Parameters.AddWithValue("@CompanyID", CompanyID);
                    cmd.Parameters.AddWithValue("@LoyaltyID", LoyaltyID);
                    cmd.Parameters.AddWithValue("@ENOCTrnxID", ENOCTrnxID);
                    cmd.Parameters.AddWithValue("@CLMTrnxID", CLMTrnxID);
                    cmd.Parameters.AddWithValue("@CLMTrnxType", CLMTrnxType);
                    cmd.Parameters.AddWithValue("@Partner", Partner);
                    cmd.Parameters.AddWithValue("@Location", Location);
                    cmd.Parameters.AddWithValue("@SiteNo", SiteNo);
                    cmd.Parameters.AddWithValue("@PointsEarned", PointsEarned);
                    cmd.Parameters.AddWithValue("@PointsRedeemed", PointsRedeemed);
                    cmd.Parameters.AddWithValue("@BusinessDate", BusinessDate);
                    cmd.Parameters.AddWithValue("@TransactionDate", transactiondate);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                    cmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                    cmd.ExecuteNonQuery();
                    strcon.conConnect.Close();

                }
            }


        }

        public static string SalesLocationCode(string location, string Partner)
        {

            string Locationcode = string.Empty;
            ClassConnectionString strcon = new ClassConnectionString();
            strcon.connectionString();
            SqlCommand command = new SqlCommand("Select LocationCode from [LoyaltyDB].[dbo].[ELM_SiteMaster] mstr with(nolock)  inner join [LoyaltyDB].[dbo].[ELM_BrandMaster] brnd on mstr.BrandMasterId=brnd.RID and mstr.EnocSiteNo='" + location + "' and brnd.PartnerCode='" + Partner + "'", strcon.conConnect);
            strcon.conConnect.Open();

            SqlDataReader myDataReader = command.ExecuteReader();
            while (myDataReader.Read())
            {

                string Code = myDataReader.GetValue(0).ToString();

                if (Code != null)
                {
                    Locationcode = myDataReader.GetValue(0).ToString();
                }
                else
                {
                    Locationcode = "0";
                    break;
                }
            }

            return Locationcode;
        }

        public static void Validate(string userName, string password)
        {
            try
            {
                String AccountUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                System.Diagnostics.EventLog.WriteEntry("userNamewithID", userName);
                String ServiceID = userName.Substring(userName.Length - 4);
                int SID = int.Parse(ServiceID);
                userName = userName.Remove(userName.Length - 4);
                System.Diagnostics.EventLog.WriteEntry("userName", userName);
                string ServiceUsername = string.Empty;
                string ServicePassword = string.Empty;
                string ServiceCertiicate, ServicePublicKey, BTCertiicate, BTPublicKey;
                string BTUserName = string.Empty;
                string BTPassword = string.Empty;
                Encryptor EnocEnc = new Encryptor();
                ClassConnectionString strcon = new ClassConnectionString();
                System.Diagnostics.EventLog.WriteEntry("strcon", strcon.ToString());
                strcon.connectionString();
                SqlCommand selectCMD = new SqlCommand("SELECT *   FROM [dbo].[ELM_ServiceCredential]  where ServiceID = " + SID + " and Active = 'Y'", strcon.conConnect);
                System.Diagnostics.EventLog.WriteEntry("selectCMD", selectCMD.ToString());
                System.Diagnostics.EventLog.WriteEntry("AccountUser", AccountUser);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = selectCMD;
                strcon.conConnect.Open();
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 2)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        if (dr[7].ToString() != "Biztalk")
                        {
                            System.Diagnostics.EventLog.WriteEntry("Biztalk", dr[7].ToString());
                            System.Diagnostics.EventLog.WriteEntry("ServiceName1", AccountUser + "_" + dr[7].ToString());
                            ServiceCertiicate = dr[5].ToString();
                            System.Diagnostics.EventLog.WriteEntry("ServiceCertiicate2", ServiceCertiicate);
                            ServicePublicKey = dr[6].ToString();
                            System.Diagnostics.EventLog.WriteEntry("ServicePublicKey3", AccountUser + "_" + ServicePublicKey);
                            ServiceUsername = EnocEnc.DecryptInput(userName, ServiceCertiicate, ServicePublicKey);
                            System.Diagnostics.EventLog.WriteEntry("ServiceUsernameDEC4", AccountUser + "_" + ServiceUsername);
                            ServicePassword = EnocEnc.DecryptInput(password, ServiceCertiicate, ServicePublicKey);
                            System.Diagnostics.EventLog.WriteEntry("ServicePasswordDEC5", AccountUser + "_" + ServicePassword);

                        }
                        if (dr[7].ToString() == "Biztalk")
                        {
                            BTUserName = dr[3].ToString();
                            System.Diagnostics.EventLog.WriteEntry("BTUserName1", AccountUser + "_" + BTUserName);
                            BTPassword = dr[4].ToString();
                            System.Diagnostics.EventLog.WriteEntry("BTPassword2", AccountUser + "_" + BTPassword);
                            BTCertiicate = dr[5].ToString();
                            System.Diagnostics.EventLog.WriteEntry("BTCertiicate3", AccountUser + "_" + BTCertiicate);
                            BTPublicKey = dr[6].ToString();
                            System.Diagnostics.EventLog.WriteEntry("BTPublicKey4", AccountUser + "_" + BTPublicKey);
                            BTUserName = EnocEnc.DecryptInput(BTUserName, BTCertiicate, BTPublicKey);
                            System.Diagnostics.EventLog.WriteEntry("BTUserNameDEC5", AccountUser + "_" + BTUserName);
                            BTPassword = EnocEnc.DecryptInput(BTPassword, BTCertiicate, BTPublicKey);
                            System.Diagnostics.EventLog.WriteEntry("BTPassword6", AccountUser + "_" + BTPassword);

                        }
                    }
                }
                strcon.conConnect.Close();
                System.Diagnostics.EventLog.WriteEntry("Final", BTUserName + " _ " + BTPassword + " _ " + ServiceUsername + " _ " + ServicePassword);

                if ((String.Equals(ServiceUsername, BTUserName) == true) && (String.Equals(ServicePassword, BTPassword) == true))
                {

                    return;
                }
                else
                {

                    //  throw new SecurityTokenException("401-Unauthorized-access-is-denied-due-to-invalid-credentials");
                }

            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("SecurityTokenException", ex.ToString());

                ///   throw new FaultException("Unauthorized Access is denied due to Invalid Credentials", new FaultCode("401"));

                //  throw new SecurityTokenException("Unknown Username or Password");

            }
            // throw new FaultException("Unauthorized Access is denied due to Invalid Credentials", new FaultCode("401"));
        }
        public static string Decrypt(string strText, string strKey)
        {
            string str;
            byte[] numArray = new byte[] { 18, 52, 86, 120, 144, 171, 205, 239 };
            byte[] numArray1 = numArray;
            byte[] numArray2 = new byte[checked(strText.Length + 1)];
            try
            {
                if (strKey.ToString().Length <= 8)
                {
                    str = "Decryption key should contain minimum 9 characters";
                }
                else
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(strKey.Substring(0, 8));

                    DESCryptoServiceProvider dESCryptoServiceProvider = new DESCryptoServiceProvider();
                    numArray2 = Convert.FromBase64String(strText);
                    MemoryStream memoryStream = new MemoryStream();
                    CryptoStream cryptoStream = new CryptoStream(memoryStream, dESCryptoServiceProvider.CreateDecryptor(bytes, numArray1), CryptoStreamMode.Write);
                    cryptoStream.Write(numArray2, 0, checked((int)numArray2.Length));
                    cryptoStream.FlushFinalBlock();
                    str = Encoding.UTF8.GetString(memoryStream.ToArray());
                }
            }
            catch (Exception exception)
            {
                // ProjectData.SetProjectError(exception);
                str = exception.Message;
                //ProjectData.ClearProjectError();
            }
            return str;
        }

        public static void Validate4(string userName, string password)
        {
            try
            {
                System.Diagnostics.EventLog.WriteEntry("Validate1C", "1");
                String ServiceID = userName.Substring(userName.Length - 4);
                System.Diagnostics.EventLog.WriteEntry("Validate2", "2");
                int SID = int.Parse(ServiceID);
                userName = userName.Remove(userName.Length - 4);
                System.Diagnostics.EventLog.WriteEntry("Validate3", SID.ToString());
                string ServiceUsername = string.Empty;
                string ServicePassword = string.Empty;
                string ServiceCertiicate, ServicePublicKey, BTCertiicate, BTPublicKey;
                string BTUserName = string.Empty;
                string BTPassword = string.Empty;
                Encryptor EnocEnc = new Encryptor();
                System.Diagnostics.EventLog.WriteEntry("Validate4", "3");

                ClassConnectionString strcon = new ClassConnectionString();
                strcon.connectionString();
                //  SqlDataAdapter da = new SqlDataAdapter("SELECT *   FROM [dbo].[ELM_ServiceCredential]  where ServiceID = "+SID+" and Active = 'Y'", strcon.conConnect);
                SqlCommand selectCMD = new SqlCommand("SELECT *   FROM [dbo].[ELM_ServiceCredential]  where ServiceID = " + SID + " and Active = 'Y'", strcon.conConnect);
                System.Diagnostics.EventLog.WriteEntry("Validate5", "4");
                SqlDataAdapter da = new SqlDataAdapter();
                System.Diagnostics.EventLog.WriteEntry("In Validate6 ", "");
                da.SelectCommand = selectCMD;
                System.Diagnostics.EventLog.WriteEntry("In Validate7", "");
                strcon.conConnect.Open();
                System.Diagnostics.EventLog.WriteEntry("In Validate8", "");
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 2)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        System.Diagnostics.EventLog.WriteEntry("In Validate9", "");
                        if (dr[7].ToString() != "Biztalk")
                        {
                            ServiceCertiicate = dr[5].ToString();
                            ServicePublicKey = dr[6].ToString();

                            //Encryptor enc = new Encryptor();
                            //string Value = enc.DecryptInput(userName, ServiceCertiicate, ServicePublicKey);
                            ServiceUsername = EnocEnc.DecryptInput(userName, ServiceCertiicate, ServicePublicKey);
                            ServicePassword = EnocEnc.DecryptInput(password, ServiceCertiicate, ServicePublicKey);
                            System.Diagnostics.EventLog.WriteEntry("INValidateServiceUsername", ServiceUsername + ServiceUsername);

                        }
                        if (dr[7].ToString() == "Biztalk")
                        {
                            BTUserName = dr[3].ToString();
                            BTPassword = dr[4].ToString();
                            BTCertiicate = dr[5].ToString();
                            BTPublicKey = dr[6].ToString();
                            BTUserName = EnocEnc.DecryptInput(BTUserName, BTCertiicate, BTPublicKey);
                            BTPassword = EnocEnc.DecryptInput(BTPassword, BTCertiicate, BTPublicKey);
                            System.Diagnostics.EventLog.WriteEntry("INValidate", BTUserName + BTPassword);
                        }
                    }
                }
                strcon.conConnect.Close();
                System.Diagnostics.EventLog.WriteEntry("V8", BTUserName + " _ " + BTPassword + " _ " + ServiceUsername + " _ " + ServicePassword);

                if ((String.Equals(ServiceUsername, BTUserName) == true) && (String.Equals(ServicePassword, BTPassword) == true))
                {
                    System.Diagnostics.EventLog.WriteEntry("V8", SID.ToString());

                    return;
                }
                else
                {
                    System.Diagnostics.EventLog.WriteEntry("V9", SID.ToString());

                }

            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("Catch", ex.ToString());

                throw;

            }



        }

        public static void Validate8(string userName, string password)
        {
            string GN = Guid.NewGuid().ToString();
            try
            {

                String AccountUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                Logwrite(GN, AccountUser);
                String ServiceID = userName.Substring(userName.Length - 4);
                int SID = int.Parse(ServiceID);
                Logwrite(GN, SID.ToString());
                userName = userName.Remove(userName.Length - 4);
                Logwrite(GN, userName);
                string ServiceUsername = string.Empty;
                string ServicePassword = string.Empty;
                string ServiceCertiicate, ServicePublicKey, BTCertiicate, BTPublicKey;
                string BTUserName = string.Empty;
                string BTPassword = string.Empty;
                Encryptor EnocEnc = new Encryptor();
                ClassConnectionString strcon = new ClassConnectionString();
                Logwrite(GN, password);
                strcon.connectionString();
                SqlCommand selectCMD = new SqlCommand("SELECT *   FROM [dbo].[ELM_ServiceCredential]  where ServiceID = " + SID + " and Active = 'Y'", strcon.conConnect);

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = selectCMD;
                strcon.conConnect.Open();
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 2)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        if (dr[7].ToString() == "Biztalk")
                        {
                            BTUserName = dr[3].ToString();
                            Logwrite(GN, BTUserName);
                            BTPassword = dr[4].ToString();
                            Logwrite(GN, BTPassword);
                            BTCertiicate = dr[5].ToString();
                            Logwrite(GN, BTCertiicate);
                            BTPublicKey = dr[6].ToString();
                            Logwrite(GN, BTPublicKey);
                            BTUserName = EnocEnc.DecryptInput(BTUserName, BTCertiicate, BTPublicKey);
                            Logwrite(GN, BTUserName);
                            BTPassword = EnocEnc.DecryptInput(BTPassword, BTCertiicate, BTPublicKey);
                            Logwrite(GN, BTPassword);

                        }
                        if (dr[7].ToString() != "Biztalk")
                        {
                            Logwrite(GN, AccountUser + "_" + dr[7].ToString());
                            ServiceCertiicate = dr[5].ToString();
                            Logwrite(GN, ServiceCertiicate);
                            ServicePublicKey = dr[6].ToString();
                            Logwrite(GN, ServicePublicKey);
                            ServiceUsername = EnocEnc.DecryptInput(userName, ServiceCertiicate, ServicePublicKey);
                            Logwrite(GN, ServiceUsername);
                            ServicePassword = EnocEnc.DecryptInput(password, ServiceCertiicate, ServicePublicKey);
                            Logwrite(GN, ServicePassword);

                        }

                    }
                }
                strcon.conConnect.Close();
                Logwrite(GN, ServiceUsername + " _ " + ServicePassword + " _ " + BTUserName + " _ " + BTPassword);

                if ((String.Equals(ServiceUsername, BTUserName) == true) && (String.Equals(ServicePassword, BTPassword) == true))
                {

                    return;
                }
                else
                {

                    //  throw new SecurityTokenException("401-Unauthorized-access-is-denied-due-to-invalid-credentials");
                }

            }
            catch (Exception ex)
            {
                Logwrite(GN, ex.ToString());

                //throw new SecurityTokenException("Unknown Username or Password");

            }
            //throw new FaultException("Unauthorized Access is denied due to Invalid Credentials", new FaultCode("401"));
        }
        public static void Logwrite(string GacId, string Logval)
        {
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"D:\Siddhant\Log\" + GacId + ".txt", true))
            {
                file.WriteLine(Logval + "\r\n");
            }
        }
        public static void Validate2(string userName, string password)
        {
            String ServiceID = userName.Substring(userName.Length - 4);
            int SID = int.Parse(ServiceID);
            userName = userName.Remove(userName.Length - 4);

            string ServiceUsername = string.Empty;
            string ServicePassword = string.Empty;
            string ServiceCertiicate, ServicePublicKey, BTCertiicate, BTPublicKey;
            string BTUserName = string.Empty;
            string BTPassword = string.Empty;
            Encryptor EnocEnc = new Encryptor();


            ClassConnectionString strcon = new ClassConnectionString();
            strcon.connectionString();
            SqlCommand command = new SqlCommand("SELECT  EncryptedCertificate,EncryptedPublicKey   FROM [dbo].[ELM_ServiceCredential]  where ServiceID =" + SID + " and Active = 'Y' and SourceSystem !='Biztalk'", strcon.conConnect);

            strcon.conConnect.Open();
            SqlDataReader myDataReader = command.ExecuteReader();

            while (myDataReader.Read())
            {
                ServiceCertiicate = myDataReader.GetValue(0).ToString();
                ServicePublicKey = myDataReader.GetValue(1).ToString();
                ServiceUsername = EnocEnc.DecryptInput(userName, ServiceCertiicate, ServicePublicKey);
                ServicePassword = EnocEnc.DecryptInput(password, ServiceCertiicate, ServicePublicKey);
            }
            strcon.conConnect.Close();
            strcon.conConnect.Open();

            SqlCommand command1 = new SqlCommand("SELECT  EncryptedUserName, EncryptedServicePassword, EncryptedCertificate,EncryptedPublicKey   FROM [dbo].[ELM_ServiceCredential]  where ServiceID =" + SID + " and Active = 'Y' and SourceSystem ='Biztalk'", strcon.conConnect);
            SqlDataReader myDataReader1 = command1.ExecuteReader();

            while (myDataReader1.Read())
            {
                BTUserName = myDataReader1.GetValue(0).ToString();
                BTPassword = myDataReader1.GetValue(1).ToString();
                BTCertiicate = myDataReader1.GetValue(2).ToString();
                BTPublicKey = myDataReader1.GetValue(3).ToString();
                BTUserName = EnocEnc.DecryptInput(BTUserName, BTCertiicate, BTPublicKey);
                BTPassword = EnocEnc.DecryptInput(BTPassword, BTCertiicate, BTPublicKey);

            }
            strcon.conConnect.Close();
            if ((String.Equals(ServiceUsername, BTUserName) == true) && (String.Equals(ServicePassword, BTPassword) == true))
                return;




        }
        public static void Validate1(string userName, string password)
        {
            String ServiceID = userName.Substring(userName.Length - 4);
            int SID = int.Parse(ServiceID);
            userName = userName.Remove(userName.Length - 4);

            string ServiceUsername = string.Empty;
            string ServicePassword = string.Empty;
            string ServiceCertiicate, ServicePublicKey, BTCertiicate, BTPublicKey;
            string BTUserName = string.Empty;
            string BTPassword = string.Empty;
            Encryptor EnocEnc = new Encryptor();
            System.Diagnostics.EventLog.WriteEntry("V1", SID.ToString());

            SqlConnection connection = new SqlConnection("server=(local);Initial Catalog=dbName;Integrated Security=True");
            SqlCommand command = new SqlCommand("SELECT  EncryptedCertificate,EncryptedPublicKey   FROM [dbo].[ELM_ServiceCredential]  where ServiceID =" + SID + " and Active = 'Y' and SourceSystem !='Biztalk'", connection);
            System.Diagnostics.EventLog.WriteEntry("V2", SID.ToString());
            connection.Open();
            SqlDataReader myDataReader = command.ExecuteReader();
            System.Diagnostics.EventLog.WriteEntry("V3", SID.ToString());
            while (myDataReader.Read())
            {
                ServiceCertiicate = myDataReader.GetValue(0).ToString();
                ServicePublicKey = myDataReader.GetValue(1).ToString();
                ServiceUsername = EnocEnc.DecryptInput(userName, ServiceCertiicate, ServicePublicKey);
                ServicePassword = EnocEnc.DecryptInput(password, ServiceCertiicate, ServicePublicKey);
                System.Diagnostics.EventLog.WriteEntry("V4", SID.ToString());
            }
            connection.Close();
            connection.Open();
            System.Diagnostics.EventLog.WriteEntry("V5", SID.ToString());
            SqlCommand command1 = new SqlCommand("SELECT  EncryptedUserName, EncryptedServicePassword, EncryptedCertificate,EncryptedPublicKey   FROM [dbo].[ELM_ServiceCredential]  where ServiceID =" + SID + " and Active = 'Y' and SourceSystem ='Biztalk'", connection);
            SqlDataReader myDataReader1 = command1.ExecuteReader();
            System.Diagnostics.EventLog.WriteEntry("V6", SID.ToString());
            while (myDataReader1.Read())
            {
                BTUserName = myDataReader1.GetValue(0).ToString();
                BTPassword = myDataReader1.GetValue(1).ToString();
                BTCertiicate = myDataReader1.GetValue(2).ToString();
                BTPublicKey = myDataReader1.GetValue(3).ToString();
                BTUserName = EnocEnc.DecryptInput(BTUserName, BTCertiicate, BTPublicKey);
                BTPassword = EnocEnc.DecryptInput(BTPassword, BTCertiicate, BTPublicKey);
                System.Diagnostics.EventLog.WriteEntry("V7", SID.ToString());
            }
            connection.Close();
            if ((String.Equals(ServiceUsername, BTUserName) == true) && (String.Equals(ServicePassword, BTPassword) == true))
                return;


        }
        public static string GetXMLFromObject(object o)
        {

            XmlSerializer xs = null;
            //These are the objects that will free us from extraneous markup.
            XmlWriterSettings settings = null;
            XmlSerializerNamespaces ns = null;
            //We use a XmlWriter instead of a StringWriter.
            XmlWriter xw = null;

            String outString = String.Empty;
            try
            {
                //To get rid of the xml declaration we create an 
                //XmlWriterSettings object and tell it to OmitXmlDeclaration.
                settings = new XmlWriterSettings();
                //settings.OmitXmlDeclaration = true;

                //To get rid of the default namespaces we create a new
                //set of namespaces with one empty entry.
                ns = new XmlSerializerNamespaces();
                ns.Add("", "");

                StringBuilder sb = new StringBuilder();

                xs = new XmlSerializer(o.GetType());

                //We create a new XmlWriter with the previously created settings 
                //(to OmitXmlDeclaration).
                xw = XmlWriter.Create(sb, settings);

                //We call xs.Serialize and pass in our custom 
                //XmlSerializerNamespaces object.
                xs.Serialize(xw, o, ns);

                xw.Flush();

                outString = sb.ToString();

                outString = outString.Replace("q1:", "");
                outString = outString.Replace(":q1", "");

                if (!String.IsNullOrEmpty(outString))
                {
                    outString = outString.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");

                    outString = outString.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", "");


                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (xw != null)
                {
                    xw.Close();
                }
            }
            return outString;

        }



        public static XmlDocument Exception(string SoapEx)
        {
            XmlDocument xdoc = new XmlDocument();
            xdoc.LoadXml(SoapEx);
            System.Diagnostics.EventLog.WriteEntry("Helper", xdoc.InnerXml.ToString());
            return xdoc;
        }


        public static void SalesFieldTrace(string Req, string Res)
        {
            XmlDocument Resdoc = new XmlDocument();
            Resdoc.Load(Res);

            XmlNode xCLMTrnxID = Resdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceResponseRecord' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesReturnResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesReturnResponse']/*[local-name()='transactionId' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesReturnResponse']");
            string CLMTrnxID = string.Empty; CLMTrnxID = (xCLMTrnxID != null) ? xCLMTrnxID.InnerText : "";
            if (CLMTrnxID != "")
            {
                string PointsEarned = string.Empty;
                string PointsRedeemed = string.Empty;
                string ENOCTrnxID = string.Empty;
                XmlDocument Reqdoc = new XmlDocument();
                Reqdoc.Load(Req);

                string RequestID = Reqdoc.SelectSingleNode("//RequestId").InnerText;
                string CompanyID = Reqdoc.SelectSingleNode("//CompanyCode").InnerText;
                string SiteNo = Reqdoc.SelectSingleNode("//SiteNo").InnerText;
                string LoyaltyID = Reqdoc.SelectSingleNode("//SaleRequest/identifierId").InnerText;

                XmlNodeList xENOCTrnxID = Reqdoc.SelectNodes("/*[local-name()='TransactionProcessorServiceRequestRecord' and namespace-uri()='']/*[local-name()='SaleRequest' and namespace-uri()='']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesRequest' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesRequest']/*[local-name()='attributes' and namespace-uri()='']");
                if (xENOCTrnxID != null)
                {
                    foreach (XmlNode node in xENOCTrnxID)
                    {
                        string text = node.FirstChild.InnerText;
                        if (text.Equals("enocTrnId"))
                        {
                            ENOCTrnxID = node.LastChild.InnerText;
                        }
                    }
                }

                XmlNode xPoint = Resdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceResponseRecord' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/TransactionProcessorServiceResponse']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesReturnResponse' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesReturnResponse']/*[local-name()='points' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesReturnResponse']");
                string Point = string.Empty; Point = (xPoint != null) ? xPoint.InnerText : "";


                XmlNode xCLMTrnxType = Reqdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceRequestRecord' and namespace-uri()='']/*[local-name()='SaleRequest' and namespace-uri()='']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesRequest' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesRequest']/*[local-name()='extTransactionTypeName' and namespace-uri()='']");
                string CLMTrnxType = string.Empty; CLMTrnxType = (xCLMTrnxType != null) ? xCLMTrnxType.InnerText : "";
                if (CLMTrnxType == "ACCRUAL_FUEL" || CLMTrnxType == "ACCRUAL_NON_FUEL")
                {
                    PointsEarned = Point; PointsRedeemed = "";
                }
                else
                {
                    PointsEarned = ""; PointsRedeemed = Point;

                }

                XmlNode xLocation = Reqdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceRequestRecord' and namespace-uri()='']/*[local-name()='SaleRequest' and namespace-uri()='']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesRequest' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesRequest']/*[local-name()='partner' and namespace-uri()='']");
                string Location = string.Empty; Location = (xLocation != null) ? xLocation.InnerText : "";

                XmlNode xPartner = Reqdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceRequestRecord' and namespace-uri()='']/*[local-name()='SaleRequest' and namespace-uri()='']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesRequest' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesRequest']/*[local-name()='partner' and namespace-uri()='']");
                string Partner = string.Empty; Partner = (xPartner != null) ? xPartner.InnerText : "";

                XmlNode xTranDate = Reqdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceRequestRecord' and namespace-uri()='']/*[local-name()='SaleRequest' and namespace-uri()='']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesRequest' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesRequest']/*[local-name()='date' and namespace-uri()='']");
                string TransactionDate = string.Empty; TransactionDate = (xTranDate != null) ? xTranDate.InnerText : "";

                XmlNode xBusinessDate = Reqdoc.SelectSingleNode("/*[local-name()='TransactionProcessorServiceRequestRecord' and namespace-uri()='']/*[local-name()='SaleRequest' and namespace-uri()='']/*[local-name()='CLMTransactionProcessorServiceTransactionIdSalesRequest' and namespace-uri()='http://enoc.com/biztalk/loyalty/CLMTransactionProcessorServiceTransactionIdSalesRequest']/*[local-name()='extBusinessDate' and namespace-uri()='']");
                string BusinessDate = string.Empty; BusinessDate = (xBusinessDate != null) ? xBusinessDate.InnerText : "";


                string CreatedBy = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

                ClassConnectionString strcon = new ClassConnectionString();
                strcon.connectionString();
                string query = "Insert INTO [dbo].[ELT_LoyaltySales] (RequestID,CompanyID,LoyaltyID,ENOCTrnxID,CLMTrnxID,CLMTrnxType,Partner,Location,SiteNo,PointsEarned,PointsRedeemed,BusinessDate,TransactionDate,CreatedBy,CreatedDate) VALUES (@RequestID,@CompanyID,@LoyaltyID,@ENOCTrnxID,@CLMTrnxID,@CLMTrnxType,@Partner,@Location,@SiteNo,@PointsEarned,@PointsRedeemed,@BusinessDate,@TransactionDate,@CreatedBy,@CreatedDate)";

                using (SqlCommand cmd = new SqlCommand(query, strcon.conConnect))
                {
                    strcon.conConnect.Open();
                    cmd.Parameters.AddWithValue("@RequestID", RequestID);
                    cmd.Parameters.AddWithValue("@CompanyID", CompanyID);
                    cmd.Parameters.AddWithValue("@LoyaltyID", LoyaltyID);
                    cmd.Parameters.AddWithValue("@ENOCTrnxID", ENOCTrnxID);
                    cmd.Parameters.AddWithValue("@CLMTrnxID", CLMTrnxID);
                    cmd.Parameters.AddWithValue("@CLMTrnxType", CLMTrnxType);
                    cmd.Parameters.AddWithValue("@Partner", Partner);
                    cmd.Parameters.AddWithValue("@Location", Location);
                    cmd.Parameters.AddWithValue("@SiteNo", SiteNo);
                    cmd.Parameters.AddWithValue("@PointsEarned", PointsEarned);
                    cmd.Parameters.AddWithValue("@PointsRedeemed", PointsRedeemed);
                    cmd.Parameters.AddWithValue("@BusinessDate", BusinessDate);
                    cmd.Parameters.AddWithValue("@TransactionDate", TransactionDate);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                    cmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                    cmd.ExecuteNonQuery();
                    strcon.conConnect.Close();

                }
            }

        }
        public static string StatusCode(string Path)
        {
            string[] values = Path.Split(',');
            string codeval = Array.Find(values, element => element.StartsWith("\"status\"", StringComparison.Ordinal));
            bool Code = string.IsNullOrEmpty(codeval);
            string statusCode = string.Empty;
            if (Code == false)
            {
                string[] status = codeval.Split(':');
                statusCode = status[1];
            }
            else { statusCode = "404"; }

            return Path;
        }


        public static string CodeCheck(string content)
        {
            content = content.Replace("\"status\":500", "\"status\":480");
            return content;
        }

        public static string AppStatus(string a)
        {
            var values = new Dictionary<string, string>();
            values.Add("customerscobrands", "0");
            values.Add("customerscobrandsunlink", "1");
            values.Add("softenrollment", "1");
            values.Add("enrollment", "1");
            values.Add("validatemember", "1");
            values.Add("validateotp", "1");

            string outval = string.Empty;
            values.TryGetValue(a, out outval);
            return outval;
        }
        public static XmlDocument GetHttpHeaderValues(string headerVal, string Method)
        {

            System.Xml.XmlDocument Response = new System.Xml.XmlDocument();
            try
            {
                String OutPut = string.Empty;
                if (Method == "softenrollment")
                {
                    //  WriteLogtoFile("SoftEnrollmentResponse", headerVal);
                    string[] lineText = headerVal.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    List<string> eftList = lineText.ToList<string>();
                    string[] LoyaltyId = eftList.Find(x => x.Contains("LoyaltyId")).Split(new char[] { ':' });
                    string LoyaltyIdVal = LoyaltyId[1].Trim();
                    string[] Location = eftList.Find(x => x.Contains("Location")).Split(new char[] { ':' }, 2);
                    string LocationVal = Location[1].Trim();
                    OutPut = "<ns2:CLMProfileServiceSoftEnrollmentResponse xmlns:ns2=\"http://enoc.com/biztalk/loyalty/CLMProfileServiceSoftEnrollmentResponse\"><ns2:Location>" + LocationVal + "</ns2:Location><ns2:LoyaltyId>" + LoyaltyIdVal + "</ns2:LoyaltyId></ns2:CLMProfileServiceSoftEnrollmentResponse>";
                    //  WriteLogtoFile("SoftEnrollmentResponse", OutPut);
                    Response.LoadXml(OutPut);
                }
                else if (Method == "enrollment")
                {
                    // WriteLogtoFile("EnrollmentResponse", headerVal);
                    string[] lineText = headerVal.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    List<string> eftList = lineText.ToList<string>();
                    string[] LoyaltyId = eftList.Find(x => x.Contains("LoyaltyId")).Split(new char[] { ':' });
                    string LoyaltyIdVal = LoyaltyId[1].Trim();
                    string[] Location = eftList.Find(x => x.Contains("Location")).Split(new char[] { ':' }, 2);
                    string LocationVal = Location[1].Trim();
                    string[] AccountId = eftList.Find(x => x.Contains("AccountId")).Split(new char[] { ':' });
                    string AccountIdVal = AccountId[1].Trim();
                    string[] CustomerId = eftList.Find(x => x.Contains("CustomerId")).Split(new char[] { ':' });
                    string CustomerIdVal = CustomerId[1].Trim();
                    OutPut = "<ns3:CLMProfileServiceEnrollmentResponse xmlns:ns3=\"http://enoc.com/biztalk/loyalty/CLMProfileServiceEnrollmentResponse\"><ns3:Location>" + LocationVal + "</ns3:Location><ns3:LoyaltyId>" + LoyaltyIdVal + "</ns3:LoyaltyId><ns3:CustomerId>" + CustomerIdVal + "</ns3:CustomerId><ns3:AccountId>" + AccountIdVal + "</ns3:AccountId></ns3:CLMProfileServiceEnrollmentResponse>";
                    // WriteLogtoFile("EnrollmentResponse", OutPut);
                    Response.LoadXml(OutPut);
                }
                else if (Method == "corpenrollment")
                {
                    // WriteLogtoFile("CorpEnrollmentResponse", headerVal);
                    string[] lineText = headerVal.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    List<string> eftList = lineText.ToList<string>();
                    string[] LoyaltyId = eftList.Find(x => x.Contains("LoyaltyId")).Split(new char[] { ':' });
                    string LoyaltyIdVal = LoyaltyId[1].Trim();
                    string[] Location = eftList.Find(x => x.Contains("Location")).Split(new char[] { ':' }, 2);
                    string LocationVal = Location[1].Trim();
                    string[] AccountId = eftList.Find(x => x.Contains("AccountId")).Split(new char[] { ':' });
                    string AccountIdVal = AccountId[1].Trim();
                    string[] CustomerId = eftList.Find(x => x.Contains("CompanyId")).Split(new char[] { ':' });
                    string CustomerIdVal = CustomerId[1].Trim();
                    OutPut = "<ns0:CLMCorporateProfileServiceEnrollmentResponse xmlns:ns0=\"http://enoc.com/biztalk/loyalty/CLMCorporateProfileServiceEnrollmentResponse\"><ns0:Location>" + LocationVal + "</ns0:Location><ns0:LoyaltyId>" + LoyaltyIdVal + "</ns0:LoyaltyId><ns0:CompanyId>" + CustomerIdVal + "</ns0:CompanyId><ns0:AccountId>" + AccountIdVal + "</ns0:AccountId></ns0:CLMCorporateProfileServiceEnrollmentResponse>";
                    // WriteLogtoFile("CorpEnrollmentResponse", OutPut);
                    Response.LoadXml(OutPut);
                }
                return Response;
            }
            catch (Exception)
            {
                string Output = "<ns0:NACK Type=\"NACK\" xmlns:ns0=\"http://schema.microsoft.com/BizTalk/2003/NACKMessage.xsd\"><NAckID>{6E78D634-0E6A-4FBA-B7DD-39BC5D875367}</NAckID><ErrorCode>0xc0c0167a</ErrorCode><ErrorCategory>0</ErrorCategory><ErrorDescription>CLM ERROR { \"error\":\"CLM Response ERROR\",\"message\":\"Response ERROR\",\"path\":\"/b2b/profile/enrollment\",\"requestToken\":\"1579070701534791\",\"status\":409,\"timestamp\":\"2020-01-15T06:45:01.591Z\"}</ErrorDescription></ns0:NACK>";
                Response.LoadXml(Output);
                return Response;
            }
        }
        public static string GetToken()
        {
            string tokenvalue = string.Empty;
            ClassConnectionString strcon = new ClassConnectionString();
            strcon.connectionString();
            SqlCommand command = new SqlCommand("select top 1 TokenValue, ExpiryTime  FROM [dbo].[ELT_TokenRequests] where IsActive = 1 ", strcon.conConnect);
            strcon.conConnect.Open();

            SqlDataReader myDataReader = command.ExecuteReader();

            bool isRecordExist = false;
            while (myDataReader.Read())
            {
                isRecordExist = true;
                string expiryTime = myDataReader.GetValue(1).ToString();
                DateTime timeCheck = Convert.ToDateTime(expiryTime);
                if (timeCheck > DateTime.Now)
                {
                    tokenvalue = myDataReader.GetValue(0).ToString();
                }
                else
                {
                    tokenvalue = UpdateToken();
                    break;
                }
            }
            if (!isRecordExist)
            {
                tokenvalue = "0";
            }
            myDataReader.Close();
            strcon.conConnect.Close();
            return tokenvalue;
        }
        public static string UpdateToken()
        {
            MyWebRequest myRequest = new MyWebRequest(address, "POST");
            JObject JsonRes = myRequest.GetResponse();

            string tokenValue = JsonRes["access_token"].ToString();
            string expires_in = JsonRes["expires_in"].ToString();
            DateTime ExDateTime = ExpiryTime(expires_in);
            string RequestId = JsonRes["jti"].ToString();
            String UserName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

            DisableToken();
            ClassConnectionString strcon = new ClassConnectionString();
            strcon.connectionString();
            string qry = "INSERT INTO [dbo].[ELT_TokenRequests](TokenValue, TokenExpiry, RequestId, IsActive, CreatedBy, CreatedDate,ExpiryTime) VALUES (@TokenValue,@TokenExpiry,@RequestId,@IsActive,@CreatedBy,@CreatedDate,@ExpiryTime)";

            using (SqlCommand cmd = new SqlCommand(qry, strcon.conConnect))
            {
                strcon.conConnect.Open();
                cmd.Parameters.AddWithValue("@TokenValue", tokenValue);
                cmd.Parameters.AddWithValue("@TokenExpiry", expires_in);
                cmd.Parameters.AddWithValue("@RequestId", RequestId);
                cmd.Parameters.AddWithValue("@IsActive", "1");
                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
                cmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                cmd.Parameters.AddWithValue("@ExpiryTime", ExDateTime);

                int k = cmd.ExecuteNonQuery();
                if (k > 0)
                {
                    System.Diagnostics.EventLog.WriteEntry("TokenNotUpdated", "Token Updated Successfully");
                }
                else
                {
                    System.Diagnostics.EventLog.WriteEntry("TokenNotUpdated", "UpdateToken Method Exception");
                }
                strcon.conConnect.Close();
            }
            return tokenValue;
        }
        public static void DisableToken()
        {
            ClassConnectionString strcon = new ClassConnectionString();
            strcon.connectionString();
            SqlCommand command = new SqlCommand("Update [dbo].[ELT_TokenRequests] SET IsActive = 0 WHERE IsActive = 1", strcon.conConnect);
            strcon.conConnect.Open();
            SqlDataReader myDataReader = command.ExecuteReader();
            strcon.conConnect.Close();
        }
        public static DateTime ExpiryTime(string extime)
        {
            int exhour = (int)Math.Round((decimal.Parse(extime) / 3600) - 1);
            DateTime date = DateTime.Now;
            TimeSpan time = new TimeSpan(exhour, 0, 0);
            DateTime exTime = date.Add(time);
            return exTime;
        }


        class ClassConnectionString
        {
            public SqlConnection conConnect;

            public void connectionString()
            {
                Encryptor DBEnc = new Encryptor();

                string con = @"Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=LoyaltyDB;Data Source=ENRBUSQLUAT\MSDSQLDEV2016";

                conConnect = new SqlConnection(con);


                //conConnect = new SqlConnection(@"Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=LoyaltyMaster;Data Source=ENSQL2016CMNDEV\ENSQL2016DEVCMN");
            }
        }

        //public class ClassConnectionString
        //{
        //    public SqlConnection conConnect;
        //    public void connectionString()
        //    {
        //        string conn_enc = System.Configuration.ConfigurationManager.AppSettings.Get("Connect_LoyaltyDB");
        //        string key_enc = System.Configuration.ConfigurationManager.AppSettings.Get("Key_LoyaltyDB");
        //        string key = decrypt(key_enc, "loyalitykey123");
        //        string conn = decrypt(conn_enc, key);
        //        conConnect = new SqlConnection(conn);
        //    }

        //    private string decrypt(string con, string key_enc)
        //    {
        //        SecureAccessComponent.clsEncryption64 enc = new SecureAccessComponent.clsEncryption64();
        //        return enc.DecryptFromBase64String(con, key_enc);
        //    }
        //}
        public class ClassConnectionString1
        {
            public SqlConnection conConnect;
            public void connectionString()
            {
                //string conn_enc = System.Configuration.ConfigurationManager.AppSettings.Get("Loyalty_ConnectString");
                //string key_enc = System.Configuration.ConfigurationManager.AppSettings.Get("Loyalty_Key");
                //string key = decrypt(key_enc, "loyalitykey123");
                //string Connect = decrypt(conn_enc, key);
                // conConnect = new SqlConnection(@"Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=LoyaltyLogs;Data Source=ENSQL2016CMNDEV\ENSQL2016DEVCMN");
                conConnect = new SqlConnection(@"Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=LoyaltyLogs;Data Source=ENRBUSQLUAT\MSDSQLDEV2016");

            }

            private string decrypt(string con, string key_enc)
            {
                SecureAccessComponent.clsEncryption64 enc = new SecureAccessComponent.clsEncryption64();
                return enc.DecryptFromBase64String(con, key_enc);
            }
        }


        class MyWebRequest
        {
            private WebRequest request;
            private Stream dataStream;
            private string status;

            public String Status
            {
                get
                {
                    return status;
                }
                set
                {
                    status = value;
                }
            }

            public MyWebRequest(string url)
            {
                request = WebRequest.Create(url);
            }

            public MyWebRequest(string url, string method)
                : this(url)
            {

                if (method.Equals("GET") || method.Equals("POST"))
                {
                    request.Method = method;
                }
                else
                {
                    throw new Exception("Invalid Method Type");
                }
            }

            //public MyWebRequest(string url, string method, string data)
            //    : this(url, method)
            //{

            //    // Create POST data and convert it to a byte array.
            //    string postData = data;
            //    byte[] byteArray = Encoding.UTF8.GetBytes(postData);

            //    // Set the ContentType property of the WebRequest.
            //    request.ContentType = "application/x-www-form-urlencoded";

            //    // Set the ContentLength property of the WebRequest.
            //    request.ContentLength = byteArray.Length;

            //    // Get the request stream.
            //    dataStream = request.GetRequestStream();

            //    // Write the data to the request stream.
            //    dataStream.Write(byteArray, 0, byteArray.Length);

            //    // Close the Stream object.
            //    dataStream.Close();

            //}

            public JObject GetResponse()
            {
                WebResponse response = request.GetResponse();
                this.Status = ((HttpWebResponse)response).StatusDescription;
                dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                string responseFromServer = reader.ReadToEnd();
                JObject joResponse = JObject.Parse(responseFromServer);
                reader.Close();
                dataStream.Close();
                response.Close();
                return joResponse;
            }

        }

    }


    public class Encryptor
    {
        private static string encryptorMsg;
        private static string cryptoKey;
        private static HashedEncryption objEncryptDecrypt;
        private const string encryptionPvtKey = "HoAuthPvtKey@1406";
        private const string configXmlName = "ENOC.SSB.CertEncryptor.Config.xml";
        private static string enocPublicKey;
        private static string hashedCertName;
        private static string decryptedCertName;
        private static string decryptedPublicKey;

        public Encryptor()
        {
            cryptoKey = string.Empty;
            decryptedCertName = string.Empty;
            objEncryptDecrypt = new HashedEncryption();
            decryptedPublicKey = string.Empty;
            enocPublicKey = string.Empty;
        }


        public string EncryptUsingCertificateName(string stringToBeEncrypt, string encryptedCertName, string encryptedPublicKey)
        {
            string encryptedInput = string.Empty;
            try
            {

                decryptedPublicKey = objEncryptDecrypt.Decrypt(encryptedPublicKey, encryptionPvtKey);
                decryptedCertName = objEncryptDecrypt.Decrypt(encryptedCertName, decryptedPublicKey);

                encryptedInput = EncryptCertString(stringToBeEncrypt, decryptedCertName);
            }
            catch (System.IO.FileNotFoundException exception)
            {

                encryptedInput = exception.Message;

            }
            catch (Exception exception)
            {

                encryptedInput = exception.Message;

            }

            return encryptedInput;
        }


        /// <summary>
        /// Method to be used to encrypt any string using certificate
        /// </summary>
        /// <param name="stringToBeEncrypt">Input string for encryption</param>
        /// <param name="encryptedCertName">Not in use</param>
        /// <param name="publicKey">Not in use</param>
        /// <returns>encrypted Input</returns>

        //[DllExport("EncryptUsingCertificate", CallingConvention = CallingConvention.Cdecl)]
        public string EncryptUsingCertificate(string stringToBeEncrypt, string encryptedCertName, string encryptedPublicKey)
        {
            string encryptedInput = string.Empty;
            try
            {
                //Read the config file in root directory
                DataSet dataset = new DataSet();
                dataset.ReadXml(configXmlName);
                hashedCertName = dataset.Tables[0].Rows[0]["CertificateName"].ToString();
                enocPublicKey = dataset.Tables[0].Rows[0]["ENOCPublicKey"].ToString();

                decryptedPublicKey = objEncryptDecrypt.Decrypt(enocPublicKey, encryptionPvtKey);
                decryptedCertName = objEncryptDecrypt.Decrypt(hashedCertName, decryptedPublicKey);

                //Old methods not in use
                //decryptedPublicKey = objEncryptDecrypt.Decrypt(publicKey, encryptionPvtKey);
                //decryptedCertName = objEncryptDecrypt.Decrypt(encryptedCertName, decryptedPublicKey);

                encryptedInput = EncryptCertString(stringToBeEncrypt, decryptedCertName);
            }
            catch (System.IO.FileNotFoundException exception)
            {
                // ProjectData.SetProjectError(exception);
                encryptedInput = exception.Message;
                //ProjectData.ClearProjectError();
            }
            catch (Exception exception)
            {
                //ProjectData.SetProjectError(exception);
                encryptedInput = exception.Message;
                //ProjectData.ClearProjectError();
            }

            return encryptedInput;
        }

        /// <summary>
        /// This method encrypts the input certificateName
        /// </summary>
        /// <param name="certName">CertificateName</param>
        /// <param name="publicKey">ENOC public key</param>
        /// <returns>encrypted certificate name</returns>
        //[DllExport("EncryptString", CallingConvention = CallingConvention.Cdecl)]
        public string EncryptString(string certName, string publicKey)
        {
            string encryptedCert = string.Empty;

            try
            {
                decryptedPublicKey = objEncryptDecrypt.Decrypt(publicKey, encryptionPvtKey);

                encryptedCert = EncryptWithHash(certName, decryptedPublicKey);
            }
            catch (Exception exception)
            {
                //ProjectData.SetProjectError(exception);
                encryptedCert = exception.Message;
                //ProjectData.ClearProjectError();
            }

            return encryptedCert;
        }
        private static string EncryptCertString(string stringToBeEncrypt, string certificateName)
        {
            string strEncyValue = string.Empty;

            try
            {
                // get the certificate from store
                X509Certificate2 cert = GetCertificateFromStore(certificateName);

                if (cert != null)
                {
                    byte[] cipherbytes = Encoding.ASCII.GetBytes(stringToBeEncrypt.Trim());
                    RSACryptoServiceProvider rsa = (RSACryptoServiceProvider)cert.PublicKey.Key;

                    byte[] cipher = rsa.Encrypt(cipherbytes, true);
                    strEncyValue = Convert.ToBase64String(cipher);
                }
                else
                {
                    encryptorMsg = "Certificate not found or invalid certificate in use";
                    strEncyValue = encryptorMsg;
                }
            }
            catch (Exception ex)
            {
                encryptorMsg = " Error in encyption, Method- Encryptstring, Error detail:  " + ex.Message;
                throw new Exception(encryptorMsg);
            }

            return strEncyValue;
        }
        private static X509Certificate2 GetCertificateFromStore(string certName)
        {
            // Get the certificate store for the local machine.
            X509Store store = new X509Store(StoreLocation.LocalMachine);
            try
            {
                store.Open(OpenFlags.ReadOnly);
                X509Certificate2Collection certCollection = store.Certificates;

                X509Certificate2Collection currentCerts = certCollection.Find(X509FindType.FindByTimeValid, DateTime.Now, false);
                X509Certificate2Collection signingCert = currentCerts.Find(X509FindType.FindBySubjectDistinguishedName, certName, false);

                if (signingCert.Count == 0)
                {
                    signingCert = currentCerts.Find(X509FindType.FindByThumbprint, certName, false);
                }
                return signingCert.Count == 0 ? null : signingCert[0];
            }
            catch (Exception exc)
            {
                encryptorMsg = " Error in encryptor, Method- #GetCertificateFromStore#, Error details:  " + exc.Message;
                throw new Exception(encryptorMsg);
            }
            finally
            {
                store.Close();
            }
        }

        public string DecryptInput(string stringToBeDecrypted, string encryptedCertName, string publicKey)
        {
            try
            {
                decryptedPublicKey = objEncryptDecrypt.Decrypt(publicKey, encryptionPvtKey);
                decryptedCertName = objEncryptDecrypt.Decrypt(encryptedCertName, decryptedPublicKey);

                return DecryptCertString(stringToBeDecrypted, decryptedCertName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string DecryptCertString(string strstringToDecrypt, string certificateNameKeyName)
        {
            string plainText = string.Empty;
            try
            {
                // get the certificate from store   
                X509Certificate2 cert = GetCertificateFromStore(certificateNameKeyName);
                if (cert != null)
                {
                    RSACryptoServiceProvider rsa;
                    rsa = (RSACryptoServiceProvider)cert.PrivateKey;
                    byte[] dcipherbytes = Convert.FromBase64String(strstringToDecrypt);
                    byte[] plainbytes = rsa.Decrypt(dcipherbytes, true);
                    ASCIIEncoding enc = new ASCIIEncoding();
                    plainText = enc.GetString(plainbytes);
                }
                else
                {
                    plainText = "ENOC.SSB.OutProcAuthService decryption - Certificate not found or invalid certificate in use";
                }
            }
            catch (Exception ex)
            {
                //plainText = " Decryption error in ENOC.SSB.OutProcAuthServices,Method- Decryptstring, Error detail:  " + ex.Message;
                //throw new Exception(encryptorMsg);
                plainText = ex.Message;
            }
            return plainText;
        }

        private static string EncryptWithHash(string stringTobeEncrypted, string key)
        {
            try
            {
                return objEncryptDecrypt.Encrypt(stringTobeEncrypted, key);
            }
            catch (Exception encryptExc)
            {
                throw encryptExc;
            }
        }

    }
}
