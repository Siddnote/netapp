﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace TokenAuthenticationLibrary
{
    public class HelperClass
    {   
        public static string GetToken()
        {
            string tokenvalue = string.Empty;
            ClassConnectionString strcon = new ClassConnectionString();
            strcon.connectionString();
            SqlCommand command = new SqlCommand("select top 1 TokenValue, ExpiryTime  FROM [LoyaltyMaster ].[dbo].[ELT_TokenRequests] where IsActive = 1 ", strcon.conConnect);
            strcon.conConnect.Open();

            SqlDataReader myDataReader = command.ExecuteReader();
            while (myDataReader.Read())
            {
                string expiryTime = myDataReader.GetValue(1).ToString();
                DateTime timeCheck = Convert.ToDateTime(expiryTime);
                if (timeCheck > DateTime.Now)
                {
                    tokenvalue = myDataReader.GetValue(0).ToString();
                }
                else
                {
                    tokenvalue = "0";
                    break;
                }
            }
            myDataReader.Close();
            strcon.conConnect.Close();
            return tokenvalue;
        }
        public static string UpdateToken(string tokenval, string expirein, string requestid)
        {
            string tokenValue = tokenval;
            string expires_in = expirein;
            DateTime ExDateTime = ExpiryTime(expires_in);
            string RequestId = requestid;
            String UserName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

            DisableToken();
            ClassConnectionString strcon = new ClassConnectionString();
            strcon.connectionString();
            string qry = "INSERT INTO [dbo].[ELT_TokenRequests](TokenValue, TokenExpiry, RequestId, IsActive, CreatedBy, CreatedDate,ExpiryTime) VALUES (@TokenValue,@TokenExpiry,@RequestId,@IsActive,@CreatedBy,@CreatedDate,@ExpiryTime)";

            using (SqlCommand cmd = new SqlCommand(qry, strcon.conConnect))
            {
                strcon.conConnect.Open();
                cmd.Parameters.AddWithValue("@TokenValue", tokenValue);
                cmd.Parameters.AddWithValue("@TokenExpiry", expires_in);
                cmd.Parameters.AddWithValue("@RequestId", RequestId);
                cmd.Parameters.AddWithValue("@IsActive", "1");
                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
                cmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                cmd.Parameters.AddWithValue("@ExpiryTime", ExDateTime);

                int k = cmd.ExecuteNonQuery();
                if (k > 0)
                {
                    System.Diagnostics.EventLog.WriteEntry("TokenNotUpdated", "Token Updated Successfully");
                }
                else
                {
                    System.Diagnostics.EventLog.WriteEntry("TokenNotUpdated", "UpdateToken Method Exception");
                }
                strcon.conConnect.Close();
            }
            return tokenValue;
        }
        public static void DisableToken()
        {
            ClassConnectionString strcon = new ClassConnectionString();
            strcon.connectionString();
            SqlCommand command = new SqlCommand("Update [dbo].[ELT_TokenRequests] SET IsActive = 0 WHERE IsActive = 1", strcon.conConnect);
            strcon.conConnect.Open();
            SqlDataReader myDataReader = command.ExecuteReader();
            strcon.conConnect.Close();
        }
        public static DateTime ExpiryTime(string extime)
        {
            int exhour = (int)Math.Round((decimal.Parse(extime) / 3600) - 1);
            DateTime date = DateTime.Now;
            TimeSpan time = new TimeSpan(exhour, 0, 0);
            DateTime exTime = date.Add(time);
            return exTime;
        }
    }
    public class ClassConnectionString
    {
        public SqlConnection conConnect;
        public void connectionString()
        {
            conConnect = new SqlConnection(@"Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=LoyaltyMaster;Data Source=ENSQL2016CMNDEV\ENSQL2016DEVCMN");
        }
    }

   


}
