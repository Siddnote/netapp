﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using ValidateOTPServiceSite.ServiceReference1;


namespace ValidateOTPServiceSite
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceReference1.WcfService_ENOC_Loyalty_Integration_CLM_OrchestrationsClient CM = new ServiceReference1.WcfService_ENOC_Loyalty_Integration_CLM_OrchestrationsClient();

            ProfileServiceResponseRecord response = CM.ProfileService(new ProfileServiceRequestRecord()
            {
                CallingSystem = "TestZoom",
                CLMProfileServiceValidateOTPRequest = new CLMProfileServiceValidateOTPRequest() { otp = "7545" },
                HTTP_METHOD = "POST",
                RequestId = Guid.NewGuid().ToString(),
                CompanyCode = "1",
                SiteNo = "1044",
                CLM_METHOD = "validateotp"
            });



            MemoryStream memoryStream = new MemoryStream();
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(memoryStream, response);
            memoryStream.Flush();
            memoryStream.Position = 0;
            string value = Convert.ToBase64String(memoryStream.ToArray());





            //var serxml = new XmlSerializer(response.GetType());
            //var ms = new MemoryStream();
            //serxml.Serialize(ms, response);


            //string xml = Encoding.UTF8.GetString(ms.ToArray());
            //Console.Write(xml);

            //XmlSerializer xmlSerializer = new XmlSerializer(response.GetType());

            //using (StringWriter textWriter = new StringWriter())
            //{
            //    xmlSerializer.Serialize(textWriter, response);
            //    textWriter.ToString();
            //    Console.Write(textWriter);
            Console.ReadLine();
            //}


        }

    }
}
