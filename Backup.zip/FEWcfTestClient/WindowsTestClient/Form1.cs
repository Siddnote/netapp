﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace WindowsTestClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            ServiceReference1.BTFrontEndServiceClient client = new ServiceReference1.BTFrontEndServiceClient();
            //BizTalkServiceInstance("WSHttpBinding_ITwoWayAsync");
            ServiceReference1.FrontendRequest FEreq = new ServiceReference1.FrontendRequest();
            FEreq.FirstName = textBox2.Text;    
            FEreq.LastName = textBox3.Text;
            FEreq.MobileNumber = textBox1.Text;


            ServiceReference1.Frontend FE = new ServiceReference1.Frontend();
            FE.Request = FEreq;


            XmlSerializer Ser1 = new XmlSerializer(FE.GetType());
            StringWriter sw = new StringWriter();
            XmlWriter writer = XmlWriter.Create(sw);

            Ser1.Serialize(writer, FE);

            XDocument xDocument = XDocument.Parse(sw.ToString());
            richTextBox1.Text = xDocument.ToString();

            ServiceReference1.Backend Res = client.FEOperation(FE);

            XmlSerializer Ser2 = new XmlSerializer(Res.GetType());
            StringWriter sw2 = new StringWriter();
            XmlWriter writer2 = XmlWriter.Create(sw2);

            Ser2.Serialize(writer2, Res);


            XDocument xDocument1 = XDocument.Parse(sw2.ToString());
            richTextBox2.Text = xDocument1.ToString();

        }
    }
}
