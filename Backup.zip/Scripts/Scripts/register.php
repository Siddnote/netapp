<?php 
	$con=mysqli_connect("localhost","id15552859_siddhant","Siddh@nt2021","id15552859_customer");
	
	
	$mobile = $_POST["mobile"];
	$name = $_POST["name"];
	$pincode = $_POST["pincode"];
	$email = $_POST["email"];
	$user =$_POST["user"];

	$sql = "INSERT INTO student(mobile,name,pincode,email,user) VALUES ('$mobile','$name','$pincode','$email','$user')";
	$result = mysqli_query( $con,$sql );
	
	if($result) {
		echo "registered successfully";
	}
	else {
		echo "some error occured";
	}
?>

