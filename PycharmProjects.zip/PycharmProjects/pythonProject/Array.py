

# -------------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------------
# Prefix Sum of Even and Odd Number

# N = [5, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# E = 0, 2, 4, 6, 8
# Prefix Sum for Even Number
# PSE =[0] * len(N)
# PSE[0] = N[0]
# for i in range(1, len(N)):
#     if i % 2 == 1:
#         PSE[i] = PSE[i-1]
#         print('if', i, PSE[i])
#     else:
#         PSE[i] = N[i] + PSE[i-1]
#         print('else', i, N[i], PSE[i])
# print(PSE)

# # Prefix Sum for Odd Number
# O = 1, 3, 5, 7, 9
# N = [3, 1, 2, 3, 4, 5, 6, 7, 8, 9]
# PSO = [0] * len(N)
# PSO[0] = 0
# for i in range(1, len(N)):
#     if i % 2 == 0:
#         PSO[i] = PSO[i-1]
#         # print('if', i, PSO[i])
#     else:
#         PSO[i] = N[i] + PSO[i-1]
#         # print('else', i, N[i], PSO[i])
# print(PSO)

# -------------------------------------------------------------------------------------------------------------------
# Special Index Element : An index after removing which the sum of odd index element is equal to even index element
# sum of Odd index  :SO =  PSO[i-1] + PSE[N-1] - PSE[i]
# sum of Even index :SE =  PSE[i-1] + PSO[N-1] - PSO[i]
# if (SO == SE): i  [i is special index]
# Count of such indices

# # A = [2, 1, 6, 4]
# A = [1, 1, 1]
# print(A)
# # # E = 0, 2, 4, 6, 8
# PSE = [0] * len(A)
# PSE[0] = A[0]
# for i in range(1, len(A)):
#     if i % 2 == 1:
#         PSE[i] = PSE[i-1]
#     else:
#         PSE[i] = A[i] + PSE[i-1]
# print(PSE)
#
# PSO = [0] * len(A)
# PSO[0] = 0
# # E = 1, 3, 5, 7, 9
# for i in range(1, len(A)):
#     if i % 2 == 0:
#         PSO[i] = PSO[i-1]
#     else:
#         PSO[i] = A[i] + PSO[i-1]
# print(PSO)
#
# count = 0
# for i in range(len(A)):
#     if i == 0:
#         SumO = PSE[len(A) - 1] - PSE[i]
#         SumE = PSO[len(A) - 1] - PSO[i]
#     else:
#         SumO = PSO[i-1] + PSE[len(A)-1] - PSE[i]
#         SumE = PSE[i-1] + PSO[len(A)-1] - PSO[i]
#
#     print(i, SumE, SumO)
#     if SumO == SumE:
#         count += 1
# print(count)

# -------------------------------------------------------------------------------------------------------------------
# A = [3, 4, 4, 6]
# B = [20, 4, 10, 2]
#
# PS = []
# total = 0
# for i in A:
#     total += i
#     PS.append(total)
# print(PS)
#
# out = []
# for i in B:
#     cnt = 0
#     for j in PS:
#         if i > j:
#             cnt += 1
#             print(i, j, cnt)
#     out.append(cnt)
#
# -------------------------------------------------------------------------------------------------------------------
#
# def count(B, PS):
#     ans = 0
#     for num in PS:
#         if B >= num:
#             ans += 1
#     return ans
# T = []
# for j in B:
#     S = count(j, PS)
#     T.append(S)
# print(T)
#

# -------------------------------------------------------------------------------------------------------------------
# Enumerate value and index
# H = [-7, 1, 5, 2, -4, 3, 0]
# for i, num in enumerate(H):
#     print(i, num)
#
# for i in enumerate(H):
#     print(i[0], i[1], i)
# -------------------------------------------------------------------------------------------------------------------

# Carry Forward Class

# Left Max
# A = [2, 3, 5, 6, 7, 7, -8, -4, 11]
# LM = [0] * len(A)
# LM[0] = A[0]
# for i in range(len(A)):
#     print(i)
#     LM[i] = max(LM[i-1], A[i])
# print(LM)

# Right Max
# A = [2, 11, 5, 6, 7, 9, -8, -4, 1]
# RM = [0] * len(A)
# RM[len(A)-1] = A[len(A)-1]
#
# for i in range(len(A)-2, -1, -1):
#     # print(i, RM[i+1], len(A)-i, A[i])
#     RM[i] = max(A[i], RM[i+1])
#
# print(RM, len(A))

# -------------------------------------------------------------------------------------------------------------------
# Given a string of lower case alphabets return the count of pairs[indices] (i, j) such that
# i < j and S[i] = 'a' and S[j] = 'g'

# Approach: 1
# A = 'abcagbsgag'
# count = 0
# for i in range(len(A)):
#     if A[i] == 'a':
#         for j in range(i, len(A)):
#             if A[j] == 'g':
#                 print(i, j)
#                 count += 1
# print(count)

# Approach: 2
# A = 'abcagbsgag'
# count_a = 0
# count = 0
# for i in A:
#     if i == 'a':
#         count_a += 1
#     if i == 'g':
#         count += count_a
# print(count)
# -------------------------------------------------------------------------------------------------------------------
# Finding maximum sum subarray
# N = [-1, -2, 3, 4, -5, 6]
# ans = N[0]
# sum = 0
# for i in N:
#     sum += i
#     ans = max(sum, ans)
#     if sum < 0:
#         sum = 0
# print(ans)
# -------------------------------------------------------------------------------------------------------------------
# Unsolved
# Given an array of length N, find the length of the smallest subarray,
# which contain both min and max element of array

# A = [7, 1, 3, 4, 1, 7]
#
# # min
# # max
# Min = min(A)
# ans = 1000000000
# ans2 = -10000000
# for i in A:
#     ans = min(i, ans)
#     ans2 = max(i, ans2)
#
#
# print

# -------------------------------------------------------------------------------------------------------------------
# Find no. of elements which have at-least 1 element greater than it
# A = [2, 3, 5, 6, 7, 7, -8, -4, 6]
# B =[]
# count = 0
# max = 0
# for i in range(len(A)):
#     if A[i] > max:
#         max = A[i]
#     if A[i] not in B:
#         B.append(A[i])
# print(max, B)
# print(len(B)-1)

# -------------------------------------------------------------------------------------------------------------------
# Given an array and an integer k, Check if there exists a pair (i, j) where i != j such that A[i] + A[j] == k

# A = [3, -2, 1, 4, 3, 6, 8]
# K = 10

# Approach: 1
# ans = False
# for i in range(len(A)):
#     B = 10 - A[i]
#     if B in A:
#         ans = True
#         print("True", A[i], B)
#
# if ans == False:
#     print("False")

# Approach: 2
# ----------- Upper Diagonal
# N = len(A)
# for i in range(0, N):
#     for j in range(i+1, N):
#         print([i], [j])
#         if A[i] + A[j] == K:
#             print(True, A[i], A[j])
# ----------- Lower Diagonal
# N = len(A)
# for i in range(N-1, 1, -1):
#     for j in range(i-1, 0, -1):
#         print([i], [j])
#         if A[i] + A[j] == K:
#             print(True, A[i], A[j])

# -------------------------------------------------------------------------------------------------------------------
# Given an array of size N, Reverse the array using Constant Extra Space

# A = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# B = len(A)
# i = 0
# j = B-1
# while i < j:
#     T = A[i]
#     A[i] = A[j]
#     A[j] = T
#     # A[i], A[j] = A[j], A[i]
#     i += 1
#     j -= 1
# print(A)
# -------------------------------------------------------------------------------------------------------------------
# Given an array of size N,two indices (S,E)-Reverse all element from S to E,From given index S till E,
# A = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# B = len(A)
# S = 4
# E = 8
# i , j = 4, 8
# while i < j:
#     A[i], A[j] = A[j], A[i]
#     i += 1
#     j -= 1
# print(A)

# -------------------------------------------------------------------------------------------------------------------
# Given an array, Rotate the array in the clockwise direction by K times

# A = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# Approach 1 : Brute force

# lenofA = len(A)
# numofTimes = 34
# print(numofTimes, lenofA)
# if numofTimes > lenofA:
#     numofTimes = numofTimes%lenofA
#     print(numofTimes)
#
# print(lenofA, numofTimes)
# B = A[:-numofTimes]
# C = A[lenofA-numofTimes:]
# print(C, B)
# C = C + B
# print(C)

# Approach 2:

# def ReverseValue(A, i, j):
#     while i < j:
#         B[i], B[j] = B[j], B[i]
#         i += 1
#         j -= 1
#     return B
#
# A = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
# B = A[::-1]
# print(B)
# print(ReverseValue(B, 0, 5))

# -------------------------------------------------------------------------------------------------------------------

# Given an integer array A and an integer B. You have to print the same array after rotating it B times towards right.
# First line begins with an integer |A| denoting the length of array, and then |A| integers denote the array elements.
# Second line contains a single integer B

# Input 1:
# 4 1 2 3 4
# 2

# Input 2:
#  3 1 2 2
#  3

# Output 1:
#  3 4 1 2
# Output 2:
#  1 2 2
#

# A = [int(item) for item in input().split()][1:]
# B = int(input())
# def checkRotation(L, intval):
#     if intval > len(L):
#         intval = intval%len(L)
#     M = L[-intval:]
#     N = L[:len(L) - intval]
#     P = M + N
#     print(*P)
#
# checkRotation(A, B)

# -------------------------------------------------------------------------------------------------------------------
# finding out the minimum number of operations required such that the maximum element of the resulting array is B.
# If it is not possible, then return -1.
#
# A = [2, 4, 3, 1, 5, 6]
# B = 3
#
# count = 0
# if B in A:
#     for i in range(len(A)):
#         if A[i] > B:
#             count += 1
#     print(count)
#
# else:
#     print('-1')

# -------------------------------------------------------------------------------------------------------------------
# You are given an integer array C of size A. Now you need to find a subarray (contiguous elements)
# so that the sum of contiguous elements is maximum.But the sum must not exceed B.

# A = [2, 3, 4, 5, 6]
# B = 9
# maxsum = 0
# for i in range(0, len(A)):
#     sum = 0
#     for j in range(i, len(A)):
#         sum += A[j]
#         if sum <= B:
#             maxsum = max(maxsum, sum)
# print(maxsum)
# -------------------------------------------------------------------------------------------------------------------
# You are given an integer array A. You have to find the second largest element/value in the array or
# report that no such element exists.

# def solve(A):
#     if len(A) == 1:
#         return -1
#
#     B = sorted(A)[-2]
#     return B
# A = [2, 1, 2]
# print(solve(A))

# -------------------------------------------------------------------------------------------------------------------
# You are given an array of integers A of size N.
# Return the difference between the maximum among all even numbers of A and the minimum among all odd numbers in A.

# A = [2, 1, 3, 4, 5, 6, 7]
# A = [-98, 54, -52, 15, 23, -97, 12, -64, 52, 85]
#
# def solve(A):
#     E = -1e9
#     O = 1e9
#     for i in A:
#         if i % 2 == 0:
#             if i > E:
#                 # print('E', i)
#                 E = i
#         else:
#             if i < O:
#                 # print('O', i)
#                 O = i
#     return (E - O)
#
# print(solve(A))

# # Approach 2:
# def solve(A):
#     return max([i for i in A if i % 2 == 0]) - min([i for i in A if i % 2])

# -------------------------------------------------------------------------------------------------------------------
# You are given an integer T denoting the number of test cases. For each test case, you are given an integer array A.
# You have to put the odd and even elements of array A in 2 separate arrays and print the new arrays.
# NOTE: Array elements should have the same relative order as in A.


# Input 1:
# 2
# 5
# 1 2 3 4 5
# 3
# 4 3 2
# Input 2:
#  2
#  3
#  2 2 2
#  2
#  1 1

# Output 1:
#  1 3 5
#  2 4
#  3
#  4 2
# Output 2:
#  2 2 2
#  1 1


# def GetEvenOdd(T):
#     E = []
#     O = []
#     for i in T:
#         if i % 2 == 0:
#             E.append(i)
#         else:
#             O.append(i)
#     E.append('')
#     O.append('')
#     return E, O

# A = input()
# for i in range(int(A)):
#     S = input()
#     T = [int(item) for item in input().split()]
#     X, Y= GetEvenOdd(T)
#     print(*Y)
#     print(*X)

# -------------------------------------------------------------------------------------------------------------------
# Multiple left rotations of the array
# Given an array of integers A and multiple values in B,
# which represents the number of times array A needs to be left rotated.
# Find the rotated array for each value and return the result in the from of a matrix where
# ith row represents the rotated array for the ith value in B.

# Input:
# A = [1, 2, 3, 4, 5]
# B = [2, 3]
#
# A = [5, 17, 100, 11]
# B = [1]

# A = [ 5, 17, 100, 11]
# B = [1]

# Output
# [[3, 4, 5, 1, 2] [4, 5, 1, 2, 3]]
# [ [17, 100, 11, 5] ]

# A = [6, 31, 33, 13, 82, 66, 9, 12, 69, 21, 17, 2, 50, 69, 90, 71, 31, 1, 13, 70, 94, 46, 89, 13, 55, 54, 67, 97, 28, 27, 62, 34, 41, 18, 15, 35, 13, 84, 93, 27, 89, 23, 6, 56, 94, 40, 54, 95, 47]
# B = [85, 49, 57]

#
# def solve(A, B):
#     G = []
#     for i in B:
#         if i >= len(A):
#             i = i % len(A)
#         C = A[:i]
#         D = A[-(len(A) - i):]
#         G.append(C + D)
#     return G

# def solve(A, B):
#     iterations = len(B)
#     size = len(A)
#     ans = []
#     for iteration in range(iterations):
#         B[iteration] %= size
#         newA = A[B[iteration]:] + A[:B[iteration]]
#         ans.append(newA)
#     return ans
# solve(A,B)
# -------------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------------
# You are given an integer array C of size A.
# Now you need to find a subarray (contiguous elements) so that the sum of contiguous elements is maximum.
# But the sum must not exceed B.
#
# def maxSubarray(A, B, C):
#     sumsubArray = 0
#     if min(C) > B:
#         return 0
#
#     for i in range(A):
#         for j in range(i, A):
#             print(j, C[j])
#             sumsubArray += C[j]
#             if sumsubArray == B:
#                 return sumsubArray
#     return sumsubArray
#
# A = 5
# B = 12
# C = [2, 1, 3, 4, 5]
# print(maxSubarray(A, B, C))

# -----------------------------------------------------------------------------------------------------------------
# A = [9650, 8208, 5737, 4539, 6893, 4718, 2903, 5284, 9419, 4591, 6034, 2003, 2420, 5058, 4876, 8259, 9205, 4797, 1819, 4618, 3871, 1167, 5862, 298, 9396, 6924, 9989, 3346, 2958, 1620, 2461, 731, 9769, 565, 6382, 9425, 6901, 4233, 1687, 3159, 3932, 198, 2355, 7501, 1466, 8881, 9387, 9254, 3023, 62, 75, 8489, 7403, 1982, 7058, 2290, 5542, 5023, 7218, 4292, 4082, 737, 912, 5741, 1297, 1354, 7655, 6994, 732, 1950, 2357, 7475, 8523, 8118, 5196, 8599, 5350, 3309, 2278, 3537, 1111, 4735, 62, 1012, 4163, 9058, 1789, 6032, 1748, 7169, 6797, 3237, 8110, 3734, 5607, 7474, 3223, 3420, 6228, 7265]
# if len(A) == 1 : 'NO'
#
# count = 0
# for i in range(1, len(A)):
#     if A[i] % 2 == 0:
#         count += 1
# if count % 2 == 0:
#     print('Yes')
# else:
#     print('No')

# -----------------------------------------------------------------------------------------------------------------
# def pow(a, p, n):
#     ans = 1
#     for i in range(n):
#         ans = (ans % p * a % p) % p
#     return ans
#
# print(pow(3, 6, 4))


# ans = 0
# A = 4545454
# a, p, n = 3, 6, 4
# for i in range(n):
#     ans = (ans + (A[i] % pow(a, p, n-i-1) % p)) % p
# print(ans)

# -----------------------------------------------------------------------------------------------------------------
# s = 'ABEC'
# n = len(s)
#
# for i in range(n):
#     for j in range(i+1, n+1):
#         print(s[i:j])

# -----------------------------------------------------------------------------------------------------------------
# Reverse the Array
# A = (42, 32, 65, 22, 9, 8, 20, 74, 74, 100, 39, 4, 36, 81, 19, 33, 87, 58, 26)
#
# def solve(A):
#     B = list(A)
#     print(B)
#     i, j = 0, len(B) - 1
#     while i < j:
#         B[i], B[j] = B[j], B[i]
#         i += 1
#         j -= 1
#     print(B)
# solve(A)
# ------------------------------------------------------------------------------------------------------------------
# SubArray

# Print a subArray
# A = [42, 32, 65, 22, 9, 8, 20, 74, 74, 100, 39, 4, 36, 81, 19, 33, 87, 58, 26]

# def PrintSubArray(A, s, e):
#     for i in range(s, e):
#         print(A[i], end='')
#     print()
# print(PrintSubArray(A, 0, len(A)))

# Sum of Array
# A = [42, 32, 65, 22, 9, 8, 20, 74, 74, 100, 39, 4, 36, 81, 19, 33, 87, 58, 26]
# A = [2, 3, 4, 5, 6]
# def SumSubArray(A, s, e):
#     sum = 0
#     for i in range(s, e):
#         sum += A[i]
#         print(sum)
#     return sum
# print(SumSubArray(A, 0, len(A)))

# ---------------------------------------------------------------------------------------------------
# Print All subArray
# totalcount = N * (N+1) /2


# Approach 1
# A = [2, 3, 4, 5, 6]
# start = 0
# for i in range(start, len(A)):
#     for j in range(i, len(A)):
#         for k in range(i, j+1):
#             print(A[k], end=' ')
#         print()

# Approach 2
# A = [2, 3, 4, 5, 6]
# start = 0
# for i in range(start, len(A)):
#     for j in range(i+1, len(A)+1):
#         print(*A[i:j])

# ------------------------------------------------------------------
# Print Sum of All subArray

# Approach 1 (Brut Force)
#
# A = [2, 3, 4, 5, 6]
# start = 0
# total = 0
# for i in range(start, len(A)):
#     for j in range(i, len(A)):
#         sum = 0
#         for k in range(i, j+1):
#             sum += A[k]
#             print(sum, end=' ')
#         total += sum
#         print()
# print(total)


# Approach 2 (Using Prefix Sum)

# A = [2, 3, 4, 5, 6]
# PS = [0]*len(A)
# PS[0] = A[0]
# for i in range(1, len(A)):
#     PS[i] = PS[i-1] + A[i]
# print(PS)
#
# start = 0
# sum = 0
# for i in range(start, len(A)):
#     for j in range(i, len(A)):
#         if i == 0:
#             sum += PS[j]
#         else:
#             sum += PS[j] - PS[i - 1]
#         print(sum, end= ' ')
#     print()


# Approach 3 (Using Two For loops)

# A = [2, 3, 4, 5, 6]
# total = 0
# for i in range(0, len(A)):
#     sum = 0
#     for j in range(i, len(A)):
#         sum += A[j]
#         total += sum
#         print(sum, end=' ')
#     print()
# print(total)

# Note: Subarray in which A[i] exist (i+1) * (N-i)
# Approach 4 (counting the array's count)

# A = [2, 3, 4, 5, 6]
# sum = 0
# for i in range(0, len(A)):
#     num_start = i + 1
#     num_end = len(A) - i
#     freq = num_start * num_end
#     sum += A[i] * freq
# print(sum)

# -----------------------------------------------------------------------------------------------
# You are given an integer array A of size N.You can pick B elements from either left or right end of array A
# to get the maximum sum.Find and return this maximum possible sum

# A = [5, -2, 3, 1, 2]
# B = 3
# ---------
# A = [1, 2]
# B = 1

# # Approach 1:  (Prefix Sum Array)
# def solve(A, B):
#     N = len(A)
#     # Creating PF(Prefix Sum Array)
#     PF = []
#     PF.append(A[0])
#     for i in range(1, N):
#         PF.append(PF[i - 1] + A[i])
#
#     print(PF)
#     # Finding max possible sum
#     if B == N:  # Case when B is equal to array length
#         return PF[N - 1]
#
#     max_sum = PF[N - 1] - PF[N - B - 1]
#     # case when all B elements are taken from right end.
#     # Initializing it to maz_sum
#
#     for i in range(B):
#         Sum = PF[i] + PF[N - 1] - PF[N - B + i]
#         print(Sum, PF[i], PF[N - 1], PF[N - B + i])
#         if Sum > max_sum:
#             max_sum = Sum
#
#     return max_sum
#
# print(solve(A, B))

# # Approach 2:
# def Sum(A, i, j):
#     sum = 0
#     for i in range(0, i):
#         sum += A[i]
#         print('i', i, A[i], sum,  end= ' ')
#     for k in range(j, len(A)):
#         sum += A[k]
#         print('k', k, A[k], sum, end= ' ')
#     return sum
#
# A = [ -55, -91, -791, 758, -779, -412, -578, -54, 506, 30, -587, 168, -100, -409, -238, 655, 410, -641, 624, -463, 548, -517, 595, -959, 602, -650, -709, -164, 374, 20, -404, -979, 348, 199, 668, -516, -719, -266, -947, 999, -582, 938, -100, 788, -873, -533, 728, -107, -352, -517, 807, -579, -690, -383, -187, 514, -691, 616, -65, 451, -400, 249, -481, 556, -202, -697, -776, 8, 844, -391, -11, -298, 195, -515, 93, -657, -477, 587, 314, 503, 448, 200, 458, -382, -420, 796, -202, 281, 589, -202, -991, 157, -528, 622, -462, -708, -962, -821, -810, 657, 958, -809, 815, -112, 156, 511, -798, -366, -728, -945, -672, -354, -638, -114, -125, -567, 869, -858, 844, 416, 881, 998, -678, -349, -979, 699, 557, -524, 892, -611, 75, -288, -400, -490, 3, -131, 861, -312, 401, 789, 255, -577, 2, -415, -818, -715, 88, 426, -383, 757, 832, -68, -831, -846, 721, 189, 976, 329, -632, -308, 425, -445, 434, -451, 441, 512, -855, -940, 718, 753, -861, -577, -721, 996, -313, -471, -451, 437, 866, -51, -807, 195, 297, -584, -714, -895, -512, -718, -545, 734, -886, 701, 316, -329, 786, -737, -687, -645, 185, -947, -88, -192, 832, -55, -687, 756, -679, 558, 646, 982, -519, -856, 196, -778, 129, -839, 535, -550, 173, -534, -956, 659, -708, -561, 253, -976, -846, 510, -255, -351, 186, -687, -526, -978, -832, -982, -213, 905, 958, 391, -798, 625, -523, -586, 314, 824, 334, 874, -628, -841, 833, -930, 487, -703, 518, -823, 773, -730, 763, -332, 192, 985, 102, -520, 213, 627, -198, -901, -473, -375, 543, 924, 23, 972, 61, -819, 3, 432, 505, 593, -275, 31, -508, -858, 222, 286, 64, 900, 187, -640, -587, -26, -730, 170, -765, -167, 711, 760, -104, -333, 285, -450, -860, 694, -305, 624, -981, -875, -424, 694, -342, -698, 371, -534, -322, -407, 851, 484, 18, -536, 119, 152, -200, -913, 60, 926, 10, -243, -830, -685, 576, -773, -957, -242, 164, 109, 882, 86, 565, 487, 577, -526, -375, 627, 629, 928, 423, -480, -98, -38, -877, -404, 737, 261, -805, -475, 264, -740, -798, -884, 30, -674, 11, -229, -589, 547, 153, 520, 790, -76, -812, 763, -60, -149, -338, 829, -100, 713, -42, 578, -635, 7, 477, 200, -942, -561, -697, -240, 357, -676, -523, 108, 113, -113, 801, -150, -540, -572, -7, 384, 405, -460, 111, -296, -165, -644, -928, 350, -177, -515, -444, 216, 626, 357, -474, 357, 337, 271, 869, 361, -104, 22, 617, -888, -283, -304, 585, -959, -577, -871, -771, -435, -441, -68, -704, 855, -947, -38, 584, 734, -346, -28, 457, -631, -468, -37, -393, -517, -89, 635, -933, -152, -325, -62, -777, -858, 754, -489, -259, -825, 459, 825, 221, 870, 626, 934, 205, 783, 850, 398, -721, -299, -807, -266, 637, -466, 556, 993, -824, 705, -38, -452, 881 ]
# B = 301
# start = B
# end = len(A)
# print(end)
# out = -100000
# while start >= 0:
#     total = Sum(A, start, end)
#     if out < total:
#         out = total
#     start -= 1
#     end -= 1
# print(out)


# A = [-533, -666, -500, 169, 724, 478, 358, -38, -536, 705, -855, 281, -173, 961, -509, -5, 942, -173, 436, -609, -396, 902, -847, -708, -618, 421, -284, 718, 895, 447, 726, -229, 538, 869, 912, 667, -701, 35, 894, -297, 811, 322, -667, 673, -336, 141, 711, -747, -132, 547, 644, -338, -243, -963, -141, -277, 741, 529, -222, -684, 35]
# B = 48

# A = [511, -798, -366, -728, -945, -672, -354, -638, -114, -125, -567, 869, -858, 844, 416, 881, 998, -678, -349, -979, 699, 557, -524, 892, -611, 75, -288, -400, -490, 3, -131, 861, -312, 401, 789, 255, -577, 2, -415, -818, -715, 88, 426, -383, 757, 832, -68, -831, -846, 721, 189, 976, 329, -632, -308, 425, -445, 434, -451, 441, 512, -855, -940, 718, 753, -861, -577, -721, 996, -313, -471, -451, 437, 866, -51, -807]
# B = 16
#
# A = [5, -2, 3, 1, 2]
# B = 3

#  Approach 3 : Without PS, TC(1),SC(1)
# def solve(A, B):
#     N = len(A) - 1
#     total = 0
#     out = -10000000000000
#     for i in range(0, B):
#         total += A[i]
#
#     while B > 0:
#         total = total - A[B - 1] + A[N]
#         if out < total:
#             out = total
#         B -= 1
#         N -= 1
#     print(out)

# -----------------------------------------------------------------------------------------------
# You are given an integer array A of length N.
# You are also given a 2D integer array B with dimensions M x 2, where each row denotes a [L, R] query.
# For each query, you have to find the sum of all elements from L to R indices in A (1 - indexed).


# A = [1, 2, 3, 4, 5]
# B = [[1, 4], [2, 3]]

# output: [10, 5]


# Brute Force Approach :
# def AddSum(A, B):
#     C = []
#     for i in B:
#         start = i[0]-1
#         end = i[1]
#         total = 0
#         for j in range(start, end):
#             total += A[j]
#         C.append(total)
#     return C
# print(AddSum(A, B))


# Approach 2: Using Prefix Sum
#
# A = [3, 7, 5]
# B = [[1, 1], [2, 3]]
#
# PS = []
# total = 0
# for i in A:
#     total += i
#     PS.append(total)
#
# C = []
# for i in B:
#     l, r, = i[0]-1, i[1]-1
#     if l == 0:
#         C.append(PS[r])
#     else:
#         C.append(PS[r] - PS[l - 1])
# print(C)


# # Approach 3 : Prefix Sum :
# def preCompute(arr, n, prefix):
#     prefix[0] = arr[0]
#     for i in range(1, n):
#         prefix[i] = prefix[i - 1] + arr[i]
#     # print(prefix)
#
# # Returns sum of elements in arr[i..j]
# # It is assumed that i <= j
# def rangeSum(l, r):
#     print(prefix)
#     if l == 0:
#         print(prefix[r])
#         return
#     print(r, l, prefix[r], prefix[l - 1], prefix[r] - prefix[l - 1])
#
# # Driver code
# arr = [1, 2, 3, 4, 5]
# n = len(arr)
# prefix = [0 for i in range(n)]
#
# print(arr)
#
# # preComputation
# print(preCompute(arr, n, prefix))
#
# # Range Queries
# print(rangeSum(1, 3))
# print(rangeSum(2, 4))
#
# -----------------------------------------------------------------------------------------------


# A = [834, 563, 606, 221, 165]
# def solve(A):
#     if len(A) == 1:
#         return 1
#
#     minval = min(A)
#     maxval = max(A)
#
#     print(minval, maxval)
#     outp = 10000
#     start = -1
#     end = -1
#     # 1 2 3 1 3 2 3 1
#     for i in range(len(A)):
#         if A[i] == minval:
#             start = i
#             print(start)
#         if A[i] == maxval:
#             end = i
#             print(end)
#         if start >= 0 and end >= 0:
#             ans = abs(start - end)
#             print(ans)
#             if ans < outp:
#                 outp = ans
#     return outp + 1
#
# print(solve(A))

# -----------------------------------------------------------------------------------------------







# ------------------------------------------------------------


# -----------------------------------------------------------------------------------------------

# -----------------------------------------------------------------------------------------------

arr = [ 1, 3, 3, 4, 5, 5, 8, 8, 8, 8]
def MaxArray(arr):
    mx = 0
    cnt = 0
    for e in arr:
        if e > mx:
            mx = e
            cnt = 1
        elif e == mx:
            cnt += 1
    return mx, cnt

print(MaxArray(arr))

# -----------------------------------------------------------------------------------------------

