# Check if given number is Even or Odd

# N = 11
# if N & 1 == 1:
#     print('odd')
# else:
#     print('Even')

# -----------------------------------------------------------------------------------------------------------------
# LeftShift, RightShift of Given Positive Number, i times

# # Right shift  =  N/2^i
# def RightShift(N, i):
#     return N >> i
# print(RightShift(8, 1))
#
# # # Left Shift = N * 2^i
# def LeftShift(N, i):
#     return N << i
# print(LeftShift(8, 1))

# -----------------------------------------------------------------------------------------------------------------
# Given two positive number, we have to check if the ith bit in N is set or not
# 110010
# Approach 1

# def checkBit(N, i):
#     return (N >> i) & 1
#
# print(checkBit(16, 3))

# Approach 2
# def checkBit(N, i):
#     if (N & (1 << i)) == 0:
#         return 0
#     else:
#         return 1
# print(checkBit(16, 4))

# ------------------------------------------------

# Binary to Decimal
# i = 0
# N = str(input())
# N = N[::-1]
# sum = 0
# for chr in N:
#     if chr != "0":
#         sum += 2 ** i
#         i += 1
#     else:
#         i += 1
# print(sum)



# Decimal To Binary
# ---------------------------------------------------
# Input
# 10
# 88
# 10
# 14
# 69
# 20
# 46
# 65
# 12
# 7
# 52
#
# def getBinary(N):
#     L = []
#     while(N > 0):
#         R = (N % 2)
#         N = (N // 2)
#         L.append(R)
#
#     L = L[::-1]
#     print(*L, sep='')
#
# L = []
# N = int(input())
# for i in range(1, N+1):
#     i = int(input())
#     L.append(i)
# print(L)
#
# for j in range(0, len(L)):
#     getBinary(L[j])
#

# -----------------------------------------------------------------------------------------------------------------

# Given 2 numbers N, i, set the i-th bit
# N = 1010, i = 3

# def Setibit(N, i):
#     M = N | (1 << i)
#     return M
#
# print(Setibit(10, 3))

# -----------------------------------------------------------------------------------------------------------------
# 1111
# Given 2 Number N, i : Unset the i-th bit

# def UnsetBit(N, i):
#     M = N & (~(1 << i))
#     return M
#
# print(UnsetBit(15, 3))


# 1111  # 8+4+2+1 = 15

# def UnsetBit(N, i):
#     if ((N >> i) & 1) == 1:
#         N ^= 1 << i
#         print(N)
#     else:
#         print(N)
# UnsetBit(15, 3)

# -----------------------------------------------------------------------------------------------------------------

# ~(1 << i) Condition
# for i in range(10):
#     C = "{0:b}".format(i)
#     D = "{0:b}".format(~i)
#     E = "{0:b}".format(~(1 << i))
#
#     print(i, C, D, E, (1 << i), (~(1 << i)))

# -----------------------------------------------------------------------------------------------------------------

# Toggle ith Bit
# 1010
# def ToggleBit(N, i):
#     return N ^ (1 << i)
# print(ToggleBit(10, 2))

# -----------------------------------------------------------------------------------------------------------------
# Given number N, Toggle all the bits starting from the right most set bit

# N = 20  # 10100
#
# def ToglleFromGivenbit(N):
#     if N == 0:
#         return 0
#     return N-1
#
# print(ToglleFromGivenbit(N))

# -----------------------------------------------------------------------------------------------------------------
# Given an array of integers A, every element appears twice except for one. Find that integer that occurs once.
#
# A = [1, 2, 2, 3, 1]
#
# def singleNumber(A):
#     ans = 0
#     for i in A:
#         print(ans, i)
#         ans = ans ^ i
#         print(ans)
#     return ans
# print(singleNumber(A))

# -----------------------------------------------------------------------------------------------------------------

# Given two binary strings, return their sum (also a binary string).
# x = '1111'
# y = '110'
# maxlen = max(len(x), len(y))
# x = x.zfill(maxlen)
# y = y.zfill(maxlen)
#
# print(x, y)
# result = ''
# carry = 0
# for i in range(maxlen-1, -1, -1):
#     print(i, x[i], y[i])
#     r = carry
#     r += 1 if x[i] == '1' else 0
#     print('r', r)
#     r += 1 if y[i] == '1' else 0
#     print('s', r)
#     result = ('1' if r % 2 == 1 else '0') + result
#     print('result', result)
#     carry = r//2
# if carry != 0:
#     result = '1' + result
# print(result)

# -----------------------------------------------------------------------------------------------------------------
# Approach: 1
# A = 2
# R = ''
# C = 0
# while A >= 1:
#     B = A % 2
#     if B == 1:
#         C += 1
#     A = A // 2
# print(C)

# Approach : 2
# def numSetBits(A):
#     ret = 0
#     while A != 0:
#         if A & 1:
#             ret += 1
#         A = A >> 1
#     return ret
# print(numSetBits(2))

# -----------------------------------------------------------------------------------------------------------------
# Reverse the bits of an 32-bit unsigned integer A.
# A = 8
# R = ''
# while A >= 1:
#     B = A % 2
#     R += str(B)
#     A = A // 2
#
# B = str(R)[::-1]
#
# out = 0
# B = B.zfill(32)
# for i in range(len(B)):
#     if B[i] == '1':
#         out += pow(2, i)
# print(out)

#
# def checkBit(N, i):
#     B = 1 << i
#     # print(B)
#     if (N & B) == 0:
#         return N
#     else:
#         return N
# print(checkBit(10, 2))

# -------------------------------------------------------------------------------------------------------------------
# Q: Count the num of set bits in Number
# N = 27 # 11011
# count = 0
# while N > 0:
#     if N & 1:
#         count += 1
#     N = N >> 1
# print(count)

# count = 0
# while N > 0:
#     count += 1
#     N = N & N-1
# print(count)

# -------------------------------------------------------------------------------------------------------------------

# def solve(A):
#     count = 0
#     while (A != 0):
#         if A & 1:
#             print(A & 1)
#             count += 1
#         A = A >> 1
#         print(A)
#     return count
#
# print(solve(5))

# print(-40%7)

# -------------------------------------------------------------------------------------------------------------------
# Write a function that takes an integer and returns the number of 1 bits it has.

# Approach -1
# def numSetBits(A):
#   count = 0#
#   while A > 0:
#      A, rem = divmod(A, 2)
#      print(A, rem)
#      if rem == 1:
#        count = count + 1
#
#   return count
# print(numSetBits(9))

# Approach -2
# def Newnum(A):
#     count = 0
#     while A > 0:
#         rem = A % 2
#         A = A // 2
#         if rem == 1:
#             count += 1
#     return count
# print(Newnum(20))

# Approach- 3
# def numSetBits(A):
#     ret = 0
#     while A != 0:
#         if A & 1:
#             ret += 1
#         A = A >> 1
#     return ret
# print(numSetBits(28))

# -------------------------------------------------------------------------------------------------------------------
# B= [1, 3, 5]
#
# for i in range(len(B)):
#     for j in range(0, len(B)):
#         C = B[i]^B[j]
#         ret = 0
#         while C > 0:
#             if C & 1 == 1:
#                 ret += 1
#             C = C >> 1
#         print(ret)
#
# A = 7
# # -------------------------------------------------------------------------------------------------------------------
# # Given N elements calculate sum of xor of # all pairs
#
# A = [3, 5, 6, 8, 2]
#
# def checkBit(N, i):
#     return (N >> i) & 1
#
# sum = 0
# for i in range(32):
#     set = 0
#     unset = 0
#     for j in range(len(A)):
#         print(i, j)
#         if checkBit(A[j], i) == 1:
#             set += 1
#         else:
#             unset += 1
#
#     bits = set * unset
#
#     sum  = sum + (bits * (1 << i))
#     print(sum)
# sum = sum
#
# print(sum)

