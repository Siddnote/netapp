import math as mt

def solve(A):
    a = A
    n = len(A)
    print(a, n)
    Prefix = [0 for i in range(n + 2)]
    Suffix = [0 for i in range(n + 2)]
    print(Prefix, Suffix)
    # Single state dynamic programming relation # for storing gcd of first i elements   # from the left in Prefix[i]
    Prefix[1] = a[0]
    for i in range(2, n + 1):
        Prefix[i] = mt.gcd(Prefix[i - 1], a[i - 1])
        print(Prefix[i])

    print(Prefix, Suffix)

    # Initializing Suffix array
    Suffix[n] = a[n - 1]

     # Single state dynamic programming relation # for storing gcd of all the elements having # greater than or equal to i in Suffix[i]
    for i in range(n - 1, 0, -1):
        Suffix[i] = mt.gcd(Suffix[i + 1], a[i - 1])

    print(Prefix, Suffix)

    # If first or last element of  # the array has to be removed
    ans = max(Suffix[2], Prefix[n - 1])
    print('ans', ans)

    # If any other element is replaced
    for i in range(2, n):
        ans = max(ans, mt.gcd(Prefix[i - 1], Suffix[i + 1]))

    # Return the maximized gcd
    return ans

A = [12, 15, 18]
print(solve(A))
