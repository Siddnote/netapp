
# Count of values using Dictionary

# A = [1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 2, 7]
# hasmap = {}
# for i in range(len(A)):
#     if A[i] in hasmap:
#         hasmap[A[i]] += 1
#     else:
#         hasmap[A[i]] = 1
# print(hasmap)
# print(hasmap.get(10))

# -------------------------------------------------------------------------------------------------------------------
# Given an integer array A of size N, find the first repeating element in it.
# We need to find the element that occurs more than once and whose index of the first occurrence is the smallest

# A = [10, 5, 3, 4, 3, 5, 6]
#
# def solve(A):
#     hasmap = {}
#     for i in range(len(A)):
#         if A[i] in hasmap:
#             hasmap[A[i]] += 1
#         else:
#             hasmap[A[i]] = 1
#     print(hasmap)
#
#     for i in A:
#         print(i)
#         if hasmap[i] > 1:
#             return i
#             # break
#     return -1
#
# print(solve(A))

# -------------------------------------------------------------------------------------------------------------------
# Find the first non-repeating Number

# A = [20, 1, 2, 10, 20, 1, 3, 2, 6]
#
# def Check(A):
#     hasmap = {}
#     for i in range(len(A)):
#         if A[i] in hasmap:
#             hasmap[A[i]] += 1
#         else:
#             hasmap[A[i]] = 1
#     print(hasmap)
#     for i in A:
#         if hasmap[i] < 2:
#             return i
#
# print(Check(A))

# -------------------------------------------------------------------------------------------------------------------
# How to creat set and add value and Multiple value
# S = set()
# S.add(2)
# S.add(5)
# S = set([3, 6, 1, 9, -2, 4, 6, 3, -1, 6])
# -------------------------------------------------------------------------------------------------------------------

# Check if there is a subarray with sum 0

# A = [3, 6, 1, -9, -2, 4, 6, 3, -1, 6]
# A = [2, -1, 3, -4, 6]


# # Prefix Sum can be done using below method
# PS = []
# sum = 0
# for i in A:
#     sum += i
#     PS.append(sum)
# print(PS)
#
# def checkSubArrayZero(A):
#     S = set()
#     PS = [0] * len(A)
#     PS[0] = A[0]
#     for i in range(0, len(A)):
#         PS[i] = PS[i - 1] + A[i]
#     print('PS', PS)
#     for i in range(len(A)):
#         if PS[i] == 0:
#             return 1
#         elif PS[i] in S:
#             return 1
#         else:
#             S.add(PS[i])
#     return 0
#
# print(checkSubArrayZero(A))
# -------------------------------------------------------------------------------------------------------------------
# Unsolved
# Check if there is subarray with sum  = k
# A = [3, 6, 1, -9, -2, 4, 6, 3, -1, 6]
# k = 10
# print(A)
# PS = []
# sum = 0
# for i in A:
#     sum += i
#     PS.append(sum)
# print('PS', PS)
#
# HM = {}
# for i in range(len(PS)):
#     if PS[i] in HM:
#         HM[PS[i]] += 1
#     else:
#         HM[PS[i]] = 1
# print('HM', HM)
#
# for i in range(len(PS)):
#     val = PS[i] - k
#     print('val', PS[i], val)
#     if val in HM:
#         print(i, 'true')


# -------------------------------------------------------------------------------------------------------------------
# Unsolved
# Given an array A of N integers.
# Find the largest continuous sequence in array which sums to zero.
#
# S = set()
# A = [1, 2, -2, 4, -4, 3, 7, -7, 6, -6, 8, -8]
# # A = [-19, 8, 2, -8, 19, 5, -2, -23 ]
# print(A)
# PS = [0]*len(A)
# PS[0] = A[0]
# for i in range(1, len(A)):
#     PS[i] = PS[i-1] + A[i]
# print('PS', PS)
#
#
# len_max = 0
# left = -1
# right = -1
# hasmap = {}
# D = [1, 2, 3, -6]
# P = [1, 3, 6, 0]
# # hasmap[0] = -1
# for i in range(len(PS)):
#     if PS[i] == 0:
#         len_max = i + 1
#         left = 0
#         right = i
#
#     if PS[i] in hasmap:
#         k = hasmap[PS[i]]  # k is index
#         print('if', i, k, PS[i], hasmap[PS[i]], len_max)
#         currentsubarraylen = i -k
#         if currentsubarraylen > len_max:
#             # left_max calculation
#             # [left, right] = right - left + 1
#             # i- (k+ 1) + 1 = i -k
#             len_max = currentsubarraylen
#             left = k + 1
#             right = i
#     else:
#         hasmap[PS[i]] = i
#     print(i, len_max, left, right)
# print(hasmap)
# if len_max == 0:
#     print('')
# else:
#     for i in range(left, right+1):
#         print(A[i], end=' ')
#
# # print(A)
# def lszero(A):
#     ans = []
#     dictionary = {}
#     sumofele = 0
#     prefix = []
#     # Generate prefix array
#     for i in range(len(A)):
#         sumofele += A[i]
#         prefix.append(sumofele)
#     print(prefix)
# # Loop through the array and check if you find same # else (using dictionary) or 0: if you do,
# # update the ans if the length of the new ans is more
#     for i in range(len(prefix)):
#         if prefix[i] == 0:
#             if i + 1 > len(ans):
#                 ans = A[:i + 1]
#         if prefix[i] in dictionary:
#             if i - dictionary[prefix[i]] > len(ans):
#                 ans = A[dictionary[prefix[i]] + 1: i + 1]
#         else:
#             print('else')
#             dictionary[prefix[i]] = i
#
#     return ans
#
# print(lszero(A))
# -------------------------------------------------------------------------------------------------------------------
# Shaggy has an array A consisting of N elements.
# We call a pair of distinct indices in that array a special if elements at those indices in the array are equal.
# Shaggy wants you to find a special pair such that the distance between that pair is minimum.
# Distance between two indices is defined as |i-j|. If there is no special pair in the array, then return -1.

# A = [7, 1, 3, 4, 1, 7]
#
# def Check(A):
#     out = 100000
#     hasmap = {}
#     for i in range(len(A)):
#         if A[i] in hasmap:
#             hasmap[A[i]] = abs(hasmap[A[i]] - i)
#             if hasmap[A[i]] < out:
#                 out = hasmap[A[i]]
#         else:
#             hasmap[A[i]] = i
#
#     if out != 100000:
#         return out
#     else:
#         return -1
#
# print(Check(A))


# def solve(A):
#     mydict = {}
#     ans = 1000000000
#     c = 0
#     for i in A:
#         if i in mydict:
#             ans = min(ans, c - mydict[i])
#             mydict[i] = c
#         else:
#             mydict[i] = c
#         c = c + 1
#     if ans == 1000000000:
#         ans = -1
#     return ans
#
# print(solve(A))

# -------------------------------------------------------------------------------------------------------------------
# Given two integer arrays, A and B of size N and M, respectively.
# Your task is to find all the common elements in both the array.

# A = [1, 2, 2, 1]
# B = [2, 3, 1, 2]

# A = [2, 1, 4, 10]
# B = [3, 6, 2, 10, 10]
#
# C = []
# HM = {}
# for i in range(len(A)):
#     if A[i] in HM:
#         HM[A[i]] += 1
#     else:
#         HM[A[i]] = 1
# print(HM)
# for i in range(len(B)):
#     if B[i] in HM:
#         C.append(B[i])
#         HM[B[i]] -= 1
#         if HM[B[i]] == 0:
#             HM.pop(B[i])
# print(C)
# -------------------------------------------------------------------------------------------------------------------
# Find a pair (i,j) such that A[i] + A[j] = k, where i != j
#
# A = [1, 4, -2, 8, -9, 14, 25, 22, 17, 13]
#
# def checkexist(A):
#     S = set()
#     K = 22
#     for i in range(len(A)):
#         print(i, A[i], S)
#         if (K - A[i]) in S:
#             return 1
#         else:
#             S.add(A[i])
#     print(S)
#     return 0
#
# print(checkexist(A))

# -------------------------------------------------------------------------------------------------------------------
# Find a pair (i,j) such that A[i] - A[j] = k
#
# A = [1, 6, -2, 8, -9, 14, 25, 22, 17, 13]
# B = 5
# start = 0
# end = 0
# Sum = A[0]
# n = len(A)
# print(A)
# while start < n and end < n:
#     if Sum == B:
#         print('Sum == B', A[start:end + 1])
#         print(A[start:end + 1])
#         break
#     elif Sum < B:
#         end += 1
#         print('end', end)
#         if end != n:
#             Sum += A[end]
#             print('Sum += ', Sum)
#     else:
#         Sum -= A[start]
#         print('Sum -= ', Sum)
#         start += 1
#         print('start -= ', start)
# print('-1')

# Approach 2 :
# A = [1, 3, 2]
# B = 0
# # x = B  +  y
#
# def diffPossible(A, B):
#     S = set(A)
#
#     if B == 0:
#         if len(A) == len(S):
#             return 0
#         else:
#             return 1
#     if len(A) == 1:
#         return 0
#     for i in range(len(A)):
#         C = abs(A[i] + B)
#         if C in S:
#             return 1
#     return 0
#
# diffPossible(A, B)

# -------------------------------------------------------------------------------------------------------------------

#
# A = [1000274, 1000802, 1000914, 1000847, 1000073, 1000562, 1000741, 1000802, 1000965, 1000371, 1000406, 1000441, 1000179, 1000802, 1000552, 1000802, 1000100, 1000724, 1000024, 1000134, 1000313, 1000802, 1000977, 1000777, 1000206, 1000412, 1000802, 1000570, 1000802, 1000518, 1000691, 1000959, 1000903, 1000802, 1000802, 1000273, 1000802, 1000802, 1000265, 1000706, 1000677, 1000802, 1000843, 1000802, 1000061, 1000802, 1000802, 1000975, 1000403, 1000150, 1000959, 1000889, 1000177, 1000416, 1000491, 1000177, 1000807, 1000989, 1000489, 1000447, 1000802, 1000860, 1000104, 1000802, 1000570, 1000015, 1000802, 1000802, 1000593, 1000802, 1000802, 1000326, 1000802, 1000802, 1000120, 1000772, 1000965, 1000802, 1000887, 1000802, 1000567, 1000973, 1000577, 1000820, 1000922, 1000802, 1000982, 1000525, 1000369, 1000829, 1000740, 1000159, 1000909, 1000510, 1000402, 1000802, 1000802, 1000239, 1000247, 1000328, 1000427, 1000802, 1000519, 1000296, 1000114, 1000149, 1000802, 1000802, 1000107, 1000841, 1000017, 1000909, 1000192, 1000425, 1000088, 1000077, 1000506, 1000163, 1000465, 1000626, 1000371, 1000802, 1000179, 1000306, 1000159, 1000802, 1000802, 1000848, 1000138, 1000306, 1000802, 1000881, 1000828, 1000802, 1000008, 1000802, 1000456, 1000802, 1000880, 1000579, 1000434, 1000163, 1000188, 1000802, 1000802, 1000231, 1000945, 1000802, 1000070, 1000727, 1000802, 1000802, 1000802, 1000051, 1000644, 1000802, 1000802, 1000057, 1000967, 1000802, 1000802, 1000366, 1000802, 1000485, 1000802, 1000061, 1000212, 1000192, 1000577, 1000559, 1000802, 1000189, 1000802, 1000802, 1000107, 1000177, 1000011, 1000802, 1000987, 1000400, 1000802, 1000402, 1000024, 1000009, 1000118, 1000046, 1000349, 1000250, 1000282, 1000138, 1000405, 1000295, 1000802, 1000878, 1000166, 1000802, 1000135, 1000005, 1000723, 1000491, 1000802, 1000802, 1000802, 1000802, 1000786, 1000306, 1000802, 1000802, 1000802, 1000639, 1000683, 1000880, 1000329, 1000408, 1000822, 1000947, 1000802, 1000455, 1000037, 1000311, 1000802, 1000802, 1000339, 1000802, 1000519, 1000401, 1000802, 1000256, 1000802, 1000802, 1000503, 1000802, 1000787, 1000802, 1000802, 1000384, 1000456, 1000845, 1000802, 1000802, 1000000, 1000213, 1000629, 1000802, 1000226, 1000802, 1000802, 1000107, 1000100, 1000802, 1000587, 1000882, 1000049, 1000623, 1000802, 1000178, 1000788, 1000648, 1000802, 1000567, 1000802, 1000802, 1000802, 1000085, 1000109, 1000965, 1000353, 1000802, 1000802, 1000802, 1000982, 1000663, 1000829, 1000578, 1000753, 1000802, 1000802, 1000529, 1000060, 1000047, 1000802, 1000750, 1000780, 1000277, 1000802, 1000751, 1000590, 1000802, 1000953, 1000240, 1000218, 1000659, 1000802, 1000001, 1000766, 1000802, 1000508, 1000802, 1000802, 1000802, 1000028, 1000802, 1000493, 1000077, 1000427, 1000505, 1000752, 1000802, 1000747, 1000126, 1000269, 1000297, 1000394, 1000257, 1000708, 1000802, 1000802, 1000697, 1000802, 1000802, 1000802, 1000921, 1000559, 1000450, 1000206, 1000802, 1000802, 1000149, 1000031, 1000866, 1000721, 1000497, 1000654, 1000057, 1000802, 1000130, 1000523, 1000577, 1000750, 1000536, 1000339, 1000796, 1000802, 1000802, 1000197, 1000584, 1000939, 1000802, 1000633, 1000553, 1000124, 1000086, 1000619, 1000802, 1000415, 1000802, 1000125, 1000802, 1000104, 1000348, 1000464, 1000187, 1000887, 1000369, 1000281, 1000802, 1000802, 1000526, 1000685, 1000029, 1000922, 1000191, 1000802, 1000802, 1000802, 1000298, 1000802, 1000176, 1000295, 1000802, 1000802, 1000238, 1000802, 1000802, 1000314, 1000303, 1000802, 1000698, 1000309, 1000677, 1000606, 1000802, 1000701, 1000898, 1000579, 1000990, 1000513, 1000435, 1000192, 1000960, 1000324, 1000509, 1000906, 1000802, 1000492, 1000705, 1000641, 1000479, 1000662, 1000642, 1000791, 1000942, 1000802, 1000802, 1000100, 1000296, 1000802, 1000802, 1000533, 1000802, 1000038, 1000802, 1000254, 1000802, 1000802, 1000802, 1000802, 1000393, 1000802, 1000435, 1000484, 1000802, 1000847, 1000802, 1000360, 1000961, 1000544, 1000914, 1000802, 1000802, 1000663, 1000802, 1000802, 1000519, 1000802, 1000928, 1000802, 1000802, 1000802, 1000802, 1000258, 1000108, 1000544, 1000802, 1000169, 1000097, 1000802, 1000306, 1000977, 1000802, 1000153, 1000802, 1000802, 1000039, 1000099, 1000802, 1000468, 1000862, 1000802, 1000802, 1000802, 1000068, 1000802, 1000161, 1000179, 1000710, 1000802, 1000802, 1000802, 1000802, 1000540, 1000802, 1000115, 1000802, 1000802, 1000089, 1000802, 1000798, 1000802, 1000802, 1000544, 1000979, 1000850, 1000085, 1000197, 1000802, 1000802, 1000031, 1000704, 1000515, 1000802, 1000198, 1000382, 1000597, 1000613, 1000857, 1000798, 1000319, 1000266, 1000154, 1000753, 1000017, 1000004, 1000802 ]
#
# # Approach 1
# def repeatedNumber(A):
#     HM = {}
#     for i in range(len(A)):
#         if A[i] in HM:
#             HM[A[i]] += 1
#         else:
#             HM[A[i]] = 1
#     print(HM)
#     inval = len(A) // 3
#     print(inval)
#
#     for key, value in HM.items():
#         print(value, inval)
#         if value > inval:
#             print(key, value)
#             return key
#     return -1
#
# repeatedNumber(A)

# Approach 2
# print(A)
#
# import sys
#
# def appearsNBy3(arr, n):
#     count1 = 0
#     count2 = 0
#     first = sys.maxsize
#     second = sys.maxsize
#
#     for i in range(0, n):
#         if (first == arr[i]):
#             count1 += 1
#
#         elif (second == arr[i]):
#             count2 += 1
#
#         elif (count1 == 0):
#             count1 += 1
#             first = arr[i]
#
#         elif (count2 == 0):
#             count2 += 1
#             second = arr[i]
#
#         else:
#             count1 -= 1
#             count2 -= 1
#
#     count1 = 0
#     count2 = 0
#
#     # Again traverse the array and find the actual counts.
#     for i in range(0, n):
#         if (arr[i] == first):
#             count1 += 1
#
#         elif (arr[i] == second):
#             count2 += 1
#
#     if (count1 > n / 3):
#         return first
#
#     if (count2 > n / 3):
#         return second
#
#     return -1
#
#
# # Driver code
#
# # arr = [1, 2, 3, 1, 1]
# arr = A
# n = len(arr)
# print(appearsNBy3(arr, n))
#

#  Two Sum
# import math

# def twoSum(A, B):
#     HM = {}
#     for i in range(len(A)):
#         if A[i] in HM:
#             HM[A[i]] += 1
#         else:
#             HM[A[i]] = i
#     print(HM)
#
#     for key, value in HM.items():
#         total = abs(B - key)
#         print('total', total)
#         if total in HM.keys():
#             print('value', value)
#         print(key, value)
#
# A = [2, 7, 11, 15]
# B = 9
# twoSum(A, B)

# -------------------------------------------------------------------------------------------------------------------
# Given a number A, find if it is COLORFUL number or not. If number A is a COLORFUL number return 1 else, return 0.

# What is a COLORFUL Number:
# A number can be broken into different contiguous sub-subsequence parts. Suppose, a number 3245 can be broken into
# parts like 3 2 4 5 32 24 45 324 245. this number is a COLORFUL number,
# since product of every digit of a contiguous subsequence is different.

# Approach 1
#
# def findProd(A):
#     ret = 1
#     for a in A:
#         ret *= int(a)
#     return str(ret)
#
# def colorful(A):
#     numbers = dict()
#     strA = str(A)
#     for a in strA:
#         if a in numbers:
#             return 0
#         else:
#             numbers[a] = 1
#
#     n = len(strA)
#
#     for i in range(2, n + 1):
#         for j in range(n - i + 1):
#             num = strA[j: j + i]
#             print('num', num)
#             ret = findProd(num)
#             print('ret', ret)
#             if ret in numbers:
#                 return 0
#             else:
#                 numbers[ret] = 1
#     return 1
#
# A = 3245
# print(colorful(A))

# Approach 2
# def multiplyList(self, myList):
#     # Multiply elements one by one
#     result = 1
#     for x in myList:
#         result = result * x
#     return result
#
# def colorful(self, A):
#     S = set()
#     lst = []
#     lst.extend(str(A))
#     for i in range(0, len(lst)):
#         M = 1
#         for j in range(i + 1, len(lst) + 1):
#             N = lst[i:j]
#             P = list(map(int, N))
#             K = self.multiplyList(P)
#             if K not in S:
#                 S.add(K)
#             else:
#                 return 0
#     return 1

# -------------------------------------------------------------------------------------------------------------------

# def getSum(B, C):
#     HM = {}
#     for i in range(len(C)):
#         if C[i] in HM:
#             HM[C[i]] += 1
#         else:
#             HM[C[i]] = 1
#     print(HM)
#     total = 0
#     flag = False
#     for key, value in HM.items():
#         if value == B:
#             total += key
#             flag = True
#
#     if flag == False:
#         return -1
#     else:
#         return total
#
# B = 2
# C = [0, 0, 1 ]
# #[ 1, 2, 3, 4, 5 ]
#
# print(getSum(B,C))

# -------------------------------------------------------------------------------------------------------------------
# A = [1, 2, 1, 3, 4, 3]
# B = 3

# Approach 1 : TLE
# out = []
# for i in range(0, len(A)-B+1):
#     S = set()
#     for j in range(i, i + B):
#         S.add(A[j])
#     out.append(len(S))
# print(out)

# # Approach - 2
# print(A)
# start = 0
# end = B
# out = []
#
# CW = A[start:end]
# S = set(CW)
# out.append(len(set(CW)))
# while end < len(A):
#     S.remove(A[start])
#     S.add(A[end])
#     out.append(len(set(CW)))
#     start += 1
#     end += 1
# print(out)

## Approach 3
# print(A)

# def countNum(A, B):
#     N = len(A)
#     HM = {}
#     lst = []
#     cnt = 0
#
#     for i in range(B):
#         if A[i] in HM:
#             HM[A[i]] += 1
#         else:
#             HM[A[i]] = 1
#             cnt += 1
#     lst.append(cnt)
#
#     print(HM, cnt)
#
#     for i in range(B, N):
#         if A[i - B] in HM:
#             HM[A[i - B]] -= 1
#             if HM[A[i - B]] == 0:
#                 HM.pop(A[i - B])
#                 cnt -= 1
#         if A[i] in HM:
#             HM[A[i]] += 1
#         else:
#             HM[A[i]] = 1
#             cnt += 1
#         lst.append(cnt)
#     # print(lst)
# countNum(A, B)

#-------------------------------------------------------------------------------------------------------------------

# Two sum

# Online Python compiler (interpreter) to run Python online.
# Write Python 3 code in this online editor and run it.
# def printPairs(arr, arr_size, sum):
#     # Create an empty hash map
#     # using an hashmap allows us to store the indices
#     hashmap = {}
#
#     for i in range(0, arr_size):
#         temp = sum - arr[i]
#         if (temp in hashmap):
#             print(f'Pair with given sum {sum} is ({temp},{arr[i]}) at indices ({hashmap[temp]},{i})')
#         hashmap[arr[i]] = i
#
# # driver code
# A = [1, 4, 45, 6, 10, 8]
# n = 16
# printPairs(A, len(A), n)

A = [5, 4, 10, 15, 7, 6]
B= 5
hashset = set()
res = 0
for elem in A:
    temp = B ^ elem
    if temp in hashset:
        res += 1
    else:
        hashset.add(elem)

print(res)


