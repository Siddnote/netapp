# -------------------------------------------------------------------------
# Given an integer array A of size N and an integer B, you have to print
# the same array after rotating it B times towards the right.

# Input 1 :
# 4 1 2 3 4
# 2
#
# def Reverse(arr, S, E):
#     while S < E:
#         arr[S], arr[E] = arr[E], arr[S]
#         S += 1
#         E -= 1
#
# A = [int(item) for item in input().split()][1:]
# B = int(input())
#
# B = B % len(A)
# Reverse(A, 0, len(A) - 1)
# Reverse(A, 0, B - 1)
# Reverse(A, B, len(A) - 1)
# print(*A, end=' ')
# ------------------------------------------------------------

# # Given an array, Find the maximum value in it
#
# A = [2, 3, -5, 6, 7, 8, 4, 9,-20]
# print(max(A))
# print(min(A))
#
# def FindMaxMinValue(arr):
#     maxval = -float('inf')
#     minval = float('inf')
#     for i in A:
#         if i > maxval:
#             maxval = i
#         if i < minval:
#             minval = i
#     return maxval, minval
#
# print(FindMaxMinValue(A))
#
# A = [2, 3, -5, 6, 7, 8, 4, -23]
# def FindMinMaxValue(arr):
#     min = arr[0]
#     max = arr[0]
#     for i in range(1, len(A)):
#         if arr[i] < min:
#             min = arr[i]
#         if arr[i] > max:
#             max = arr[i]
#
#     return min,max
# print(FindMinMaxValue(A))

# ----------------------------------------------------------
# A = [1, 2, 3, 1, 2, 4]
# A = [2308, 1447, 1918, 1391, 2308, 216, 1391, 410, 1021, 537, 1825, 1021, 1729, 669, 216, 1825, 537, 1995, 805, 410, 805, 602, 1918, 1447, 90, 1995, 90, 1540, 1161, 1540, 2160, 1235, 1161, 602, 880, 2160, 1235, 669 ]
#
# B = {}
# for i in range(len(A)):
#     if A[i] not in B.keys():
#         B[A[i]] = 1
#     else:
#         B[A[i]] = B.get(A[i]) + 1
#
# C = []
# for i in B:
#     if B.get(i) == 1:
#         C.append(i)
# C.sort()
# print(C)


# A = ['S', 'c', 'A', 'l', 'e', 'r', 'A', 'c', 'a', '#', 'D', 'e', 'm', 'y']
# B = []
# def to_lower(A):
#     for i in range(len(A)):
#         t = str.lower(A[i])
#         B.append(t)
#     return B
# to_lower(A)

#----------------------------------------------------------
# name = input()
# print("Welcome", input());

# s = 5^6
# print("hello","siddhant", "lear", sep='\n', end ="")

# counter = 1
# while counter <= 10:
#     print(counter, end=' ')
#     counter += 1

# n = int(input())
#
# i = 1
# while i <= n:
#     print("*" * i)
#     i += 1


# for i in range(1, 5):
#     for j in range(1, i+1):
#         print(j, end=' ')
#     print()

# -------------
# n = int(input())
# for i in range(1, n+1):
#     print("*" * i)
# --------------

# n = int(input())
#
# for i in range(1, n+1):
#     for j in range(1, i+1):
#         print(j, end=' ')
#     print()

# n = int(input())
#
# value = 65
# for i in range(0, n):
#      for j in range(0, i):
#          ch= chr(value)
#          print(ch, end=' ')
#      cha= chr(value)
#      value += 1
#      print(cha)


# n = int(input())
#
# for i in range(1, n+1):
#     for j in range(1, i):
#         print(j, end=' ')
#     print(i)


# print(list(range(1,11)))
# print(list(range(0,11,2)))

# for i in range(9,0,-2):
#     print(i**3, end=' ')

# print(list(range(9,0,-2)))

# for c in "welcome":
#     print(c, end= ' ')

#### Sum of all digit
# N = input("")
# print(range(len(N)))
# total = 0
# for i in range(len(N)):
#     total += int(N[i])
# print(total)

#### Sum of Digits
# n = int(input())
# sum = 0
# while n>0:
#     digit = n % 10
#     sum += digit
#     n = n//10
# print(sum)

## Reverse Number Patten
# n = int(input())
#
# for i in range(n, 0, -1):
#     for j in range(1, i):
#         print(j,end=' ')
#         j +=1
#     print(i)

# import  random
# n = int(input())
#
# while True:
#     r = random.randint(1, 10 )
#     print(r, end=' ')
#     if r== 5:
#       break


# for i in range(2,100, 2):
#     if i%3 != 0:
#         print(i, end=' ')
#
# print()
# for i in range(2,100,2):
#     if i%3 ==0:
#         continue
#     print(i, end= ' ')


# n = int(input())
# isPrime = True
# for i in range(2, n):
#     if n % i == 0:
#         isPrime = False
#         break
#
# if isPrime:
#     print("Prime number")
# else:
#     print("Not Prime")


# a = int(input())
# b = int(input())
# a,b = b,a
# print(a, b)

# a = 5
# b = 5
# print(id(a))
# print(id(b))


# a = [1,2,3,4,5,6,7,8]
# print(a)
#
# a.append(9)
# print(a)
#
# a.insert(4, 9)
#
# a.pop()
# print(a)

# #Empty
# a = []
# a = list()

# a= list(range(2,10))
# print(a)
# a = [2,3,6,5,6,7,8,9]
# b = 6
# print(a.index(b))

# print(dir(a))
# for i in range(len(a)):
#     if a[i] == b:
#         print(i)


# a = input()
# b = a.split()
# for i in range(len(b)):
#     b[i] = int(b[i])
#
# print(b)
# print(type(b[0]))

# def hello(name, age, number = 40):
#     print("Hello", name,age,number)
#     return number;
# a =hello("sid", 3,45)
#
# print(a)


# def cube(num):
#     num = num ** 3
#     return num
#
# a = cube(2)
# b = cube(2)
# print(a + b)

# def spiderman():
#     return "siddhant", 20, "pandey"
#
# name, age, surname = spiderman()
# print(name, age, surname)

# call stack
# y = 100
#
# def square(x):
#     global y
#     y = 5
#     print("y", y)
#     return x ** 2
#
# def pythagoras(a,b):
#     c2 = square(a) + square(b)
#     print("y", y)
#     return c2
#
# print(pythagoras(4,5))


# Map Function

# def square(x):
#     return x ** 2
# a = [5, 2, 7, 6, 9, 3]
#
# b = []
# # for x in a:
# #     b.append(square(x))
#
# b = list(map(square, a))
# print(b)
#

# def square(x):
#     return x**2
#
# square2 = lambda x: x ** 2
# multiply = lambda a, b: a*b
# print(square2(3))
# print(multiply(4,5))
#

# a = [2, 3, 4, 5, 6, 7]
# print(a[::-1])
# print(a[1:4:1])
# print(a[:3])
# print(a[0:])
# print(a[5:1:-1])

# res = []
# for i in range(1, 101):
#     res.append(i ** 2)
# print(res)
#
# res1 = [i**2 for i in range(1, 101)]
# print(res1)
#
# res2 = [i**3 for i in range(1, 101)]
# print(res2)

# def square(x):
#     return x**2
#
# res = list(map(square,range(1,10)))
# print(res)

# res1 = [i**2 for i in range(1, 101)]
# for x in res1:
#     print(x, end=' ')


# # ---------
# a = [27, 24, 21, 46, 6, 25, 38, 10, 40]
# b = []
#
# for x in a:
#     if x % 2 == 0:
#         b.append(x)
# print(b)
#
# c = [x for x in a if x % 2 == 0]
# print(c)


# d= [i for i in range(1, 101) if i % 2 != 0]
# print(d)


# ##Tuples
# alpha = ('a', 'b', 'c', 'd', 'e', 'f')
# print(alpha)
#
# a = tuple(['a', 'b', 'c', 'd', 'e', 'f'])
# print(a)
#
#
import math

# a = ('hello', 'd', 3, ['a', 'b'])


# a[3].append('t')
#
# b = (2,3,4)
# print(a+b)
# print(a[0:4:1])

# a = (1,3,4,2,6,9,7,6)
# for i in range(len(a)- 1):
#     if a[i] < a[i+1]:
#         continue
#     else:
#          print("not")

# def product(*num):

# def linearSearch(A, B):
#     for i in range(len(A)):
#        if A[i] == B:
#             return 1
#     return 0
#
# A = [27, 24, 21, 46, 6, 25, 38, 10, 40]
# B = 38
#
# out = linearSearch(A, B)
# print(out)

# A = input()
# B = A.split(' ')
# N = int(B[0])
# for i in range(1, N+1):
#     i = int(B[i])
#     if i < 0:
#         print(i, end=' ')

# A = [1, 1, 1]
# B = 2
# count = 0
#
# for i in range(len(A)):
#     for j in range(i+1, len(A)):
#         print(A[i], A[j])
#         if A[i]+A[j] == B:
#             count += 1
# print(count)

# B = ("96943 7901 9301 4755 2798 7072 7308 2827 1888 8405 2958 6214 2553 8098 1949 9378 4237 5772 230 7539 7276 2207 4396 752 8892 6547 6740 9313 1477 1034 3255 8419 8934 8907 3173 8083 5978 6832 909 7866 5236 3866 431 7789 1964 2379 7166 6200 8151 3747 90 1778 5953 837 2529 4844 3736 5620 508 5212 6653 114 3630 1939 9020 3155 21 4998 9986 930 9215 1574 1147 9645 9362 3110 8375 2879 5662 6525 6625 2103 4655 8929 2940 3535 3772 6675 9155 631 1886 2159 745 1867 449 6116 5021 470 7465 1359 7751 6679 2932 8897 2675 8645 8359 7402 1523 372 3926 4499 2474 4932 3427 5413 8467 3550 8439 3973 532 324 6131 7628 8543 6580 3744 3563 3401 1208 4921 1151 4239 7852 47 3265 2848 4757 666 4370 5128 944 5220 7602 2227 4998 9366 693 4899 7805 4665 5431 4480 7148 3058 3022 79 3153 6585 3479 713 7857 4629 1303 2061 1027 4567 4908 5784 1585 5630 911 8880 7201 4864 1106 2199 4230 1799 7097 8386 2815 8879 2865 6314 8289 5887 6392 1441 8823 9870 2153 3031 850 3455 5091 1877 4374 6351 4012 5958 1980 4922 1189 5532 613")
# B = ("5 1 2 3 4 5")

# A = B.split()
# output = A[:0:-1]
# S = " ".join(output)
# print(S, end= ' ')


# s="kskkskkkk"
# s=s.replace("k","0",3)
# print(s)

# n=int(input())
# char=65
# for j in range(1,n+1):
#     print(((chr(char)+chr(32))*j).rstrip(),end="")
# print()
# char+=1

#
# A = input()
# A = int(A)
#
# for i in range(A,0,-1):
#     for j in range(1, i):
#         print(j,end=' ')
#     print(i)
#


# A = input()
# A = int(A)
# sum = 0
# for i in range(1,A+1):
#     if i%2 == 0:
#         sum += i
# print(sum)


# A = input()
# A = int(A)
# for i in range(1, 11):
#     print(A, "*", i, "=", A * i)


# 0 0 0 1 0 0 0
# 0 0 2 3 2 0 0
# 0 3 4 5 4 3 0
# 4 5 6 7 6 5 4
#
# A = 4
# A = int(A)
#
# for i in range(1, A+1):
#     print("0 " * (A-i), end='')
#     for j in range(i, 2*i-1):
#         print(j, end=' ')
#     for j in range(2*i-1, i-1, -1):
#         print(j, end=' ')
#     print("0 " * (A-i))
#

#
# def CalculateYear(h, b):
#     M = int(h)
#     Y = int(b)
#     if M == 2 and ((Y % 400 == 0) or (Y % 4 == 0 and Y % 100 != 0)):  # very important condition
#         return 29
#     if M == 2:
#         return 28
#     if M == 1 or M == 3 or M == 5 or M == 7 or M == 8 or M == 10 or M == 12:
#         return 31
#     if M == 2 or M == 2 or M == 4 or M == 6 or M == 9 or M == 11:
#         return 30
#     else:
#         return 0
#
#
# print(CalculateYear(2, 300))


# A = int(input())
# B = int(input())
# output = 1
#
# for i in range(1, B+1):
#     output *= A
# print(output)

# A = input()
# A = A.split(' ')
# total = 0
# for i in A:
#     total += int(i)
# total = total//5
#
# if total >= 90:
#     print(total, "A")
# elif total >= 80:
#     print(total, "B")
# elif total >= 70:
#     print(total, "C")
# elif total >= 60:
#     print(total, "D")
# elif total >= 50:
#     print(total, "E")
# elif total < 40:
#     print(total, "F")

# import math
# A= math.log(10)
# print(A)
#

# n = 100
# while n > 1:
#     print(n)
#     n = n / 2


# a = int(input())
# b = int(input())
#
# def gcd (c, d):
#     while c != 0:
#         c, d = d % c, c
#     return d
# print("GCD is", gcd(a, b))
#
#
# out = 0
# def lcm(x, y):
#     global out
#     out = (x * y) / gcd(x, y)
#     return out
#
# C= lcm(a, b)
# print(C)
# import math
# B = math.gcd(6, 4)
# A = math.lcm(6, 4)
# print(A, B)


# Sq = 9 ** (1/2)
# def isPrime(n):
#     sq = int(math.sqrt(n))
#     print(sq)
#
#     for i in range(2, sq+1):
#         if n % i == 0:
#             return False
#     return True
# B = 10 ** 18
# A = isPrime(B)
# print(A)

# #Prime Number
# def main():
#     N = int(input())
#     sqr = int(math.sqrt(N))
#     print(sqr)
#     isPrime = True
#     for i in range(2, sqr):
#         if (N % i == 0):
#             isPrime = False
#             break
#     print(isPrime)
#     return isPrime
#
# if __name__ == '__main__':
#     main()

# ##############
# def checkDivisor(N):
#     sum = 0
#     for j in range(1, N):
#         if N % j == 0:
#             sum += j
#     if sum == N:
#         print("YES")
#     else:
#         print("NO")
#
# A = []
# N = int(input())
# for i in range(1, N+1):
#     i = input()
#     A.append(i)
#
# for i in range(0, len(A)):
#     checkDivisor(int(A[i]))


########## Sum of N Numbers
# sum = 0
# N = int(input())
# print(N)
# sum = N*(N +1)//2
#
# print(sum)

# Binary Search : Return square root of the number if it is perfect square otherwise return -1.
# def solve(A):
#     L = 1
#     R = A
#     while L <= R:
#         mid = (L + R) // 2
#         print("mid", mid)
#         if mid * mid == A:
#             print("if", mid)
#             return mid
#         elif mid * mid > A:
#             R = mid - 1
#             print("elif 1", R)
#         elif mid * mid < A:
#             L = mid + 1
#             print("elif 2", L)
#
#     return "-1"
#
# print(solve(3481))
#

#### Args and Kwargs
# def person(name, age, mobile, *args, **kwargs):
#     print(name, age, mobile)
#     print(args)
#     print(kwargs)
#
# A= person("siddh", 20, 9898, "Aastha", "House", city= "BLR", state = "KR")
#

##### String Vowels vs Consonants  ---------------------------------------------------------------------------------
# A = "interviewbit"   #[5 7]

# V= ['a', 'e', 'i', 'o', 'u']
# vcount = 0
# ccount = 0
# for char in A:
#     if char in V:
#         vcount += 1
#     else:
#         ccount += 1
# print(vcount, ccount)

# Approach - 2
#
# def solve(A):
#     ans = [0]*2
#     # print(ans)
#     for i in range(0,len(A)):
#         if A[i] == 'a' or A[i] == 'e' or A[i] == 'i' or A[i] == 'o' or A[i] == 'u':
#             ans[0] += 1
#         else:
#             ans[1] += 1
#     return ans
#
# print(solve(A))

# -----------------------------------------------------------------------------------------------------------------


# Pattern
# s = chr(1 + ord('A') )
# print(s)
# A
# B B
# C C C
# D D D D
#
# n = int(input())
# for i in range(n):
#     print(i)
#     print((chr(65+i)+" ")*(i+1))




## Table of N number
# N = int(input())
# for i in range(1, 11):
#     print(str(N) + ' * ' + str(i) + ' = ' + str(N * i))

### Armstrong Number
# A = int(input())
# for i in range(1, A + 1):
#     sum = 0
#     for chr in str(i):
#         sum += int(chr) ** 3
#     if sum == i:
#         print(sum)

#Function in Python

# def tea():
#     print("A")
#     print("B")
#     return "sid"
#
# def coffee():
#     print("C")
#     print("D")

#------------------------------------------------
#### Map Function
# def square(x):
#     return x ** 2
#
# a = [5, 2, 6, 9, 3]
# b = []
#
# # 1st approach
# for i in a:
#     b.append(square(i))
# print(b)
#
# # 2nd approach
# b = list(map(square, a))
# print(b)


### Lambda Functions/expressions
# square2 = lambda x: x **2
# A = square2(10)
# print(A)

# multiply = lambda a,b: a*b
# C = multiply(2,3)
# print(C)

# d = lambda b: [b ** 2, b + b]
# print(d(10))


####You are given an integer N you need to print all the Prime Numbers between 1 and N.
# def getPrimeNum(N):
#     isPrime = True
#     for j in range(2, N):
#         if N % j == 0:
#             isPrime = False
#     return isPrime
#
# N = int(input())
# for i in range(2, N + 1):
#     T = getPrimeNum(i)
#     if T == True:
#         print(i)

########################################################
#
# # square List
# res =[]
# for i in range(1, 101):
#     res.append(i ** 2)
# print(res)
#
# # Single Line
# res1 = [i ** 2 for i in range(1, 101)]
# print(res1)
#
# # Map Function
# def square(x):
#     return x ** 2
# res2 = list(map(square, range(1, 101)))
# print(res2)

# Even number between (1, 100)
# b = []
# for x in range(1, 101):
#     if x % 2 == 0:
#         b.append(x)
# print(b)
#
# # ------------------------------------------------------------
# C = [x for x in range(1, 101) if x % 2 == 0]
# print(C)


###Tuples
# vowels = ('a','e','i','o','u')
# print(type(vowels))
#
# planets = 'a','b','c','d','f'
# print(type(planets))
#
# a = tuple()
# a = tuple([2,3,4,5,6])
# print(a)



# --------------------------------------

# R = int(input())
# N = math.ceil((4/3) * (math.pi) * (R**3))
# print(N)

# ------> Sets
# friend1 = [
#     'a',
#     'b',
#     'c'
# ]
# friend2 = [
#     'd',
#     'e',
#     'f'
# ]
# friend3 = [
#     'a',
#     'e',
#     'f'
# ]
# s = set()
# s.update(friend1, friend2, friend3)
# print(*s)
#
# friend5 = ['b', 'a', 'e']
#
# for i in friend5:
#     if i in s:
#         print('>', i)

##### -----------------------
# s= {1, 2, 3, 4}
# # s.add([8, 9]) can't add list but update in set
# s.update([8, 9])
# print(s)

#### ------------------------
#
# currency = dict()
# currency = {}
#
# currency = {
#     'india': 'a',
#     'PAk': 'b',
#     'Japan': 'c'
# }
# print(currency)
# C = currency['india']
# currency['USA'] = 'USD'

# list not allowed in Dictionary
# l = [1, 2, 3]
# currency[l] = 'not ok'

#Tuples are allowed in Dictionary
# t = (3, 4, 5)
# currency[t] = ['ok', 'well']

# print(currency)

# value can be list in Dictionary

# a =currency.keys()
# b =currency.values()
# print(a, b)

#
# a = [
#     [1, 2, 3, 4],
#     [5, 6, 7, 8],
#     [9, 1, 2, 3]
# ]
# b = [
#     [1, 2, 3, 4],
#     [5, 6, 7, 8],
#     [9, 1, 2, 3]
# ]
#
# for row in a:
#     for x in row:
#         print(x ** 2, end=' ')
#     print()


# -------------------------------------------
# a = [1, 2, 3, 4, 5, [3, 2]]
# print(a)
# print(a[5])
#
# b = [
#     [1, 2, 3, 4],
#     [6, 3, 2, 1],
#     [7, 3, 2, 1]
# ]
#
# print(b[0][2])
# print(b[2][3])
# -------------------------------------------
# 2 4
# r, c = map(int, input().split())
# print(type(r))
# print(r, c)
#

# 1 2 3 4
# 9 8 7 5

# a = []
# for i in range(r):
#     row = list(map(int, input().split()))
#     a.append(row)
# print(a)


#Problem solving
# a = 0
# N = 5
# for i in range(N):
#     for j in range(N, i, -1):
#         a = a + i + j
#         print(i,j,N,a)


# ------------------------------------------------------------------------------------
# Convert string list to int List
# test_list = ['1', '4', '3', '6', '7']

## Using map()
# test_list = list(map(int, test_list))
# print(test_list)

## Using list comprehension
# test_list1 = [int(i) for i in test_list]
# print(test_list1)

## Native Method
# for i in range(0, len(test_list)):
#     test_list[i] = int(test_list[i])

# ------------------------------------------------------------------------------------
# S = [1, 2, 3, 4, 5]#[1::]
# V = S[:3]
# P = S[-(len(S)-3):]
# T = S[-3:]
# U = S[:len(S)-3]
# # print(S, T, U, T+U)
# print(V, P)

# B = []
# x = ''
# for line in iter(input, x):
#     C = line.split()
#     B.append(C)
# print(B)

# ----------------------------------------------------------------------------------------------------------
# Write a program to print maximum and minimum
# Input 1:
# 5 1 2 3 4 5
# Input 2:
# 4 10 50 40 80
#
# Output 1:
# 5 1
# Output 2:
# 80 10

# A = [int(item) for item in input().split()][1:]
# min, max = A[0], A[0]
# for i in range(len(A)):
#     if A[i] < min:
#         min = Aap
#     if A[i] > max:
#         max = A[i]
#     print(max, min)
# ----------------------------------------------------------------------------

# A = [42, 32, 65, 22, 9, 8, 20, 74, 74, 100, 39, 4, 36, 81, 19, 33, 87, 58, 26]
# B = A[2:6:1]
# print (sum(B))

# ------------------------------------------------------------------
# def SumOfMaxNumb(A, B):
#     max = 0
#     fsum = 0
#     Bsum = 0
#
#     for i in range(B):
#         fsum = fsum + A[i]
#         max = fsum
#
#     for j in range(len(A)-1, len(A)-1-B, -1):
#         Bsum = Bsum + A[j]
#
#     if Bsum > max:
#         max = Bsum
#
#     for i in range(0, B):
#         for j in range(B-1, 1, -1):
#             print(i, j)
#
#     print(max)
# A = [5, -2, 4, 1, 2]
# B = 4
# SumOfMaxNumb(A, B)

# ------------------------------------------------------------------
#
# def titleToNumber(A):
#     result = 0
#     n = len(A)
#     for i in range(n):
#         result *= 26
#         print(i, result, A[i], ord(A[i]))
#         result += ord(A[i]) - ord('A') + 1
#         print('r', result)
#     return result
#
# print(titleToNumber('ABCDE'))
#
# print(ord('A'))

# --------------
# count = 0
# N = 10
# i = 1
# while i * i < N:
#     count += 1
#     i += 1
# print(count)
# # ---------------
# count = 0
# n = 10
# for i in range(1, n+1):
#     if i * i < n:
#         count += 1
# print(count)
# ---------------
# N = 10
# print([x * x for x in range(1, N+1)])
#
# print(math.floor(math.sqrt(10)))
# # ---------------
# def solve(A, B, C):
#     D = [A, B, C]
#     D.sort()
#     E = ''
#     for i in D:
#         E += str(i)
#     return E

# print(solve(10, 20, 30))
# # ---------------
# N = 13  #1101
# count = 0
# while N > 0:
#     if N & 1 == 1:
#         count += 1
#     N = N >> 1
#     print(count, N)
# print(count)
# # ---------------
# count = 0
# A = 93
# B = 4
# A = A & (1<<B)
# print(1<<B)
# print(A)

# # ---------------
# I = 'ABEC'
# V = ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']
# count = 0
# for i in range(len(I)):
#     if I[i] in V:
#         for j in range(i+1, len(I)+1):
#             print(I[i:j])

# A = 'ABEC'
# n = len(A)
# print(n)
# c = 0
# for i in range(n):
#     if(A[i]=='A' or A[i]== 'E' or A[i]== 'I' or A[i]== 'O' or A[i]== 'U' or A[i]== 'a' or A[i]== 'e' or A[i]== 'i' or A[i]== 'o'or A[i]== 'u'):
#         c = c + (n-i)
# c = c % 10003
# print(c)




# # abcba
# def Check(A):
#     i = 0
#     j = len(A) - 1
#
#     while i < j:
#         if A[i] != A[j]:
#             return '0'
#         else:
#             i += 1
#             j -= 1
#     return 1
#
# A = input()
# B = []
# for i in range(0, A):
#     print(i)
#     # C = input()
#     # # print(B)
#     # out = Check(C)
#     # B.append(out)
#
# print(B)

# # ---------------
# Find Nth Fibonacci
# A = 50
# n = A
# a = 0
# b = 1
#
# # Check is n is less
# # than 0
# if n < 0:
#         print("Incorrect input")
# # Check is n is equal
# # to 0
# elif n == 0:
#         print(0)
# # Check if n is equal to 1
# elif n == 1:
#         print(b)
# else:
#         for i in range(1, n):
#                 c = a + b
#                 a = b
#                 b = c
#         print(b)
#         f = b % (1000000000 + 7)
#         print(f)


# def sumofDigit(A):
#     total = 0
#     while A > 0:
#         print(A)
#         B = A % 10
#         total += B
#         A = A // 10
#         print(A)
#     return total
# print(sumofDigit(22732))

# A = 100001
# B = str(A)
# D = ''
# for i in range(len(B)-1, -1, -1):
#     D ="".join((D, B[i]))
#
# if B == D:
#     print('Yes')
# else:
#     print('No')

# -----------------------------------------------------------------------------------
# Given an integer A, determine whether it is palindromic or not.
# def palindromic(A):
#     # A = int(input())
#     tempA = A
#     revA = 0
#     while tempA > 0:
#         lastdig = tempA % 10
#         revA = (revA * 10) + lastdig
#         tempA //= 10
#
#     if revA == A:
#         print("Yes")
#
#     else:
#         print("No")
#     return 0
#
# palindromic(10001)



