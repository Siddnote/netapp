# Crate Nodes
# Create linked list
# Add Nodes to linked list
# Print Linked List

# # Add Node at the End of the Linked List
# class Node:
#     def __init__(self, data):
#         self.data = data
#         self.next = None
#
# class LinkedList:
#     def __init__(self):
#         self.head = None
#
#     def insert(self, newNode):
#         if self.head is None:
#             self.head = newNode
#         else:
#             # self.head.next = newNode
#             lastNode = self.head
#             while True:
#                 if lastNode.next is None:
#                     break
#                 lastNode = lastNode.next
#             lastNode.next = newNode
#
#     def printList(self):
#         if self.head is None:
#             print("Empty List")
#             return
#         currentNode = self.head
#         while True:
#             if currentNode is None:
#                 break
#             print(currentNode.data)
#             currentNode = currentNode.next
#
#
# # Node have 2 field : data, next
# firstNode = Node("John")
# linkedList = LinkedList()
# linkedList.insert(firstNode)
# secondNode = Node("Ben")
# linkedList.insert(secondNode)
# thirdNode = Node("Methew")
# linkedList.insert(thirdNode)
# linkedList.printList()
# ----------------------------------------------------------------------------
# Add Node at the Start of the Linked List
#
# class Node:
#     def __init__(self, data):
#         self.data = data
#         self.next = None
#
# class LinkedList:
#     def __init__(self):
#         self.head = None
#
#     def insert(self, newNode):
#         if self.head is None:
#             self.head = newNode
#         else:
#             # self.head.next = newNode
#             lastNode = self.head
#             while True:
#                 if lastNode.next is None:
#                     break
#                 lastNode = lastNode.next
#             lastNode.next = newNode
#
#     def insertHead(self, newNode):
#         tempNode = self.head
#         self.head = newNode
#         self.head.next = tempNode
#         del tempNode
#
#
#     def printList(self):
#         if self.head is None:
#             print("Empty List")
#             return
#         currentNode = self.head
#         while True:
#             if currentNode is None:
#                 break
#             print(currentNode.data)
#             currentNode = currentNode.next
#
# firstNode = Node("John")
# linkedList = LinkedList()
# linkedList.insert(firstNode)
# secondNode = Node("Ben")
# linkedList.insert(secondNode)
# thirdNode = Node("Methew")
# linkedList.insertHead(thirdNode)
# linkedList.printList()

# ----------------------------------------------------------------------------

# Add Node at the K the index of the Linked List
#
# class Node:
#     def __init__(self, data):
#         self.data = data
#         self.next = None
#
# class LinkedList:
#     def __init__(self):
#         self.head = None
#
#     def listLength(self):
#         currentNode = self.head
#         length = 0
#         while currentNode is not None:
#             length += 1
#             currentNode = currentNode.next
#         return length
#
#
#     def insert(self, newNode):
#         if self.head is None:
#             self.head = newNode
#         else:
#             # self.head.next = newNode
#             lastNode = self.head
#             while True:
#                 if lastNode.next is None:
#                     break
#                 lastNode = lastNode.next
#             lastNode.next = newNode
#
#     def insertHead(self, newNode):
#         tempNode = self.head
#         self.head = newNode
#         self.head.next = tempNode
#         del tempNode
#
#     def insertAt(self, newNode, position):
#         if position < 0 or position > self.listLength():
#             print('Invalid Position', self.listLength())
#             return
#         if position == 0:
#             self.insertHead(newNode)
#             return
#         currentNode = self.head
#         currentPosition = 0
#         while True:
#             if currentPosition == position:
#                 previousNode.next = newNode
#                 newNode.next = currentNode
#                 break
#             previousNode = currentNode
#             currentNode = currentNode.next
#             currentPosition += 1
#
#
#     def printList(self):
#         if self.head is None:
#             print("Empty List")
#             return
#         currentNode = self.head
#         while True:
#             if currentNode is None:
#                 break
#             print(currentNode.data)
#             currentNode = currentNode.next
#
# firstNode = Node("John")
# linkedList = LinkedList()
# linkedList.insert(firstNode)
# secondNode = Node("Ben")
# linkedList.insert(secondNode)
# thirdNode = Node("Methew")
# linkedList.insertAt(thirdNode, 1)
# linkedList.printList()

# ----------------------------------------------------------------------------
# Deleting Linked List from the End of List
# class Node:
#     def __init__(self, data):
#         self.data = data
#         self.next = None
#
# class LinkedList:
#     def __init__(self):
#         self.head = None
#
#     def listLength(self):
#         currentNode = self.head
#         length = 0
#         while currentNode is not None:
#             length += 1
#             currentNode = currentNode.next
#         return length
#
#     def deleteEnd(self):
#         lastNode = self.head
#         while lastNode.next is not None:
#             previousNode = lastNode
#             lastNode = lastNode.next
#         previousNode.next = None
#
#     def insert(self, newNode):
#         if self.head is None:
#             self.head = newNode
#         else:
#             # self.head.next = newNode
#             lastNode = self.head
#             while True:
#                 if lastNode.next is None:
#                     break
#                 lastNode = lastNode.next
#             lastNode.next = newNode
#
#     def insertHead(self, newNode):
#         tempNode = self.head
#         self.head = newNode
#         self.head.next = tempNode
#         del tempNode
#
#     def insertAt(self, newNode, position):
#         if position < 0 or position > self.listLength():
#             print('Invalid Position', self.listLength())
#             return
#         if position == 0:
#             self.insertHead(newNode)
#             return
#         currentNode = self.head
#         currentPosition = 0
#         while True:
#             if currentPosition == position:
#                 previousNode.next = newNode
#                 newNode.next = currentNode
#                 break
#             previousNode = currentNode
#             currentNode = currentNode.next
#             currentPosition += 1
#
#     def printList(self):
#         if self.head is None:
#             print("Empty List")
#             return
#         currentNode = self.head
#         while True:
#             if currentNode is None:
#                 break
#             print(currentNode.data)
#             currentNode = currentNode.next
#
# firstNode = Node("John")
# linkedList = LinkedList()
# linkedList.insert(firstNode)
# secondNode = Node("Ben")
# linkedList.insert(secondNode)
# thirdNode = Node("Methew")
# linkedList.insert(thirdNode)
# linkedList.deleteEnd()
# linkedList.printList()

# ----------------------------------------------------------------------------
# Deleting the Head of Linked List
# class Node:
#     def __init__(self, data):
#         self.data = data
#         self.next = None
#
# class LinkedList:
#     def __init__(self):
#         self.head = None
#
#     def listLength(self):
#         currentNode = self.head
#         length = 0
#         while currentNode is not None:
#             length += 1
#             currentNode = currentNode.next
#         return length
#
#     def deleteEnd(self):
#         if self.isListEmpty() is False:
#             if self.head.next is None:
#                 self.deleteHead()
#                 return
#             lastNode = self.head
#             while lastNode.next is not None:
#                 previousNode = lastNode
#                 lastNode = lastNode.next
#             previousNode.next = None
#         else:
#             print("Empty link End list")
#
#     def deleteHead(self):
#         if self.isListEmpty() is False:
#             previousHead = self.head
#             self.head = self.head.next
#             previousHead.next = None
#         else:
#             print("Empty link Head list")
#
#     def isListEmpty(self):
#         if self.head is None:
#             return True
#         else:
#             return False
#
#     def insert(self, newNode):
#         if self.head is None:
#             self.head = newNode
#         else:
#             # self.head.next = newNode
#             lastNode = self.head
#             while True:
#                 if lastNode.next is None:
#                     break
#                 lastNode = lastNode.next
#             lastNode.next = newNode
#
#     def insertHead(self, newNode):
#         tempNode = self.head
#         self.head = newNode
#         self.head.next = tempNode
#         del tempNode
#
#     def insertAt(self, newNode, position):
#         if position < 0 or position > self.listLength():
#             print('Invalid Position', self.listLength())
#             return
#         if position == 0:
#             self.insertHead(newNode)
#             return
#         currentNode = self.head
#         currentPosition = 0
#         while True:
#             if currentPosition == position:
#                 previousNode.next = newNode
#                 newNode.next = currentNode
#                 break
#             previousNode = currentNode
#             currentNode = currentNode.next
#             currentPosition += 1
#
#     def printList(self):
#         if self.head is None:
#             print("Empty List")
#             return
#         currentNode = self.head
#         while True:
#             if currentNode is None:
#                 break
#             print(currentNode.data)
#             currentNode = currentNode.next
#
# linkedList = LinkedList()
# firstNode = Node("John")
# linkedList.insert(firstNode)
# secondNode = Node("Ben")
# # linkedList.insert(secondNode)
# thirdNode = Node("Methew")
# # linkedList.insert(thirdNode)
# linkedList.printList()
# linkedList.deleteEnd()
# # linkedList.insert(firstNode)
# linkedList.printList()

# ----------------------------------------------------------------------------
# Delete from K the index
# class Node:
#     def __init__(self, data):
#         self.data = data
#         self.next = None
#
# class LinkedList:
#     def __init__(self):
#         self.head = None
#
#     def listLength(self):
#         currentNode = self.head
#         length = 0
#         while currentNode is not None:
#             length += 1
#             currentNode = currentNode.next
#         return length
#
#     def deleteAt(self, position):
#         if position < 0 or position >= self.listLength():
#             print('Invalid Position', self.listLength())
#             return
#         if self.isListEmpty() is False:
#             if position is 0:
#                 self.deleteHead()
#                 return
#             currentNode = self.head
#             currentPosition = 0
#             while True:
#                 if currentPosition == position:
#                     previousNode.next = currentNode.next
#                     currentNode.next = None
#                     break
#                 previousNode = currentNode
#                 currentNode = currentNode.next
#                 currentPosition += 1
#     def deleteEnd(self):
#         if self.isListEmpty() is False:
#             if self.head.next is None:
#                 self.deleteHead()
#                 return
#             lastNode = self.head
#             while lastNode.next is not None:
#                 previousNode = lastNode
#                 lastNode = lastNode.next
#             previousNode.next = None
#         else:
#             print("Empty link End list")
#
#     def deleteHead(self):
#         if self.isListEmpty() is False:
#             previousHead = self.head
#             self.head = self.head.next
#             previousHead.next = None
#         else:
#             print("Empty link Head list")
#
#     def isListEmpty(self):
#         if self.head is None:
#             return True
#         else:
#             return False
#
#     def insert(self, newNode):
#         if self.head is None:
#             self.head = newNode
#         else:
#             # self.head.next = newNode
#             lastNode = self.head
#             while True:
#                 if lastNode.next is None:
#                     break
#                 lastNode = lastNode.next
#             lastNode.next = newNode
#
#     def insertHead(self, newNode):
#         tempNode = self.head
#         self.head = newNode
#         self.head.next = tempNode
#         del tempNode
#
#     def insertAt(self, newNode, position):
#         if position < 0 or position > self.listLength():
#             print('Invalid Position', self.listLength())
#             return
#         if position == 0:
#             self.insertHead(newNode)
#             return
#         currentNode = self.head
#         currentPosition = 0
#         while True:
#             if currentPosition == position:
#                 previousNode.next = newNode
#                 newNode.next = currentNode
#                 break
#             previousNode = currentNode
#             currentNode = currentNode.next
#             currentPosition += 1
#
#     def printList(self):
#         if self.head is None:
#             print("Empty List")
#             return
#         currentNode = self.head
#         while True:
#             if currentNode is None:
#                 break
#             print(currentNode.data)
#             currentNode = currentNode.next
#
# linkedList = LinkedList()
# firstNode = Node("John")
# linkedList.insert(firstNode)
# secondNode = Node("Ben")
# linkedList.insert(secondNode)
# thirdNode = Node("Methew")
# linkedList.insert(thirdNode)
# linkedList.printList()
# linkedList.deleteAt(1)
# linkedList.printList()

# ----------------------------------------------------------------------------
# Doubly Linked List
# ----------------------------------------------------------------------------
# Create Doubly linked list
# class Node:
#     def __init__(self, data):
#         self.data = data
#         self.next = None
#         self.previous = None
#
# class LinkedList:
#     def __init__(self):
#         self.head = None
#
#     def insertEnd(self, newNode):
#         # sid  -> UST -> Meta->
#         if self.head is None:
#             self.head = newNode
#             return
#         else:
#             currentNode = self.head
#             while True:
#                 if currentNode.next == None:
#                     break
#                 currentNode = currentNode.next
#             currentNode.next = newNode
#             newNode.previous = currentNode
#
#     def PrintList(self):
#         if self.head is None:
#             print('List is Empty')
#         currentNode = self.head
#         print('Begining')
#         while True:
#             if currentNode is None:
#                 break
#             print(currentNode.data)
#             if currentNode.next is None:
#                 reverseTraverseNode = currentNode
#             currentNode = currentNode.next
#         print('End')
#         while True:
#             if reverseTraverseNode is None:
#                 break
#             print(reverseTraverseNode.data)
#             reverseTraverseNode = reverseTraverseNode.previous
#
# nodeOne = Node('Sid')
# nodeTwo = Node('UST')
# nodeThree = Node('Meta')
#
# linkedList = LinkedList()
# linkedList.insertEnd(nodeOne)
# linkedList.insertEnd(nodeTwo)
# linkedList.insertEnd(nodeThree)
#
# linkedList.PrintList()
#
# --------------------------------------------------------------------------------
# Add Head Node in the Linked List
# class Node:
#     def __init__(self, data):
#         self.data = data
#         self.next = None
#         self.previous = None
#
# class LinkedList:
#     def __init__(self):
#         self.head = None
#
#     def insertEnd(self, newNode):
#         # sid  -> UST -> Meta->
#         if self.head is None:
#             self.head = newNode
#             return
#         else:
#             currentNode = self.head
#             while True:
#                 if currentNode.next == None:
#                     break
#                 currentNode = currentNode.next
#             currentNode.next = newNode
#             newNode.previous = currentNode
#
#     def insertHead(self, newNode):
#         previousHead = self.head
#         self.head  = newNode
#         self.head.next = previousHead
#         previousHead.previous = self.head
#
#     def PrintList(self):
#         if self.head is None:
#             print('List is Empty')
#         currentNode = self.head
#         print('Begining')
#         while True:
#             if currentNode is None:
#                 break
#             print(currentNode.data)
#             if currentNode.next is None:
#                 reverseTraverseNode = currentNode
#             currentNode = currentNode.next
#         print('End')
#         while True:
#             if reverseTraverseNode is None:
#                 break
#             print(reverseTraverseNode.data)
#             reverseTraverseNode = reverseTraverseNode.previous
#
# nodeOne = Node('Sid')
# nodeTwo = Node('UST')
# nodeThree = Node('Meta')
# nodeFour = Node('UK')
# linkedList = LinkedList()
# linkedList.insertEnd(nodeOne)
# linkedList.insertEnd(nodeTwo)
# linkedList.insertEnd(nodeThree)
# linkedList.insertHead(nodeFour)
#
# linkedList.PrintList()

# --------------------------------------------------------------------------------
# Insert a Node in between Two Nodes

# class Node:
#     def __init__(self, data):
#         self.data = data
#         self.next = None
#         self.previous = None
#
# class LinkedList:
#     def __init__(self):
#         self.head = None
#
#     def insertEnd(self, newNode):
#         # sid  -> UST -> Meta->
#         if self.head is None:
#             self.head = newNode
#             return
#         else:
#             currentNode = self.head
#             while True:
#                 if currentNode.next == None:
#                     break
#                 currentNode = currentNode.next
#             currentNode.next = newNode
#             newNode.previous = currentNode
#     def listLength(self):
#         length = 0
#         currentNode = self.head
#         while currentNode is not None:
#             currentNode = currentNode.next
#             length += 1
#         return length
#
#     def insertHead(self, newNode):
#         previousHead = self.head
#         self.head  = newNode
#         self.head.next = previousHead
#         previousHead.previous = self.head
#
#     def insertAt(self, newNode, position):
#         if position < 0 or position > self.listLength():
#             print('Invalid Position')
#             return
#         if position is self.listLength():
#             self.insertEnd(newNode)
#             return
#         if position == 0:
#             self.insertHead(newNode)
#             return
#         currentNode = self.head
#         currentPostion = 0
#         while True:
#             if currentPostion == position:
#                 currentNode.previous.next = newNode
#                 newNode.previous = currentNode.previous
#                 newNode.next = currentNode
#                 currentNode.previous = newNode
#                 break
#             currentNode = currentNode.next
#             currentPostion += 1
#
#     def PrintList(self):
#         if self.head is None:
#             print('List is Empty')
#         currentNode = self.head
#         print('Begining')
#         while True:
#             if currentNode is None:
#                 break
#             print(currentNode.data)
#             if currentNode.next is None:
#                 reverseTraverseNode = currentNode
#             currentNode = currentNode.next
#         print('End')
#         while True:
#             if reverseTraverseNode is None:
#                 break
#             print(reverseTraverseNode.data)
#             reverseTraverseNode = reverseTraverseNode.previous
#
# nodeOne = Node('1')
# nodeTwo = Node('2')
# nodeThree = Node('3')
# nodeFour = Node('4')
# linkedList = LinkedList()
# linkedList.insertEnd(nodeOne)
# linkedList.insertEnd(nodeTwo)
# linkedList.insertEnd(nodeThree)
# linkedList.insertAt(nodeFour, -1)
#
# linkedList.PrintList()
#
# --------------------------------------------------------------------------------
# Delete a Node from End of Linked List
#
# class Node:
#     def __init__(self, data):
#         self.data = data
#         self.next = None
#         self.previous = None
#
# class LinkedList:
#     def __init__(self):
#         self.head = None
#
#     def insertEnd(self, newNode):
#         # sid  -> UST -> Meta->
#         if self.head is None:
#             self.head = newNode
#             return
#         else:
#             currentNode = self.head
#             while True:
#                 if currentNode.next == None:
#                     break
#                 currentNode = currentNode.next
#             currentNode.next = newNode
#             newNode.previous = currentNode
#     def listLength(self):
#         length = 0
#         currentNode = self.head
#         while currentNode is not None:
#             currentNode = currentNode.next
#             length += 1
#         return length
#
#     def insertHead(self, newNode):
#         previousHead = self.head
#         self.head  = newNode
#         self.head.next = previousHead
#         previousHead.previous = self.head
#
#     def insertAt(self, newNode, position):
#         if position < 0 or position > self.listLength():
#             print('Invalid Position')
#             return
#         if position is self.listLength():
#             self.insertEnd(newNode)
#             return
#         if position == 0:
#             self.insertHead(newNode)
#             return
#         currentNode = self.head
#         currentPostion = 0
#         while True:
#             if currentPostion == position:
#                 currentNode.previous.next = newNode
#                 newNode.previous = currentNode.previous
#                 newNode.next = currentNode
#                 currentNode.previous = newNode
#                 break
#             currentNode = currentNode.next
#             currentPostion += 1
#
#     def deleteHead(self):
#         self.head = self.head.next
#         self.head.previous.next = None
#         self.head.previous = None
#
#     def PrintList(self):
#         if self.head is None:
#             print('List is Empty')
#         currentNode = self.head
#         print('Begining')
#         while True:
#             if currentNode is None:
#                 break
#             print(currentNode.data)
#             if currentNode.next is None:
#                 reverseTraverseNode = currentNode
#             currentNode = currentNode.next
#         print('End')
#         while True:
#             if reverseTraverseNode is None:
#                 break
#             print(reverseTraverseNode.data)
#             reverseTraverseNode = reverseTraverseNode.previous
#
# nodeOne = Node('1')
# nodeTwo = Node('2')
# nodeThree = Node('3')
# nodeFour = Node('4')
# linkedList = LinkedList()
# linkedList.insertEnd(nodeOne)
# linkedList.insertEnd(nodeTwo)
# linkedList.insertEnd(nodeThree)
# linkedList.deleteHead()
#
# linkedList.PrintList()


# ---------------------------------------------------
#
#
# class Node:
#     def __init__(self, data):
#         self.data = data
#         self.next = None
#         self.previous = None
#
# class LinkedList:
#     def __init__(self):
#         self.head = None
#
#     def insertEnd(self, newNode):
#         # sid  -> UST -> Meta->
#         if self.head is None:
#             self.head = newNode
#             return
#         else:
#             currentNode = self.head
#             while True:
#                 if currentNode.next == None:
#                     break
#                 currentNode = currentNode.next
#             currentNode.next = newNode
#             newNode.previous = currentNode
#     def listLength(self):
#         length = 0
#         currentNode = self.head
#         while currentNode is not None:
#             currentNode = currentNode.next
#             length += 1
#         return length
#
#     def insertHead(self, newNode):
#         previousHead = self.head
#         self.head  = newNode
#         self.head.next = previousHead
#         previousHead.previous = self.head
#
#     def insertAt(self, newNode, position):
#         if position < 0 or position > self.listLength():
#             print('Invalid Position')
#             return
#         if position is self.listLength():
#             self.insertEnd(newNode)
#             return
#         if position == 0:
#             self.insertHead(newNode)
#             return
#         currentNode = self.head
#         currentPostion = 0
#         while True:
#             if currentPostion == position:
#                 currentNode.previous.next = newNode
#                 newNode.previous = currentNode.previous
#                 newNode.next = currentNode
#                 currentNode.previous = newNode
#                 break
#             currentNode = currentNode.next
#             currentPostion += 1
#
#     def deleteAt(self, position):
#         currentNode = self.head
#         currentPosition = 0
#         while True:
#             if currentPosition == position:
#                 currentNode.previous.next = currentNode.next
#                 currentNode.next.previous = currentNode.previous
#                 currentNode.next = None
#                 currentNode.previous = None
#                 break
#             currentNode = currentNode.next
#             currentPosition += 1
#
#
#     def deleteHead(self):
#         self.head = self.head.next
#         self.head.previous.next = None
#         self.head.previous = None
#
#     def PrintList(self):
#         if self.head is None:
#             print('List is Empty')
#         currentNode = self.head
#         print('Begining')
#         while True:
#             if currentNode is None:
#                 break
#             print(currentNode.data)
#             if currentNode.next is None:
#                 reverseTraverseNode = currentNode
#             currentNode = currentNode.next
#         print('End')
#         while True:
#             if reverseTraverseNode is None:
#                 break
#             print(reverseTraverseNode.data)
#             reverseTraverseNode = reverseTraverseNode.previous
#
# nodeOne = Node('1')
# nodeTwo = Node('2')
# nodeThree = Node('3')
# nodeFour = Node('4')
# linkedList = LinkedList()
# linkedList.insertEnd(nodeOne)
# linkedList.insertEnd(nodeTwo)
# linkedList.insertEnd(nodeThree)
# linkedList.insertEnd(nodeFour)
#
# linkedList.deleteAt(2)
#
# linkedList.PrintList()
#












