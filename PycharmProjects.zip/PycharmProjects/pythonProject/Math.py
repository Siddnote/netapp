# Lucky Numbers

# A lucky number is a number that has exactly 2 distinct prime divisors.
# You are given a number A, and you need to determine the count of
# lucky numbers between the range 1 to A (both inclusive).

# def solve(A):
#     res = 0
#     arr = [0] * (A + 1)
#     print(arr)
#     p = 2
#     while p <= A:
#         # if we encounter 2 then that has 2 distinct primes
#         if arr[p] == 2:
#             res += 1
#             p += 1
#             print('if',p, res)
#             continue
#
#         # 0 indicates a new prime number
#         print('arr', arr[p])
#         if arr[p] == 0:
#             for i in range(2 * p, A + 1, p):
#                 arr[i] += 1
#                 print('0', i, arr,p)
#         p += 1
#         print('p-value', p)
#     return res
#
# print(solve(12))

# ---------------------------------------------------------------------
# def SieveOfEratosthenes(n):
#     prime = [1 for i in range(n + 1)]
#     print(prime)
#     p = 2
#     while (p * p) <= n:
#         # If prime[p] is not changed, then it is a prime
#         print('p', p)
#         if prime[p] == 1:
#             # Update all multiples of p
#             for i in range(p ** 2, n + 1, p):
#                 print(i, end=', ')
#                 prime[i] = 0
#             print()
#         p += 1
#
#     prime[0] = 0
#     prime[1] = 0
#
#     print(prime)
#     for t in range(len(prime)):
#         if prime[t] == 1:
#             print(t, end=', ')
# n = 130
#
# print(SieveOfEratosthenes(n))

#---------------------------------------------------------------------
N= 5
for i in range(N,0, -1):
    print(i)
    print('*' + ' ' * N + '*')