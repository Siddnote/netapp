# Max Sum Contiguous Subarray

# def maxSubArray(A):
#     nums = A
#     max_sum = -9999999
#     curr_sum = 0
#     print(A)
#     for i in range(len(nums)):
#         curr_sum = curr_sum + nums[i]
#         print(curr_sum, i, max_sum)
#         if curr_sum > max_sum:
#             max_sum = curr_sum
#
#         if curr_sum < 0:  # discard
#             curr_sum = 0
#
#     return max_sum
#
#
# A = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
# print(maxSubArray(A))

# --------------------------------------------------------------------------------------------------------------

# Two Sum
# Approach 1
# def twoSum(self, A, B):
#     required = {}
#     for i in range(len(A)):
#         if B - A[i] in required:
#             return [required[B - A[i]] + 1, i + 1]
#         elif A[i] in required:
#             continue
#         else:
#             required[A[i]] = i
#     return []

#  Approach 2
# def twoSum(self, A, B):
#     values = dict()
#     for i, elem in enumerate(A):
#         comp = B - elem
#         if comp in values:
#             return [values[comp] +1 , i + 1]
#         elif A[i] in values:
#             continue
#         values[elem] = i
#     return []

#
# arr = [4, 6, 5, 1, 8]
# target = 9
#
# two_sum(arr, target)
# --------------------------------------------------------------------------------------------------------------
# You are given an integer array A of size N.
# You have to pick B elements in total. Some (possibly 0) elements from left end of array A and some (possibly 0) from
# the right end of array A to get the maximum sum.Find and return this maximum possible sum.

# Input 1:
#  A = [5, -2, 3 , 1, 2]
#  B = 3
# Input 2:
#  A = [1, 2]
#  B = 1
#
# Output 1: 8
# Output 2: 2

# def solve(self, A, B):
#     N = len(A) - 1
#     out = -10000000000000
#     total = 0
#
#     for i in range(B):
#         total += A[i]
#
#     while B > 0:
#         total = total - A[B - 1] + A[N]
#         if out < total:
#             out = total
#         B -= 1
#         N -= 1
#     return out

# --------------------------------------------------------------------------------------------------------------
#  Maximum Absolute Difference

# class Solution:
#     # @param A : list of integers
#     # @return an integer
#     def maxArr(self, A):
#         n = len(A)
#
#         if len(A) == 1:
#             return 0
#
#         X_MAX, X_MIN = -99999999999, 99999999999
#         Y_MAX, Y_MIN = -99999999999, 99999999999
#         ans = max((X_MAX - X_MIN), (Y_MAX - Y_MIN))
#
#         for i in range(n):
#             X = A[i] - i
#             Y = A[i] + i
#             # update X_MAX, X_MIN, Y_MAX, Y_MIN
#             X_MAX, X_MIN = max(X, X_MAX), min(X, X_MIN)
#             Y_MAX, Y_MIN = max(Y, Y_MAX), min(Y, Y_MIN)
#
#         ans = max((X_MAX - X_MIN), (Y_MAX - Y_MIN))
#
#         return ans

# --------------------------------------------------------------------------------------------------------------

# Given an array B of length A with elements 1 or 0. Find the number of subarrays with bitwise OR 1.
# A = 3
# B = [1, 0, 1]
#
# A = 2
# B = [1, 0]
#
# Output
# Output 1: 5
# Output 2: 2

# The subarrays are :- [1], [0], [1], [1, 0], [0, 1], [1, 0, 1]
# Except the subarray [0] all the other subarrays has a Bitwise OR = 1


# def solve(A, B):
#     N = (len(B) * (len(B) + 1))/2
#     L = len(B)
#     i= 0
#     while i < L:
#         if B[i] == 1:
#             i += 1
#             continue
#         j = i
#         cnt = 0
#         while j < L and B[j] == 0:
#             j += 1
#             cnt += 1
#         N = N - cnt * (cnt +1)/2
#         i = j
#     return int(N)


# --------------------------------------------------------------------------------------------------------------

# count the sub-array which have 1 in that
#
# B = [1, 0, 0, 1, 1, 0, 1, 1, 1]
# N = (len(B) * (len(B) + 1)) / 2
# L = len(B)
# i = 0
# while i < L:
#     if B[i] == 1:
#         i += 1
#         continue
#     j = i
#     cnt = 0
#     while j < L and B[j] == 0:
#         j += 1
#         cnt += 1
#
#     print(cnt)
#     N = N - cnt * (cnt + 1) / 2
#     i = j
#
# print(N)

# --------------------------------------------------------------------------------------------------------------

# N = [1, 2, 4, 3, 3, 2, 2, 3, 1, 1]
#
#
# def checkNum(N):
#     maxval = max(N)
#
#     msb = 1
#     count = 0
#     res = 0
#
#     while msb <= max:
#         count = 0
#
#         for i in range(len(N)):
#             if (N[i] & msb) != 0:
#                 count += 1
#
#         if count % 3 != 0:
#             res += msb
#
#         msb = msb << 1
#     return res
#
#
# checkNum(N)


# --------------------------------------------------------------------------------------------------------------
# Given an array of integers, every element appears thrice except for one, which occurs once.
# Find that element that does not appear thrice



# N = [1, 2, 4, 3, 3, 2, 2, 3, 1, 1]
# N = [1, -2, 4, -3, -3, -2, -2, -3, 1, 1]

# def checkNum(N):
#     maxval = max(N)
#     msb = 1
#     count = 0
#     res = 0
#     # print(N)
#     while msb <= maxval:
#         count = 0
#         for i in range(len(N)):
#             # print('input', i , N[i], msb,  N[i] & msb)
#             if (N[i] & msb) != 0:
#                 count += 1
#                 # print('cnt', count)
#
#         # print('count ----->',count)
#         if (count % 3) != 0:
#             res += msb
#             # print(res, '---')
#
#         msb = msb << 1
#         # print('msb', msb)
#
#     return res
#
#
# print(checkNum(N))


# Program to print binomial expansion series
def series(A, X, n):
    # Calculating and printing first term
    term = pow(A, n)
    print(term, end=" ")

    # Computing and printing remaining terms
    for i in range(1, n + 1):
        # Find current term using previous terms We increment power of X by 1, decrement
        # power of A by 1 and compute nCi using previous term by multiplying previous
        # term with (n - i + 1)/i
        term = int(term * X * (n - i + 1) / (i * A))

        print(term, end=" ")


# Driver Code
A = 3;
X = 4;
n = 5
series(A, X, n)
