
# Write a recursive function that checks whether string A is a palindrome or Not.
# Return 1 if the string A is a palindrome, else return 0.
#
# import sys
# sys.setrecursionlimit(10**6)
#
# def check(A, start, end):
#     if start >= end:
#         return 1
#     if A[start] == A[end] and check(A, start + 1, end - 1):
#         return 1
#     return 0
# class Solution:
#     # @param A : string
#     # @return an integer
#
#     def solve(self, A):
#         return check(A, 0, len(A)-1)

# -------------------------------------------------------------------------------------------------------------------
# palindrome
#
# def check(A, start, end):
#     if start >= end:
#         return 1
#     if A[start] == A[end] and check(A, start + 1, end - 1):
#         return 1
#     return 0
#
# A = int(input())
# for i in range(0, A):
#     i = input()
#     out = check(i, 0, len(i) - 1)
#     print(out)
# -------------------------------------------------------------------------------------------------------------------

# Given a string A consisting of lowercase characters.
# Check if characters of the given string can be rearranged to form a palindrome.
# Return 1 if it is possible to rearrange the characters of the string A such that it becomes a palindrome else return 0
#
# A = "abbcdde"
# HM = {}
# for i in A:
#     if i in HM:
#         HM[i] += 1
#     else:
#         HM[i] = 1
# print(len(HM))
#
# count = 0
# for i in HM:
#     if HM[i] % 2 == 1:
#         count += 1
# if count > 1:
#     print('0')

# -------------------------------------------------------------------------------------------------------------------
#
# def bar(x, y):
#     if y == 0:
#         return 0
#     return (x + bar(x, y-1))
#
# def foo(x, y):
#     if(y == 0):
#         return 1
#     return bar(x, foo(x, y-1))
#
# print(foo(3, 5))
#
#
# def fun(x, n):
#     if (n == 0):
#         return 1
#     elif (n % 2 == 0):
#         return fun(x * x, n //2)
#     else:
#         return x * fun(x * x, (n - 1) // 2)
#
# ans = fun(2, 10)
# print(ans)

# -------------------------------------------------------------------------------------------------------------------
# def findAthFibonacci(A):
#     if A == 0:
#         return 0
#     elif A == 1 or A == 2:
#         return 1
#     else:
#         return (findAthFibonacci((A - 1)) + findAthFibonacci((A - 2)))
#
# print(findAthFibonacci(6))


# -------------------------------------------------------------------------------------------------------------------

# def reverse(s):
#     if len(s) == 0:
#         return s
#     else:
#         return reverse(s[1:]) + s[0]
#
# s = "Geeksforgeeks"
# # print(s[1:])
# print(reverse(s))
# -------------------------------------------------------------------------------------------------------------------

p = 1.0
f = 1.0
# Taylor Series
def e(x, n):
    global p, f
    # Termination condition
    if (n == 0):
        return 1

    # Recursive call
    r = e(x, n - 1)
    # Update the power of x
    p = p * x
    # Factorial
    f = f * n
    return (r + p / f)

print(e(1, 10))

# using Horner's Rule

p = 1.0
def H(x, n):
    global p
    if n == 0:
        return p
    p = 1 + x /n * p
    return H(x, n-1)
print(H(1, 10))

# Using Itretive Method
def solve(x, n):
    s = 1
    num = 1
    den = 1
    for i in range(1, n):
        num *= x
        den *= i
        s += num/den
    return s

print(solve(1, 10))





