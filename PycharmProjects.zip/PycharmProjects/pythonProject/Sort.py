
# Bubble sort
A = [4, 2, 5, 10, 1, 3]
#  Time Complexity : O(N^2)
for i in range(0, len(A)):
    for j in range(0, len(A)-1):
        if A[j] > A[j+1]:
            A[j], A[j+1] = A[j+1], A[j]
print(A)

# Binary Search
start = 0
end = len(A)-1
target = 8
ans = -1
while start <= end:
    mid = (start + end)//2

    if A[mid] == target:
        ans = mid
        break
    elif A[mid] > target:
        end = mid-1
    # elif A[mid] < target:
    else:
        start = mid + 1

print(ans)






# def solve(A):
#     B = sorted(A)
#     print(B)
#     for i in range(len(B)-1, 0, -1):
#         if (B[i] - B[i - 1]) == (B[i - 1] - B[i - 2]):
#             continue
#         else:
#             return 0
#
# A = [3, 5, 1]
# print(solve(A))

# A = [ 2, 0, 0, 1, 0, 0, 2, 2, 1, 1, 0, 0, 1, 0, 2, 1, 1, 0, 1, 0, 1, 2, 2, 2, 0, 0, 1, 0, 2, 1, 1, 2, 1, 2, 2, 1, 0, 2, 2, 1, 1, 1, 0, 1, 0, 1, 0, 2, 1, 2, 0, 2, 0, 1, 1, 0, 2, 2, 1, 2, 0, 2, 1, 1, 1, 2, 0, 1, 0, 2, 2, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 2, 1, 1, 0, 2, 1, 2, 0, 0, 0, 2, 2, 2, 2, 0, 0, 0, 1, 1, 0, 2, 1, 2, 2, 2, 1, 2, 2, 0, 1, 0, 1, 2, 1, 1, 0, 1, 2, 0, 1, 0, 2, 2, 1, 2, 1, 0, 2, 2, 1, 1, 0, 2, 1, 2 ]
#
# def sortColors(A):
#     if len(A) == 1:
#         return 0
#     rcount = 0
#     wcount = 0
#     bcount = 0
#     for i in range(len(A)):
#         if A[i] == 0:
#             rcount += 1
#         if A[i] == 1:
#             wcount += 1
#         if A[i] == 2:
#             bcount += 1
#
#     A = rcount * [0]
#     B = wcount * [1]
#     C = bcount * [2]
#
#     return A + B + C
#
# print(sortColors(A))

#
# def solve(A, B):
#     HM = {}
#     for i in A:
#         if i in HM:
#             HM[i] += 1
#         else:
#             HM[i] = 1
#     print(HM)
#
#     D = []
#     for i in HM.values():
#         D.append(i)
#     print(D)
#
#     C = []
#     l = 0
#     while B > 0:
#         l += 1
#         if B >= l:
#             C.append(l)
#             if l in D:
#                 D.remove(l)
#         else:
#             C.append(B)
#             if B in D:
#                 D.remove(B)
#         B -= l
#     print(C)
#     print(D)
#
#     for i, j in HM.items()
#
# A = 'wfnfozvsrt'
# solve(A, 4)



