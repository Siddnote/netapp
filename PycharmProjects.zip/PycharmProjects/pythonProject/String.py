# ord function to ASCII

# print(ord('a'))
# print(ord('A'))
#
# # ASCII to function
# print(chr(65))
# print(chr(90))

### String is Immutable
# s = "Hello"
# print(id(s))
# s = "Hello world"
# print(id(s))
# s = "Hello world" + "new" + str(4)
# print(id(s))
# print(s)

### Repetition
# s = "Hello "
# a = s * 5
# print(a)


### Search word from string
# book = 'Harry is in my school, Hope he is doing well'
# if 'Harry' in book:
#     print("yes")
# else:
#     print("No")


### Replace
# text = "House is beautiful"
# new_text = text.replace("beautiful", "Gorgeous")
# print(text, new_text)

# a= "siddhant is in office".replace("is", "was")
# print(a)


### Lower / Uper
# book = 'Siddhant is wokring for exam'
# low = book.lower()
# upper = book.upper()
# print(low)
# print(upper)

# book = 'Siddhant is wokring for exam'
# for char in book:
#     print(char, end=' ')

### delete variable
# book = 'Siddhant is wokring for exam'
# del book
# print(book)

### String Splicing
# s = "Hello Wrorld"
# t = s[:-1]
# print(s, t)

### Strip Function
# a = "           Hello World              "
# print(a.lstrip())
# print(a.rstrip())
# print(a.strip())


### Reverse String
# s = "Hello world baby love you "
# A =s.split()
# i = 0
# j = len(A) -1
# while i < j:
#     A[i], A[j] = A[j], A[i]
#     i += 1
#     j -= 1
# B =" ".join(A)
# print(B)

# s ="this book"
# sa = " ".join(s.split())[::-1]
# print(sa)

### []DocStrings
# def square(x):
#     '''
#
#     :param x:
#     :return:
#
#     '''
#     return x**2
#
# print(square(3))


# -------------------------------------------------------------------------------------------------------------------
### Q: Given character is lowercase
#
# def checkCharacter( input):
#     input = ord(input)
#     print(input)
#     if input >= 97 and input <= 122:
#         return input
#
# print(checkCharacter('5'))
# -------------------------------------------------------------------------------------------------------------------
# Given string, seperate character
# lst = []
# A = 'Siddhant'
# lst.extend(A)
# print(lst)

# -------------------------------------------------------------------------------------------------------------------
# Q : Toggle case of all the characters of a string
# Approach 1 :

# A = 'SidDhAnt'
# lst = []
# lst.extend(A)
#
# for i in range(len(lst)):
#     input = ord(lst[i])
#
#     if (input >= 97) and (input <= 122):
#         lst[i] = chr(input - 32)
#
#     elif (input >= 65) and (input <= 90):
#         lst[i] = chr(input + 32)
#
# print(*lst)

# Approach 2:
# A = 'SidDhAnt'
# lst = []
# lst.extend(A)

# for i in range(len(lst)):
#     input = ord(lst[i])
#     lst[i] = chr(input ^ (1 << 5))
# print(*lst)

# -------------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------------
# lst = ['S', 'c', 'A', 'L', 'E', 'r', 'A', 'c', 'a', 'D', 'e', 'm', 'y']
# for i in range(len(lst)):
#     input = ord(lst[i])
#     # print(input, type(input))
#     if (input >= 97) and (input <= 122):
#         lst[i] = chr(input ^ (1 << 5))
#     else:
#         lst[i] = chr(input)
# print(*lst)

# ## Alpha Numeric
# A = ['S', 'c', 'a', 'l', '*', 'e', 'r', 'A', 'c', 'a', 'd', 'e', 'm', 'y', '2', '0', '2', '0']
# def solve(A):
#     for x in A:
#         if (x.isalnum() == 0):
#             return 0
#     return 1
# print(solve(A))
#
# ## Alphabet
# def solve(self, A):
#     for x in A:
#         if (x.isalpha() == 0):
#             return 0
#     return 1

# -------------------------------------------------------------------------------------------------------------------

# def solve(A):
#     B = A + A
#     lst = []
#     lst.extend(B)
#     print('a', len(lst))
#     for i in range(len(lst)):
#         print('i', i)
#         input = ord(lst[i])
#         print(input)
#         if (input >= 65) and (input <= 90):
#             print('rem', lst[i])
#     print(list)

#
# A="AbcaZeoB"
# solve(A)
# A = 'abobobc'
# lst = []
# lst.extend(A)
# count = 0
# print(len(lst))
# for i in range(len(lst)):
#     if lst[i] == 'b':
#         print('if',i, i+1)
#         if lst[i + 1] == 'o':
#             if lst[i + 2] == 'b':
#                 count += 1
# print(count)
#
#
# def solve(self, A):
#     s = A
#     prev = -1
#     ans = 0
#     cur = s.find("bob", prev + 1)
#     while cur != -1:
#         ans += 1
#         prev = cur
#         cur = s.find("bob", prev + 1)
#     return ans
#
#
# s = 'hackthegame'
# HM = {}
# for i in s:
#     if i in HM:
#         HM[i] += 1
#     else :
#         HM[i] = 1
# print(HM)
# for i in range(len(s)):
#     print(HM[s[i]])
#     if HM[s[i]] < 2:
#         print(i+1)
#         break

# -------------------------------------------------------------------------------------------------------------------
# def reverse(s):
#     if len(s) == 0:
#         return s
#     else:
#         return reverse(s[1:]) + s[0]

# -------------------------------------------------------------------------------------------------------------------
# Make possible palindromic string from given Input
# A = "abb"
# A = "aaaaabaaaa"
# HM = {}
# for i in A:
#     if i in HM:
#         HM[i] += 1
#     else:
#         HM[i] = 1
# print(HM)
#
# out = ['0', '0', '0']
# s = ""
# for j in HM:
#     val = 0
#     if HM[j] > 1:
#         # print(j, HM[j])
#         val = HM[j] // 2
#         out[0] = (val * j)
#
#     else:
#         out[1] = j
# out[2] = out[0]
# s = s.join(out)
# print(s)

# -------------------------------------------------------------------------------------------------------------------
# Pending
# A = "aaaaabaaaa"
# A = "abb"
# A = 'abcdefghij'
# A = 'cacaccbabcabbbaacbbbbcaaaccaacbabcaccbccaacccaacbbaaabbbabcaaabc'
# A = aacbbbbcaa
# A = 'babbbbbba'
#
# def longestPalindrome(A):
#     max_strng_len = 0
#     max_strng = None
#
#     def reverse(S, strt, end):
#         while strt >= 0 and end < len(S):
#             if S[strt] != S[end]:
#                 return S[strt + 1:end]
#             strt -= 1
#             end += 1
#         return S[strt + 1:end]
#
#     # odd length palindrome check
#     for i in range(len(A)):
#         x = reverse(A, i, i)
#         print(x)
#         if len(x) > max_strng_len:
#             max_strng = x
#             max_strng_len = max(max_strng_len, len(x))
#
#     # even length palindrome check
#     p1 = 0
#     p2 = 1
#     while p2 < len(A):
#         x = reverse(A, p1, p2)
#         print(x)
#         if len(x) > max_strng_len:
#             max_strng = x
#             max_strng_len = max(max_strng_len, len(x))
#         p1 += 1
#         p2 += 1
#     return max_strng
#
# print(longestPalindrome(A))

# -------------------------------------------------------------------------------------------------------------------
# Reverse given Array
# A = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# Approach - 1
# i = 0
# j = len(A)-1
# while i < j:
#     print(i, j, A[i], A[j])
#     A[i], A[j] = A[j], A[i]
#     i += 1
#     j -= 1
# print(A)

# Approach - 2
# A = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# B = [0] * (len(A))
# i = 0
# j = len(A)-1
# while i <= (len(A)-1):
#     B[i] = A[j]
#     i += 1
#     j -= 1
# print(B)
# -------------------------------------------------------------------------------------------------------------------
